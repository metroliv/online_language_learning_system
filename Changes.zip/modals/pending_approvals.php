<!-- approve collection -->
<div class="modal fade fixed-right" id="approve_<?php echo $rows['collection_id']; ?>" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header align-items-center">
				<div class="text-center">
					<h6 class="mb-0 text-bold"><?php echo $rows['user_names']; ?></h6>
				</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>

			</div>
			<div class="modal-body">
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					<div class="row">

						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Stream <span class="text-danger">*</span></label>
							<input type="hidden" readonly name="collection_id" value="<?php echo $rows['collection_id']; ?>" class="form-control">
							<input type="text" readonly value="<?php echo $rows['stream_name'] ?>" value="<?php echo $rows['collection_id']; ?>" class="form-control">

						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Service <span class="text-danger">*</span></label>
							<input type="text" readonly value="<?php echo $rows['service_name'] ?>" value="<?php echo $rows['collection_id']; ?>" class="form-control">

						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Amount <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly name="collection_amount" value="<?php echo $rows['collection_amount']; ?>" class="form-control">
							</div>
						</div>

						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Date <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly value="<?php echo $rows['collection_date']; ?>" readonly name="collection_date" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Location <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly name="collection_location" value="<?php echo $rows['collection_location']; ?>" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Assignment <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly name="collection_assignment" value="<?php echo $rows['collection_assignment']; ?>" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-12 col-lg-12 col-xl-12">
							<label class="form-control-label">Give a comment (optional)</label>
							<div class="input-group input-group-merge">
								<textarea type="text" name="collection_approval_comment" class="form-control"></textarea>
							</div>
						</div>

					</div>
					<div class="text-right">
						<button type="submit" name="ApproveCollection" class="btn btn-outline-success">Approve</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- decline collection -->
<div class="modal fade fixed-right" id="decline_<?php echo $rows['collection_id']; ?>" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header align-items-center">
				<div class="text-center">
					<h6 class="mb-0 text-bold"><?php echo $rows['user_names']; ?></h6>
				</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					<div class="row">

						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Stream <span class="text-danger">*</span></label>
							<input type="hidden" readonly name="collection_id" value="<?php echo $rows['collection_id']; ?>" class="form-control">
							<input type="text" readonly value="<?php echo $rows['stream_name'] ?>" value="<?php echo $rows['collection_id']; ?>" class="form-control">

						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Service <span class="text-danger">*</span></label>
							<input type="text" readonly value="<?php echo $rows['service_name'] ?>" value="<?php echo $rows['collection_id']; ?>" class="form-control">

						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Amount <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly name="collection_amount" value="<?php echo $rows['collection_amount']; ?>" class="form-control">
							</div>
						</div>

						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Date <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly value="<?php echo $rows['collection_date']; ?>" readonly name="collection_date" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Location <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly name="collection_location" value="<?php echo $rows['collection_location']; ?>" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Assignment <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" readonly name="collection_assignment" value="<?php echo $rows['collection_assignment']; ?>" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-12 col-lg-12 col-xl-12">
							<label class="form-control-label">Give a comment <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<textarea type="text" required name="collection_approval_comment" class="form-control"></textarea>
							</div>
						</div>

					</div>
					<div class="text-right">
						<button type="submit" name="DeclineCollection" class="btn btn-outline-danger">Decline Collection</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>