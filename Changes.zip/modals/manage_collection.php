<div class="modal fade fixed-right" id="update_<?php echo $rows['collection_id']; ?>" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header align-items-center">
                <div class="text-center">
                    <h6 class="mb-0 text-bold">Update Collections</h6>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body">
                <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                    <div class="row">
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Stream <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input type="hidden" required name="collection_id" value="<?php echo $rows['collection_id']; ?>" class="form-control">
                                <select type="text" required name="collection_stream_id" class="form-control">
                                    <option value="<?php echo $rows['stream_id']; ?>"><?php echo $rows['stream_name']; ?></option>
                                    <?php
                                    $fetch_streams_sql = mysqli_query(
                                        $mysqli,
                                        "SELECT * FROM revenue_streams"
                                    );
                                    if (mysqli_num_rows($fetch_streams_sql) > 0) {
                                        while ($streams = mysqli_fetch_array($fetch_streams_sql)) {
                                    ?>
                                            <option value="<?php echo $streams['stream_id']; ?>"><?php echo $streams['stream_name']; ?></option>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Service <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input type="hidden" required name="collection_id" value="<?php echo $rows['collection_id']; ?>" class="form-control">
                                <select type="text" required name="collection_service_id" class="form-control">
                                    <option value="<?php echo $rows['service_id']; ?>"><?php echo $rows['service_name']; ?></option>
                                    <?php
                                    $fetch_services_sql = mysqli_query(
                                        $mysqli,
                                        "SELECT * FROM revenue_services"
                                    );
                                    if (mysqli_num_rows($fetch_services_sql) > 0) {
                                        while ($services = mysqli_fetch_array($fetch_services_sql)) {
                                    ?>
                                            <option value="<?php echo $services['service_id']; ?>"><?php echo $services['service_name']; ?></option>
                                    <?php }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Amount <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input type="text" required name="collection_amount" value="<?php echo $rows['collection_amount']; ?>" class="form-control">
                            </div>
                        </div>

                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Date <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input type="text" readonly value="<?php echo $rows['collection_date']; ?>" required name="collection_date" class="form-control">
                            </div>
                        </div>
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Location <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input type="text" required name="collection_location" value="<?php echo $rows['collection_location']; ?>" class="form-control">
                            </div>
                        </div>
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Assignment <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input type="text" required name="collection_assignment" value="<?php echo $rows['collection_assignment']; ?>" class="form-control">
                            </div>
                        </div>
                        <div class="form-group col-sm-12 col-lg-12 col-xl-12">
                            <label class="form-control-label">Comment <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <textarea type="text" required name="collection_comment" class="form-control"><?php echo $rows['collection_comment']; ?></textarea>
                            </div>
                        </div>

                    </div>
                    <div class="text-right">
                        <button type="submit" name="UpdateCollection" class="btn btn-outline-success">Update Collection</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>