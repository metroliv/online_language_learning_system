<!-- add user form -->
<?php
//session_start();
require_once('../helpers/add_streams.php');?>
<html>
    <body>
    <div class="row">
                    <div class="modal fade fixed-right" id="addUser" role="dialog" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header align-items-center">
                                    <div class="text-center">
                                        <h6 class="mb-0 text-bold">Register new revenue system</h6>
                                    </div>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                                        <div class="row">
                                            <div class="form-group col-sm-12 col-lg-12 col-xl-12">
                                                <label class="form-control-label">Name <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" required name="stream_name" class="form-control">
                                                </div>
                                            </div>

                                            <!--<div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label">Phone number <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="phone" required name="user_phone_number" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label">Access level <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <select type="text" required name="user_access_level" class="form-control">
                                                        <option value="System Administrator">System Administrator</option>
                                                        <option value="ECM">ECM - ICT, Education & Internship</option>
                                                        <option value="ECMS">ECMs</option>
                                                        <option value="Chief Officer">Chief Officer</option>
                                                        <option value="Director">Director</option>
                                                        <option value="Director - IMV">Director - IMV</option>
                                                        <option value="Ward Administrator">Ward Administrator</option>
                                                        <option value="Staff">Revenue Collector</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label"> User Ward <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <select type="text" required name="user_ward" class="form-control">
                                                        <option value="33">Emali/Mulala</option>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-4 col-lg-12 col-xl-12">
                                                <label class="form-control-label">Address <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" required name="user_address" class="form-control">
                                                </div>
                                            </div>-->

                                        </div>
                                        <div class="text-right">
                                            <button type="submit" name="Add_streams" class="btn btn-outline-success">Add Stream</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<!-- ./ Add user modal -->
    

            
        </body>

        </html>
<!-- Add New Stream Modal -->
<!--<div class="modal fade" id="addUser" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Create New Revenue Stream</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="add_revenue_stream.php">
                        <div class="form-group">
                            <label for="stream_name">Stream Name</label>
                            <input type="text" class="form-control" id="stream_name" name="stream_name" required>
                        </div>
                        <button type="submit" name="add_stream" class="btn btn-primary">Add Stream</button>
                    </form>
                </div>
            </div>
        </div>
    </div>



