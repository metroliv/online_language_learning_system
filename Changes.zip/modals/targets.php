<!-- update stream targets -->
<div class="modal fade fixed-right" id="updateee_<?php echo $rows['ward_id']; ?>" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
	<div class="modal-content">
			<div class="modal-header align-items-center">
				<div class="text-center">
					<h6 class="mb-0 text-bold">Update targets</h6>
				</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				
			</div>
		</div>
	</div>
</div>
		

<!-- Edit Modal -->
<div class="modal fade fixed-right" id="updateTarget_<?php echo $rows['target_id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header align-items-center">
                <div class="text-bold">
                    <h6 class="text-bold">Update Ward Target</h6>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body"2>
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					
					<div class="row">										
						<div class="form-group col-sm-4 col-lg-12 col-xl-12">
							<label class="form-control-label">Ward <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="hidden" name="target_id" value="<?php echo $rows['target_id'] ?>" class="form-control">
								<input type="text" disabled name="target_id" value="<?php echo $rows['ward_name'] ?>" class="form-control">
							</div>
						</div>
					</div>
					
					<div class="row">										
						<div class="form-group col-sm-4 col-lg-12 col-xl-12">
							<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" disabled name="target_financial_year" value="<?php echo $rows['target_financial_year'] ?>" class="form-control">
							</div>
						</div>
					</div>
					
					<div class="row">										
						<div class="form-group col-sm-4 col-lg-12 col-xl-12">
							<label class="form-control-label">Target Amount <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" required name="target_amount" value="<?php echo $rows['target_amount'] ?>" class="form-control">
							</div>
						</div>
					</div>
					
					<div class="text-right">
						<button type="submit" name="UpdateTarget" class="btn btn-outline-success">Update Target</button>
					</div>
				</form>
            </div>
        </div>
    </div>
</div>
<!-- End Modal -->

<!-- Update stream target -->
<div class="modal fade fixed-right" id="updateStreamTarget_<?php echo $rows['target_id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header align-items-center">
                <div class="text-bold">
                    <h6 class="text-bold">Update Stream Target</h6>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body"2>
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					
					<div class="row">										
						<div class="form-group col-sm-4 col-lg-12 col-xl-12">
							<label class="form-control-label">Ward <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="hidden" name="target_id" value="<?php echo $rows['target_id'] ?>" class="form-control">
								<input type="text" disabled name="target_id" value="<?php echo $rows['ward_name'] ?>" class="form-control">
							</div>
						</div>
					</div>
					
					<div class="row">										
						<div class="form-group col-sm-4 col-lg-12 col-xl-12">
							<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" disabled name="target_financial_year" value="<?php echo $rows['target_financial_year'] ?>" class="form-control">
							</div>
						</div>
					</div>
					
					<div class="row">										
						<div class="form-group col-sm-4 col-lg-12 col-xl-12">
							<label class="form-control-label">Target Amount <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" required name="target_amount" value="<?php echo $rows['target_amount'] ?>" class="form-control">
							</div>
						</div>
					</div>
					
					<div class="text-right">
						<button type="submit" name="UpdateTarget" class="btn btn-outline-success">Update Target</button>
					</div>
				</form>
            </div>
        </div>
    </div>
</div>
<!-- End Modal -->

<!-- Delete Modal -->


<!-- Change User Passwords
<div class="modal fade fixed-right" id="passwords_" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header align-items-center">
                <div class="text-bold">
                    <h6 class="text-bold">Update user passwords</h6>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                    <div class="row">

                        <div style="display:none;" class="form-group col-sm-12 col-lg-4 col-xl-4">
                            <div class="input-group input-group-merge">
                                <input type="text" value="<?php echo $rows['user_id']; ?>" required name="user_id" class="form-control">
                            </div>
                        </div>
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">New password <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input id="password" type="password" required name="new_password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 5 or more characters">
                            </div>
                        </div>
                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                            <label class="form-control-label">Confirm password <span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <input id="confirm_password" type="password" required name="confirm_password" class="form-control" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 5 or more characters">
                            </div>
                        </div>
                        <div id="message">
                            <label class="text-center font-weight-bold">Password must contain the following:</label>
                            <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                            <p id="capital" class="invalid">An <b>uppercase</b> letter</p>
                            <p id="number" class="invalid">A <b>number</b></p>
                            <p id="symbol" class="invalid">A <b>symbol</b></p>
                            <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                        </div>
                        <div id="confirm_message">
                            <p id="match" class="invalid">Passwords <b> match</b></p>
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" name="Update_Officer_Password" class="btn btn-outline-success">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> -->
<!-- End Modal -->