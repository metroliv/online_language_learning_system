<?php
//session_start();
require_once('../helpers/add_services.php');?>
<html>
    <body>
        <div class="row">
            <div class="modal fade fixed-right" id="addUser" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header align-items-center">
                            <div class="text-center">
                                <h6 class="mb-0 text-bold">Register new revenue service</h6>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                                <div class="row">
                                    <div class="form-group col-sm-12 col-lg-12 col-xl-12">
                                        <label class="form-control-label">Service Name <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <input type="text" required name="service_name" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-12 col-lg-12 col-xl-12">
                                        <label class="form-control-label">Stream Name <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <select required name="service_stream_id" class="form-control">
                                                <option value="">Select Stream</option>
                                                <?php foreach ($streams as $stream) { ?>
                                                    <option value="<?php echo $stream['stream_id']; ?>"><?php echo $stream['stream_name']; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <button type="submit" name="Add_services" class="btn btn-outline-success">Add Service</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ./ Add user modal -->
    </body>
</html>
