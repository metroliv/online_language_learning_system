<div class="modal fade fixed-right" id="adminAddImprest" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header align-items-center">
				<div class="text-center">
					<h6 class="mb-0 text-bold">Register new</h6>
				</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					<div class="row">
						<div class="form-group col-sm-12 col-lg-12 col-xl-12">
							<label class="form-control-label">Amount <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" required name="stream_name" class="form-control">
							</div>
						</div>
						<div class="form-group col-sm-12 col-lg-12 col-xl-12">
							<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<input type="text" required name="stream_name" class="form-control">
							</div>
						</div>


					</div>
					<div class="text-right">
						<button type="submit" name="Add_streams" class="btn btn-outline-success">Add Stream</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>