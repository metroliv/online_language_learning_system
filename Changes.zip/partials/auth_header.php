<div class="login-logo">
    <img src="../public/img/merged_logos.png" width="60%" alt="">
</div>
<h5 class="login-box-msg text-dark">
    <b>
        Government of Makueni County <br>
        Revenue Collection Reporting Tool
    </b>
</h5>