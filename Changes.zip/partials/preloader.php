<!-- <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="../public/img/merged_logos.png" alt="" width="20%">
</div> -->