<nav class="main-header navbar navbar-expand navbar-white navbar-light">
	<!-- Left navbar links -->
	<ul class="navbar-nav">
		<li class="nav-item">
			<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
		</li>
		<li class="nav-item d-none d-sm-inline-block">
			<h5 class="pt-2">GoMC - Revenue Reporting Tool</h5>
		</li>

	</ul>

	<ul class="navbar-nav flex-row ml-md-auto d-none d-md-flex">
		<li class="nav-item">
			<a class="nav-link text-danger" data-toggle="modal" data-target="#end_session" href=""><i class="fas fa-power-off"></i></a>
		</li>

	</ul>



</nav>