<?php
require_once('../config/config.php');
require_once('../functions/reusableQuery.php');
require_once('../helpers/cards_collection.php');
require_once('../helpers/stream_perfomance_query.php');
require_once('../helpers/ward_perfomance_query.php');
require_once('../partials/head.php');
require_once('../helpers/cards_collection.php');
require_once('../helpers/stream_perfomance_query.php');

// Fetch wards
$wardsQuery = "SELECT sub_county_id AS ward_id, sub_county_name AS ward_name FROM sub_county";
$wardsResult = $mysqli->query($wardsQuery);

// Check for errors in the query
if (!$wardsResult) {
    die('Error fetching wards: ' . $mysqli->error);
}

// Fetch revenue officers
$officersQuery = "SELECT user_id, user_names FROM users WHERE user_access_level = 'Revenue Collector'";
$officersResult = $mysqli->query($officersQuery);

// Check for errors in the query
if (!$officersResult) {
    die('Error fetching officers: ' . $mysqli->error);
}

// Fetch streams
$streamsQuery = "SELECT stream_id, stream_name FROM revenue_streams";
$streamsResult = $mysqli->query($streamsQuery);

// Check for errors in the query
if (!$streamsResult) {
    die('Error fetching streams: ' . $mysqli->error);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('../partials/head.php'); ?>
    <title>Revenue Collection Reports</title>
    <style>
        .chart-container {
            position: relative;
            height: 500px;
            /* Increased height */
            width: 100%;
            /* Full width */
        }

        .content-wrapper {
            padding: 20px;
            /* Ensure padding for content */
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <!-- Main Sidebar Container -->
        <!-- Content Wrapper. Contains page content -->
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo $greeting . ', ' . $_SESSION['user_names']; ?>
                        </h1>
                        <small>Welcome to Department of Finance Revenue Collection Tool</small>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="container-fluid">
            <div class="row">
                <!-- Info Boxes -->
                <!-- Info Box for Revenue Target -->
                <div class="col-md-3 col-sm-6 col-12">
                    <a href="revenue_target" class="text-dark">
                        <div class="info-box">
                            <span class="info-box-icon bg-info"><i class="far fa-flag"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Revenue Target</span>
                                <span class="info-box-text"></span>
                                <span class="info-box-number"><?php echo number_format($revenueTarget); ?> Ksh</span>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- Info Box for Total Revenue Collected -->
                <div class="col-md-3 col-sm-6 col-12">
                    <a href="revenue_collected" class="text-dark">
                        <div class="info-box">
                            <span class="info-box-icon bg-success"><i class="fas fa-wallet"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Total Revenue Collected</span>
                                <span class="info-box-number"><?php echo number_format($totalRevenueCollected); ?> Ksh</span>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- Info Box for % Target Achieved -->
                <div class="col-md-3 col-sm-6 col-12">
                    <a href="target_achieved" class="text-dark">
                        <div class="info-box">
                            <span class="info-box-icon bg-warning"><i class="fas fa-percent"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">% Target Achieved</span>
                                <span class="info-box-number"><?php echo number_format($percentageAchieved, 2); ?>%</span>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- Info Box for Top Officer's Performance -->
                <div class="col-md-3 col-sm-6 col-12">
                    <a href="../partials/top_officer.php" class="text-dark">
                        <div class="info-box">
                            <span class="info-box-icon bg-primary"><i class="fas fa-chart-line"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Top Officer</span>
                                <span class="info-box-text">Officer: <?php echo htmlspecialchars($topOfficerName); ?></span>
                                <span class="info-box-text">Ward: <?php echo htmlspecialchars($topOfficerWard); ?></span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Ward Performance Chart -->
            <div class="row mb-3">
                <div class="col-12">
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title">Performance vs Target by Ward</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="chart-container" style="position: relative; height: 100%; width: 90%; ">
                                <canvas id="performanceChart"></canvas>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
            </div>
            <!-- Filter Form -->
            <div class="row mb-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title m-0">Filter Stream Performance</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="stream">Stream</label>
                                        <select id="stream" name="stream" class="form-control">
                                            <option value="all">All</option>
                                            <?php
                                            $streamsQuery = "SELECT stream_id, stream_name FROM revenue_streams";
                                            $streamsResult = $mysqli->query($streamsQuery);
                                            while ($stream = $streamsResult->fetch_assoc()) {
                                                echo '<option value="' . $stream['stream_id'] . '">' . htmlspecialchars($stream['stream_name']) . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="start_date">Start Date</label>
                                        <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($startDate); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="end_date">End Date</label>
                                        <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($endDate); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="submit">&nbsp;</label>
                                        <button type="submit" class="btn btn-primary form-control">Filter</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stream Performance Table -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title m-0">Stream Performance</h5>
                        </div>
                        <div class="card-body">
                            <table class="data_table table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Timeframe</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($streamPerformance as $performance) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($performance['stream_name']); ?></td>
                                            <td><?php echo htmlspecialchars($startDate) . ' to ' . htmlspecialchars($endDate); ?></td>
                                            <td><?php echo number_format($performance['total_collected'], 0); ?> Ksh</td>
                                            <td>
                                                <a href="../views/view_details.php?stream_id=<?php echo $performance['stream_id']; ?>&start_date=<?php echo urlencode($startDate); ?>&end_date=<?php echo urlencode($endDate); ?>" class="btn btn-info btn-sm">View Details</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- ./wrapper -->
    <?php include('../partials/scriptn.php'); ?>
    <script>
        // JavaScript to render the chart
        document.addEventListener('DOMContentLoaded', function() {
            var ctxLine = document.getElementById('performanceChart').getContext('2d');
            var performanceChart = new Chart(ctxLine, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($wards); ?>,
                    datasets: [{
                        label: 'Target Amount',
                        data: <?php echo json_encode($targets); ?>,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2,
                        fill: false
                    }, {
                        label: 'Collected Amount',
                        data: <?php echo json_encode($collected); ?>,
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 2,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                display: true,
                                color: '#e3e3e3'
                            }
                        },
                        x: {
                            grid: {
                                display: true,
                                color: '#e3e3e3'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                            labels: {
                                color: '#333'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.7)',
                            titleColor: '#fff',
                            bodyColor: '#fff'
                        }
                    }
                }
            });
        });
    </script>

</body>

</html>