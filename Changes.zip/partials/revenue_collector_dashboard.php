<?php
// Start session and connect to the database

require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../partials/headn.php');
require_once('../functions/collector_target_analytics.php');
require_once('../partials/headn.php');
//dd($_SESSION['user_ward_id']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Collector Dashboard</title>
  <link rel="stylesheet" href="../public/css/adminlte.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dist/css/adminlte.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js library -->
</head>

<body>
  <!-- Main content -->
  <section class="content">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">
              <?php echo $greeting . ', ' . $_SESSION['user_names'] ?>
            </h1>
            <small>Welcome to Department of Finance Revenue Collection Tool</small>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>


    <div class="row">
      <!-- Date Range Filter -->

    </div>

    <div class="container-fluid">
      <!-- Small boxes (Stat box) -->

      <!-- /.row -->
      <div class="row">

        <div class="col-md-3 col-sm-6 col-12">
          <a href="revenue_target_per_stream?id=<?php echo $_SESSION['user_id'] ?>" class="text-dark">
            <div class="info-box">
              <span class="info-box-icon bg-info"><i class="fas fa-bullseye"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">My Target</span>
                <span class="info-box-number">Ksh <?php echo number_format($collectorTarget); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </a>
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-12">
          <a href="#" class="text-dark">
            <div class="info-box">
              <span class="info-box-icon bg-success"><i class="fas fa-equals"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Collected Amount</span>
                <span class="info-box-number">Ksh <?php echo number_format($my_collections); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </a>
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-12">
          <div class="info-box">

            <span class="info-box-icon bg-warning"><i class="fas fa-check-double"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">% Target Achieved</span>
              <span class="info-box-number"><?php echo number_format($totalPercentage, 2) . '%'; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-12">
          <a href="imprest" class="text-dark">
            <div class="info-box">

              <span class="info-box-icon bg-warning"><i class="fas fa-file-invoice-dollar"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Imprest Earned</span>
                <span class="info-box-number">Ksh <?php echo number_format($imprest * $my_collections); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
          </a> <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->


      <?php include('../views/chart2.php'); ?>
      <?php include('../partials/scriptn.php'); ?>
     
    </div>