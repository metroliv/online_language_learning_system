<footer class="main-footer">
    <strong>Copyright &copy; 2014-2024 <a href="#">Makueni County</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        
    </div>
</footer>