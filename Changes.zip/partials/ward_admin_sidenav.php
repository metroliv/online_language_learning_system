<?php

/** pending Approvals */
$query = "SELECT count(collection_status) FROM revenue_collections 
WHERE collection_status = 'Pending' 
AND collection_ward_id = '{$_SESSION['user_ward_id']}' 
";
// AND collection_fy = '2024/2025' 
// AND DATE_FORMAT(collection_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m');";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($pending_approvals);
$stmt->fetch();
$stmt->close();

?>

<aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: #124491 ">
	<!-- Brand Logo -->


	<!-- Sidebar -->
	<!-- <div class="sidebar"> -->
	<!-- Sidebar user panel (optional) -->
	<!-- <div class="user-panel mt-3 pb-3 mb-3">

            <div class="image">
                <img src="../public/img/avatar5.png" class="img-circle elevation-2" alt="User Image">
            </div>
            </br>
            <div class="info">
                <a href="#" class="d-block">
                    <?php $_SESSION['user_email']; ?>
                    <br />
                    <?php $_SESSION['user_access_level']; ?>                    
                </a>
            </div>
        </div> -->

	<!-- SidebarSearch Form -->

	<!-- Brand Logo -->
	<a href="dashboard" class="brand-link">
		<img src="../public/img/merged_logos.png" alt="makueni Logo" class="brand-image" style="opacity: .8">
		<span class="brand-text font-weight-light">GoMC</span>
	</a>

	<!-- Sidebar -->
	<div class="sidebar">
		<!-- Sidebar user panel (optional) -->
		<div class="user-panel mt-3 pb-3 mb-3 d-flex">
			<div class="image">
				<img src="../public/img/no-profile.png" class="img-circle elevation-2" alt="User Image">
			</div>

			<div class="info pt-0 mt-0">
				<a href="#" class="">
					<?php echo $_SESSION['user_names']; ?>
					<br />
					<?php echo $_SESSION['user_access_level']; ?>
				</a>
			</div>
		</div>

		<!-- SidebarSearch Form -->
		<div class="form-inline">
			<div class="input-group" data-widget="sidebar-search">
				<input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
				<div class="input-group-append">
					<button class="btn btn-sidebar">
						<i class="fas fa-search fa-fw"></i>
					</button>
				</div>
			</div>
		</div>


		<!-- Sidebar Menu -->
		<nav class="mt-2">
			<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

				<li class="nav-item">
					<a href="dashboard" class="nav-link">
						<i class="nav-icon fas fa-tachometer-alt text-success"></i>
						<p>
							Dashboard
						</p>
					</a>
				</li>
				<li class="nav-item">
					<a href="admin_collections" class="nav-link">
						<i class="nav-icon fas fa-file-invoice-dollar text-success"></i>
						<p>
							Register Collections
						</p>
					</a>
				</li>




				<!-- Imprest -->
				<li class="nav-item">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-wallet text-success"></i>
						<p>
							Imprest
							<i class="fas fa-angle-left right"></i>
						</p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="staff_imprest" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Calculations</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="staff_imprest_payment" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Payments</p>
							</a>
						</li>

					</ul>
				</li>

				<!-- ward -->
				<li class="nav-item">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-map text-success"></i>
						<p>
							Ward
							<i class="fas fa-angle-left right"></i>
						</p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="ward_performance" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Performance</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="ward_revenue_target" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Targets</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="ward_collections" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Collections</p>
							</a>
						</li>

					</ul>
				</li>

				<!-- Collectors -->
				<li class="nav-item">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-users text-success"></i>
						<p>
							Collectors
							<i class="fas fa-angle-left right"></i>
						</p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="staff_performance" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Performance</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="staff_annual_target" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Targets</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="staff_collections" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Collections</p>
							</a>
						</li>

						<li class="nav-item">
							<a href="ward_staff" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Registry</p>
							</a>
						</li>
					</ul>
				</li>

				<!-- Reports -->
				<li class="nav-item">
					<a href="All_reports" class="nav-link">
						<i class="nav-icon fas fa-flag text-success"></i>
						<p>
							Reports
							<i class="fas fa-angle-left right"></i>
							<?php
							if ($pending_approvals > 0) {
							?>
								<span class="badge badge-info right"><?php echo $pending_approvals; ?></span>
							<?php } ?>
						</p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="All_reports?status=Pending&date=<?php echo date('Y-m-d') . ' - ' . date('Y-m-d'); ?>&fy=2024/2025"
								class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Pending</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="All_reports?status=Approved&date=<?php echo date('Y-m-d') . ' - ' . date('Y-m-d'); ?>&fy=2024/2025" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Approved</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="All_reports?status=Rejected&date=<?php echo date('Y-m-d') . ' - ' . date('Y-m-d'); ?>&fy=2024/2025" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Rejected</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="All_reports?status=All&date=<?php echo date('Y-m-d') . ' - ' . date('Y-m-d'); ?>&fy=2024/2025" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>All reports</p>
							</a>
						</li>
					</ul>
				</li>

				<!-- Logout -->
				<li class="nav-item">
					<a class="nav-link" data-toggle="modal" data-target="#end_session" href="">
						<i class="nav-icon fas fa-power-off text-success"></i>
						<p>
							Logout
						</p>
					</a>
				</li>

				<!-- 
                    <li class="nav-item">
                        <a href="ward_revenue_target" class="nav-link">
						<i class="nav-icon fas fa-file-invoice-dollar text-success"></i>
                            <p>
                                Ward Targets
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="staff_annual_target" class="nav-link">
						<i class="nav-icon fas fa-file-invoice-dollar text-success"></i>
                            <p>
                                Staff Targets
                            </p>
                        </a>
                    </li> -->
				<!-- <li class="nav-item">
                        <a href="annual_ward_target" class="nav-link">
                            <i class="nav-icon fas fa-columns"></i>
                            <p>
                                ward Annual Target
                            </p>
                        </a>
                    </li> -->
				<!-- <li class="nav-item">
                        <a href="staff_monthly_targets" class="nav-link">
                            <i class="nav-icon fas fa-columns"></i>
                            <p>
                                Monthly Target
                            </p>
                        </a>
                    </li> -->
				<!-- <li class="nav-item">
                        <a href="annual_ward_target" class="nav-link">
                            <i class="nav-icon fas fa-columns"></i>
                            <p>
                                staff Target
                            </p>
                        </a>
                    </li> -->
				<!-- <li class="nav-item">
                        <a href="ward_staff" class="nav-link">
						<i class="nav-icon fas fa-file-invoice-dollar text-success"></i>
                            <p>
                                Staff
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="All_reports" class="nav-link">
						<i class="nav-icon fas fa-file-invoice-dollar text-success"></i>
                            <p>
                                Reports
                            </p>
                        </a>
                    </li>   -->
				<!-- <li class="nav-item">
                        <a href="approved_reports" class="nav-link">
                            <i class="nav-icon fas fa-columns"></i>
                            <p>
                                Approved Reports
                            </p>
                        </a>
                    </li>  
                    <li class="nav-item">
                        <a href="pending_approvals" class="nav-link">
                            <i class="nav-icon fas fa-columns"></i>
                            <p>
                                Pending Reports
								<span class="badge badge-info right">1</span>
                            </p>
                        </a>
                    </li>  
                    <li class="nav-item">
                        <a href="rejected_reports" class="nav-link">
                            <i class="nav-icon fas fa-columns"></i>
                            <p>
                                Rejected Reports
								<span class="badge badge-info right">5</span>
                            </p>
                        </a>
                    </li>   -->

			</ul>
		</nav>
		<!-- /.sidebar-menu -->
	</div>
	<!-- /.sidebar -->
</aside>