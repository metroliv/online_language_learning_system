<aside class="main-sidebar sidebar-light-primary elevation-4" style="background-color: #ffffff ;">
    <!-- Brand Logo -->
    <a href="dashboard" class="brand-link text-center">
        <img src="../public/img/merged_logos.png" alt="Brand Logo" class="" style="width: 150px; height: auto; opacity: .9;">
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center border-bottom">
            <div class="image">
                <img src="<?php echo isset($_SESSION['user_image']) ? $_SESSION['user_image'] : '../public/img/avatar5.png'; ?>" 
                     class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info ml-3">
                <a href="#" class="d-block text-dark font-weight-bold">
                    <?php echo $_SESSION['user_names']; ?><br />
                    <span class="badge badge-success mt-1"><?php echo $_SESSION['user_access_level']; ?></span>
                </a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="dashboard" class="nav-link">
                        <i class="nav-icon fas fa-tachometer-alt text-primary"></i>
                        <p class="text-dark font-weight-medium">Dashboard</p>
                    </a>
                </li>
                <!-- Collections -->
                <li class="nav-item">
                    <a href="collection" class="nav-link">
                        <i class="nav-icon fas fa-file-invoice-dollar text-success"></i>
                        <p class="text-dark font-weight-medium">Register Collections</p>
                    </a>
                </li>
                <!-- Rejected Collections -->
                <li class="nav-item">
                    <a href="rejected_collections" class="nav-link">
                        <i class="nav-icon fas fa-times-circle text-danger"></i>
                        <p class="text-dark font-weight-medium">Rejected Collections</p>
                    </a>
                </li>
                <!-- Approved Collections -->
                <li class="nav-item">
                    <a href="approved_collections" class="nav-link">
                        <i class="nav-icon fas fa-check-circle text-success"></i>
                        <p class="text-dark font-weight-medium">Approved Collections</p>
                    </a>
                </li>
                <!-- Reporting -->
                <li class="nav-item">
                    <a href="performance.php" class="nav-link">
                        <i class="nav-icon fas fa-chart-bar text-info"></i>
                        <p class="text-dark font-weight-medium">Ward Performance</p>
                    </a>
                </li>
				<!-- Logout -->
				<li class="nav-item">					
					<a class="nav-link" data-toggle="modal" data-target="#end_session" href="">
						<i class="nav-icon fas fa-power-off text-success"></i>
						<p>
							Logout
						</p>
					</a>
				</li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
