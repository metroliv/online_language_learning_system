<?php
// Get the current page's file name to use for setting the active state
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4" style="background-color: #124491 ">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <img src="../public/img/merged_logos.png" alt="Logo" class="brand-image">
        <span class="brand-text font-weight-light">GoMC</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="../public/img/avatar5.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">
                    <?php echo $_SESSION['user_names']; ?>
                    <br />
                    <?php echo $_SESSION['user_access_level']; ?>
                </a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="../views/dashboard.php" class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-tachometer-alt text-success"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <!-- Total Revenue Collected -->
                <li class="nav-item">
                    <a href="../views/total_revenue.php" class="nav-link <?php echo ($current_page == 'total_revenue.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-coins text-success" ></i>
                        <p>Revenue Trend</p>
                    </a>
                </li>
                <!-- Stream Performance Analysis -->
                <li class="nav-item">
                    <a href="../views/stream_analysis.php" class="nav-link <?php echo ($current_page == 'stream_analysis.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-chart-pie text-success"></i>
                        <p>Stream Performance</p>
                    </a>
                </li>

                <!-- Champions Section -->
                <li class="nav-item" style="display:none">
                    <a href="#" class="nav-link <?php echo (in_array($current_page, ['top_officer.php', 'top_streams.php'])) ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-trophy text-success"></i>
                        <p>Champions</p>
                    </a>
                </li>

                <!-- Top Officers -->
                <li class="nav-item">
                    <a href="../views/top_officer.php" class="nav-link <?php echo ($current_page == 'top_officer.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-user-tie text-success"></i>
                        <p>Top Officers</p>
                    </a>
                </li>

                <!-- Top Streams -->
                <li class="nav-item">
                    <a href="../views/top_streams.php" class="nav-link <?php echo ($current_page == 'top_streams.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-stream text-success"></i>
                        <p>Top Streams</p>
                    </a>
                </li>

                <!-- Reports -->
                <li class="nav-item">
                    <a href="../views/report_perfomance.php" class="nav-link <?php echo ($current_page == 'report_perfomance.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-file-alt text-success"></i>
                        <p>Reports</p>
                    </a>
                </li>

                <!-- Collector Imprests -->
                <li class="nav-item">
                    <a href="../views/collector_imprests.php" class="nav-link <?php echo ($current_page == 'collector_imprests.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-wallet text-success"></i>
                        <p>Collector Imprests</p>
                    </a>
                </li>

                <!-- Ward Performance Overview -->
                <li class="nav-item">
                    <a href="../views/ward_overview.php" class="nav-link <?php echo ($current_page == 'ward_overview.php') ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-medal text-success"></i>
                        <p>Ward Performance</p>
                    </a>
                </li>
				<!-- Logout -->
				<li class="nav-item">					
					<a class="nav-link" data-toggle="modal" data-target="#end_session" href="">
						<i class="nav-icon fas fa-power-off text-success"></i>
						<p>
							Logout
						</p>
					</a>
				</li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
