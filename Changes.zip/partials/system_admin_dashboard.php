<?php
require('../config/config.php');
require('../functions/system_admin_analytics.php');


?>
<!-- Main content -->
<section class="content">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">
						<?php echo $greeting . ', ' . $_SESSION['user_names'] ?>
					</h1>
					<small>Welcome to Department of Finance Revenue Collection Tool</small>

					<h2 class="mt-2 text-dark">
						<?php
						if ($annual) {
							// echo '2024/2025 FY';
							echo '2024/2025 FY';
						} else {
							$trimonth = trim($months, "'");
							$monthWithoutZero = (int)$trimonth; // This will be 8

							echo $myMonths[$monthWithoutZero] . ', 2024';
						}

						?>
					</h2>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="dashboard">Home</a></li>
						<li class="breadcrumb-item active">Dashboard</li>
					</ol>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>

	<!-- filters -->
	<div class="container-fluid pb-2">
		<!-- <div class="col-md-3 col-sm-3 col-3"> -->
		<div class="text-right">
			<a data-toggle="modal" data-target="#filterDashboard"><button type="button" class="btn btn-outline-success btn-sm">filter</button></a>
		</div>
		<!-- </div> -->
	</div>
	<!-- ./ filters -->

	<div class="container-fluid">
		<!-- Small boxes (Stat box) -->

		<!-- /.row -->
		<div class="row">
			<div class="col-md-4 col-sm-6 col-12">
				<a href="revenue_target?month=<?php echo $months?>&fy=<?php echo $fy?>" class="text-dark" style="text-decoration: none">
					<div class="info-box">
						<span class="info-box-icon" style="background: #ffcd3d"><i class="far fa-flag"></i></span>

						<div class="info-box-content">
							<span class="info-box-text">Targets</span>
							<span class="info-box-number">
								<?php
								if ($annual) {
									echo 'Ksh. ' . number_format($annaulTarget);
								} else {
									echo 'Ksh. ' . number_format($monthTarget);
								}
								?>
							</span>
						</div>
						<!-- /.info-box-content -->
					</div>
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-4 col-sm-6 col-12">
				<a href="revenue_collected?month=<?php echo $months?>&fy=<?php echo $fy?>" class="text-dark" style="text-decoration: none">
					<div class="info-box">
						<span class="info-box-icon" style="background: #ffcd3d"><i class="fas fa-wallet"></i></span>

						<div class="info-box-content">
							<span class="info-box-text">Collections</span>
							<span class="info-box-number">Ksh. <?php echo number_format($countyCollections, 2) ?></span>
						</div>
						<!-- /.info-box-content -->
					</div>
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-4 col-sm-6 col-12">
				<a href="target_achieved?month=<?php echo $months?>&fy=<?php echo $fy?>" class="text-dark" style="text-decoration: none">
					<div class="info-box">
						<span class="info-box-icon" style="background: #ffcd3d"><i class="fas fa-percent"></i></span>

						<div class="info-box-content">
							<span class="info-box-text">Target Achieved</span>
							<span class="info-box-number">
								<?php
								if ($annual) {
									echo floor($annualTargetAchieved) . '%';
								} else {
									echo floor($mothlyTargetAchieved) . '%';
								}
								?>
							</span>
						</div>
						<!-- /.info-box-content -->
					</div>
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->

			<!-- /.col -->
		</div>
		<!-- /.row -->

		<!-- Main row -->
		<!-- /.row (main row) -->
	</div>
	<!-- /.container-fluid -->

	<!-- Bar graph -->
	<div class="row">
		<div class="col-12 d-none">
			<!-- Bar chart -->
			<div class="card card-primary card-outline">
				<div class="card-header">
					<h3 class="card-title">
						<i class="far fa-chart-bar"></i>
						Revenue collections per month
					</h3>
				</div>
				<div class="card-body">
					<div id="bar-chart" style="height: 300px;"></div>
				</div>
				<!-- /.card-body-->
			</div>

		</div>

		<!-- Logs -->
		<div class="col-12 col-sm-12 col-md-12">
			<div class="card">
				<div class="card-header">
					<h5 class="card-title m-0">Today, <?php echo date('d M Y'); ?> Authenitcation Logs</h5>
				</div>
				<!-- /.card-header -->
				<div class="card-body">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>#</th>
								<th>User </th>
								<th>IP Address</th>
								<th>Device</th>
								<th>Time</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$today = date('Y-m-d');
							$tomorrow = date('Y-m-d', strtotime('tomorrow'));
							$fetch_records_sql = mysqli_query(
								$mysqli,
								"SELECT * FROM logs l
							INNER JOIN users u ON u.user_id = l.log_user_id
							WHERE u.user_id = '{$user_id}' AND
							l.log_date BETWEEN '{$today}' AND '{$tomorrow}' ORDER BY l.log_id DESC"
							);
							$cnt = 1;
							if (mysqli_num_rows($fetch_records_sql) > 0) {
								while ($return_results = mysqli_fetch_array($fetch_records_sql)) {
							?>
									<tr>
										<td><?php echo $cnt; ?></td>
										<td><?php echo $return_results['user_names']; ?></td>
										<td><?php echo $return_results['log_ip_address']; ?></td>
										<td><?php echo $return_results['log_device']; ?></td>
										<td><?php echo date('g:ia', strtotime($return_results['log_date'])); ?></td>
									</tr>
							<?php
									$cnt = $cnt + 1;
								}
							} ?>

						</tbody>
					</table>
				</div>
				<!-- /.card-body -->
			</div>
			<!-- /.card -->
		</div>
		<!-- /.col -->
	</div>

</section>
<!-- /.content -->

<section class="content d-none">
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h1>Flot Charts</h1>
					</div>
					<div class="col-sm-6">
						<ol class="breadcrumb float-sm-right">
							<li class="breadcrumb-item"><a href="#">Home</a></li>
							<li class="breadcrumb-item active">Flot</li>
						</ol>
					</div>
				</div>
			</div><!-- /.container-fluid -->
		</section>

		<!-- Main content -->
		<section class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-12">
						<!-- interactive chart -->
						<div class="card card-primary card-outline">
							<div class="card-header">
								<h3 class="card-title">
									<i class="far fa-chart-bar"></i>
									Interactive Area Chart
								</h3>

								<div class="card-tools">
									Real time
									<div class="btn-group" id="realtime" data-toggle="btn-toggle">
										<button type="button" class="btn btn-default btn-sm active" data-toggle="on">On</button>
										<button type="button" class="btn btn-default btn-sm" data-toggle="off">Off</button>
									</div>
								</div>
							</div>
							<div class="card-body">
								<div id="interactive" style="height: 300px;"></div>
							</div>
							<!-- /.card-body-->
						</div>
						<!-- /.card -->

					</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->

				<div class="row">
					<div class="col-md-6">
						<!-- Line chart -->
						<div class="card card-primary card-outline">
							<div class="card-header">
								<h3 class="card-title">
									<i class="far fa-chart-bar"></i>
									Line Chart
								</h3>

								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
									<button type="button" class="btn btn-tool" data-card-widget="remove">
										<i class="fas fa-times"></i>
									</button>
								</div>
							</div>
							<div class="card-body">
								<div id="line-chart" style="height: 300px;"></div>
							</div>
							<!-- /.card-body-->
						</div>
						<!-- /.card -->

						<!-- Area chart -->
						<div class="card card-primary card-outline">
							<div class="card-header">
								<h3 class="card-title">
									<i class="far fa-chart-bar"></i>
									Area Chart
								</h3>

								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
										<i class="fas fa-minus"></i>
									</button>
									<button type="button" class="btn btn-tool" data-card-widget="remove">
										<i class="fas fa-times"></i>
									</button>
								</div>
							</div>
							<div class="card-body">
								<div id="area-chart" style="height: 338px;" class="full-width-chart"></div>
							</div>
							<!-- /.card-body-->
						</div>
						<!-- /.card -->

					</div>
					<!-- /.col -->

					<!-- Donut chart -->
					<div class="card card-primary card-outline">
						<div class="card-header">
							<h3 class="card-title">
								<i class="far fa-chart-bar"></i>
								Donut Chart
							</h3>

							<div class="card-tools">
								<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
								</button>
								<button type="button" class="btn btn-tool" data-card-widget="remove">
									<i class="fas fa-times"></i>
								</button>
							</div>
						</div>
						<div class="card-body">
							<div id="donut-chart" style="height: 300px;"></div>
						</div>
						<!-- /.card-body-->
					</div>
					<!-- /.card -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
	</div><!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
</section>

<!-- filters modal-->
<div class="modal fade fixed-right" id="filterDashboard" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header align-items-center">
				<div class="text-center">
					<h6 class="mb-0 text-bold">Filter</h6>
				</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					<div class="row">
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Month <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<select type="text" required name="month" class="form-control">
									<option value="">Select</option>
									<option value="all">All Months</option>
									<option value="1">January</option>
									<option value="2">February</option>
									<option value="3">March</option>
									<option value="4">April</option>
									<option value="5">May</option>
									<option value="6">June</option>
									<option value="7">July</option>
									<option value="8">August</option>
									<option value="9">September</option>
									<option value="10">October</option>
									<option value="11">November</option>
									<option value="12">December</option>

								</select>
							</div>
						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<select type="text" required name="fy" class="form-control">
									<option value="2024/2025">2024/2025</option>

								</select>
							</div>
						</div>

					</div>
					<div class="text-right">
						<button type="submit" name="Dashboadfiters" class="btn btn-outline-success">Search</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- ./ filters -->