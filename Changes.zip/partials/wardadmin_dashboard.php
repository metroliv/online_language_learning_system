<?php
require('../config/config.php');
include_once('../functions/reciever_analytics.php');

/**
 *  Bar chart data
 * @var mixed
 */

/**
 *  Bar chart data
 * @var mixed
 */

// $rev_streams = [];
// $rev_targets = [];
// $rev_collections = [];

// $fetch_records_sql = mysqli_query(
// 	$mysqli,
// 	"SELECT * FROM streamtarget st 
// 	INNER JOIN revenue_streams rs ON rs.stream_id = st.streamtarget_stream_id 
// 	WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
// 	"

// );
// if (mysqli_num_rows($fetch_records_sql) > 0) {
// 	$cnt =  1;

// 	while ($rows = mysqli_fetch_array($fetch_records_sql)) {
// 		//dd($rows);
// 		array_push($rev_streams, $rows['stream_name']);
// 		if ($annual) {
// 			array_push($rev_targets, $rows['streamtarget_amount']);
// 		} else {
// 			$month_target = floor($rows['streamtarget_amount'] / 12);
// 			array_push($rev_targets, $month_target);
// 		}


// 		$query = "SELECT SUM(collection_amount) FROM revenue_collections 
// 		WHERE collection_ward_id = '{$_SESSION['user_ward_id']}'
// 		AND collection_stream_id = '{$rows['streamtarget_stream_id']}'
// 		AND MONTH(collection_date) IN ({$months})";
// 		$stmt = $mysqli->prepare($query);
// 		$stmt->execute();
// 		$stmt->bind_result($stream_collections);
// 		$stmt->fetch();
// 		$stmt->close();


// 		if ($stream_collections > 0) {
// 			array_push($rev_collections, $stream_collections);
// 		} else {
// 			array_push($rev_collections, 0);
// 		};
// 	}
// }
// dd(json_encode($rev_collections));


// /** user ward name */
// $ward_name = selectItem('ward', 'ward_name', ['ward_id' => $_SESSION['user_ward_id']]);

// /** ward Target */
// //monthly
// $query = "SELECT SUM(streamtarget_amount) FROM streamtarget 
// WHERE streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
// AND streamtarget_fy = '{$fy}'
// ";
// $stmt = $mysqli->prepare($query);
// $stmt->execute();
// $stmt->bind_result($wardAnnaulTarget);
// $stmt->fetch();
// $stmt->close();



// //anual
// $wardMonthlyTarget = floor($wardAnnaulTarget / 12);

// /** Collection */
// $query = "SELECT SUM(collection_amount) FROM revenue_collections 
// WHERE collection_ward_id = '{$_SESSION['user_ward_id']}' 
// AND collection_status = 'Approved' 
// AND MONTH(collection_date) IN ({$months})
// ";
// $stmt = $mysqli->prepare($query);
// $stmt->execute();
// $stmt->bind_result($collections_total);
// $stmt->fetch();
// $stmt->close();


// /** % Achievement */
// //monthly
// if ($wardMonthlyTarget > 0) {
// 	$mothlyAchievments = ($collections_total * 100) / $wardMonthlyTarget;
// 	$annualAchievments = ($collections_total * 100) / $wardAnnaulTarget;
// } else {
// 	$mothlyAchievments = 0;
// 	$annualAchievments = 0;
// }

// /** number of collectors per ward */
// $query = "SELECT COUNT(user_id) FROM users 
// WHERE user_ward_id = '{$_SESSION['user_ward_id']}'
// AND user_access_level = 'Revenue Collector'
// ";
// $stmt = $mysqli->prepare($query);
// $stmt->execute();
// $stmt->bind_result($collectorNo);
// $stmt->fetch();
// $stmt->close();

// /** Annual collector target */
// $collectorTarget = floor($wardAnnaulTarget / $collectorNo);

// /** Monthly collector target */
// $collectorTargetMonth = floor($collectorTarget / 12);


// /** pending Approvals */
// $query = "SELECT count(collection_status) FROM revenue_collections 
// WHERE collection_status = 'Pending' 
// AND collection_ward_id = '{$_SESSION['user_ward_id']}' 
// ";
// // AND collection_fy = '2024/2025'

// // AND DATE_FORMAT(collection_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m');";
// $stmt = $mysqli->prepare($query);
// $stmt->execute();
// $stmt->bind_result($pending_approvals);
// $stmt->fetch();
// $stmt->close();



?>

<!-- Main content -->
<section class="content">
	<!-- Content Header (Page header) -->
	<div class="content-header">
		<div class="">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1 class="m-0 text-dark">
						<?php
						echo $ward_name['ward_name'] . ' Ward. ';
						if ($annual) {
							echo '2024/2025 FY';
						} else {
							$trimonth = trim($months, "'");
							$monthWithoutZero = (int)$trimonth; // This will be 8
							// echo $months;
							// echo $monthWithoutZero;
							echo $myMonths[$monthWithoutZero] . ', 2024';
						}

						?>
						<?php $greeting . ', ' . $_SESSION['user_names'] ?>
					</h1>
					<small>Department of Finance Revenue Collection Tool</small>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="dashboard">Home</a></li>
						<li class="breadcrumb-item active">Dashboard</li>
					</ol>
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->
	</div>

	<!-- filters -->
	<div class="container-fluid">
		<!-- <div class="col-md-3 col-sm-3 col-3"> -->
		<div class="text-right">
			<a data-toggle="modal" data-target="#filterDashboard"><button type="button" class="btn btn-outline-success btn-sm">Filter</button></a>
		</div>
		<!-- </div> -->
	</div>
	<!-- ./ filters -->

	<!-- widgets -->
	<div class="container-fluid mt-4">
		<div class="row">
			<div class="col-md-4 col-sm-6 col-12">
				<a href="ward_revenue_target" class="text-dark">
					<!-- <a href="ward_revenue_target?month=<?php $months ?>&fy=2024/2025" class="text-dark"> -->
					<div class="info-box">
						<span class="info-box-icon" style="background: #ffcd3d"><i class="far fa-flag"></i></span>

						<div class="info-box-content">
							<span class="info-box-text">Target</span>
							<span class="info-box-number">
								<?php
								if ($annual) {
									echo 'KSH ' . number_format($wardAnnaulTarget);
								} else {
									echo 'KSH ' . number_format($wardMonthlyTarget, 2);
								}
								?>
							</span>
						</div>
						<!-- /.info-box-content -->
					</div>
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-4 col-sm-6 col-12">
				<!-- <a href="ward_revenue_target" class="text-dark"> -->
				<!-- <a href="ward_collections?month=<?php $months ?>&fy=2024/2025" class="text-dark"> -->
				<a href="ward_collections" class="text-dark">

					<div class="info-box">
						<span class="info-box-icon" style="background: #ffcd3d"><i class="fas fa-wallet"></i></span>

						<div class="info-box-content">
							<span class="info-box-text">Collections</span>
							<span class="info-box-number">
								<?php
								if ($collections_total >= 1) {
									echo 'Ksh. ' . number_format($collections_total);
								} else {
									echo 'Ksh. 0';
								}
								?>
							</span>
						</div>
						<!-- /.info-box-content -->
					</div>
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-4 col-sm-6 col-12">
				<!-- <a href="ward_revenue_target" class="text-dark"> -->
				<!-- <a href="ward_performance?month=<?php $months ?>&fy=2024/2025" class="text-dark"> -->
				<a href="ward_performance" class="text-dark">

					<div class="info-box">
						<span class="info-box-icon" style="background: #ffcd3d"><i class="fas fa-percent"></i></span>

						<div class="info-box-content">
							<span class="info-box-text">Target Achieved</span>
							<span class="info-box-number">
								<?php
								if ($annual) {
									echo floor($annualAchievments) . '%';
								} else {
									echo floor($mothlyAchievments) . '%';
								}
								?>
							</span>
						</div>
						<!-- /.info-box-content -->
					</div>
				</a>
				<!-- /.info-box -->
			</div>
		</div>
	</div>
	<!-- ./widgets -->

	<!-- staff peformance -->
	<div class="col-lg-12 d-none">
		<div class="card card-primary card-outline">
			<div class="card-header">
				<h3 class="card-title">
					Staff Performance
				</h3>
			</div>

			<!-- /.card-header -->
			<div class="card-body">
				<table id="example1" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th style="width: 10px">#</th>
							<th>name</th>
							<th>Target</th>
							<th>Collections</th>
							<th>Target Achieved</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$fetch_records_sql = mysqli_query(
							$mysqli,

							"SELECT * FROM users u 
											WHERE user_access_level = 'Revenue Collector'
											AND user_ward_id = '{$_SESSION['user_ward_id']}'
											"
							// JOIN collectortarget ct ON u.user_id = ct.collectortarget_user_id
							// AND	ct.collectortarget_ward_id = 2}'
							// "SELECT * FROM collectortarget  ct 
							// INNER JOIN streamtarget st ON ct.collectortarget_streamtarget_id  = st.streamtarget_id 
							// INNER JOIN revenue_streams rs ON rs.stream_id = st.streamtarget_stream_id 
							// INNER JOIN users s ON ct.collectortarget_user_id = s.user_id 
							// WHERE st.streamtarget_ward_id = 's.user_ward_id'
							// "	
						);
						if (mysqli_num_rows($fetch_records_sql) > 0) {
							$cnt =  1;
							while ($rows = mysqli_fetch_array($fetch_records_sql)) {
						?>
								<tr>
									<td>
										<?php echo $cnt; ?>
									</td>

									<td>
										<a href="staff_stream_performance?id=<?php echo $rows['user_id'] ?>">
											<?php echo $rows['user_names']; ?>
										</a>
									</td>

									<td>
										<?php
										if ($annual) {
											echo 'Ksh. ' . number_format($collectorTarget);
										} else {
											echo 'Ksh. ' . number_format($collectorTargetMonth);
										}
										// $query = "SELECT SUM(streamtarget_amount) FROM  streamtarget st
										// WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
										// AND st.streamtarget_fy = '2024/2025'
										// ";
										// $stmt = $mysqli->prepare($query);
										// $stmt->execute();
										// $stmt->bind_result($streamTargetAmounts);
										// $stmt->fetch();
										// $stmt->close();

										// $myTargets = $streamTargetAmounts/$collectorNo;
										// echo floor($myTargets);

										/** Total annual Target*/
										// $query = "SELECT SUM(collectortarget_amount ) FROM collectortarget 
										// WHERE collectortarget_user_id = '{$rows['user_id']}'";
										// $stmt = $mysqli->prepare($query);
										// $stmt->execute();
										// $stmt->bind_result($annualTargets);
										// $stmt->fetch();
										// $stmt->close();
										// if($annualTargets>0){
										// 	$monthTarget = $annualTargets/12;
										// }else{
										// 	$monthTarget = 0;
										// }
										// echo floor($annualTargets);
										?>
									</td>

									<td>
										<?php
										$query = "SELECT SUM(collection_amount) FROM revenue_collections 
														WHERE collection_ward_id = '{$_SESSION['user_ward_id']}'
														AND collection_user_id = '{$rows['user_id']}'
														AND collection_status = 'Approved' 
														AND MONTH(collection_date) IN ({$months})
														";

										$stmt = $mysqli->prepare($query);
										$stmt->execute();
										$stmt->bind_result($stream_collections);
										$stmt->fetch();
										$stmt->close();

										if ($stream_collections >= 1) {
											echo 'Ksh. ' . number_format($stream_collections);
										} else {
											echo 'Ksh. 0';
										};
										?>
									</td>
									<td>
										<?php
										$achiedPercentage = ($stream_collections * 100);
										if ($collectorTarget > 0) {
											if ($annual) {
												echo floor($achiedPercentage / $collectorTarget) . '%';
											} else {
												echo floor($achiedPercentage / $collectorTargetMonth) . '%';
											}
										} else {
											echo '0%';
										}
										?>
										<!-- </td>                                                    -->
										<!-- <td>
                                                        <a data-toggle="modal" href="monthly_ward_targets" class="badge badge-primary"><i class="fas fa-eye"></i> View </a>
                                                        
                                                    </td> -->

								</tr>
						<?php
								$cnt = $cnt + 1;
								// include('../modals/users.php');
							}
						} ?>
					</tbody>

					</tbody>
				</table>
			</div>
			<!-- /.card-body -->
		</div>
		<!-- /.card -->
	</div>
</section>

<!-- filters modal-->
<div class="modal fade fixed-right" id="filterDashboard" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header align-items-center">
				<div class="text-center">
					<h6 class="mb-0 text-bold">Filter</h6>
				</div>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
					<div class="row">
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Month <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<select type="text" required name="month" class="form-control">
									<option value="">Select</option>
									<option value="all">All Months</option>
									<option value="1">January</option>
									<option value="2">February</option>
									<option value="3">March</option>
									<option value="4">April</option>
									<option value="5">May</option>
									<option value="6">June</option>
									<option value="7">July</option>
									<option value="8">August</option>
									<option value="9">September</option>
									<option value="10">October</option>
									<option value="11">November</option>
									<option value="12">December</option>

								</select>
							</div>
						</div>
						<div class="form-group col-sm-6 col-lg-6 col-xl-6">
							<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
							<div class="input-group input-group-merge">
								<select type="text" required name="fy" class="form-control">
									<option value="2024/2025">2024/2025</option>

								</select>
							</div>
						</div>

					</div>
					<div class="text-right">
						<button type="submit" name="Dashboadfiters" class="btn btn-outline-success">Search</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Add user modal -->

<!-- Main content -->
<section class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<!-- LINE CHART -->
				<div class="card card-info d-none">
					<div class="card-header">
						<h3 class="card-title">Line Chart</h3>

						<div class="card-tools">
							<button type="button" class="btn btn-tool" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							</button>
							<button type="button" class="btn btn-tool" data-card-widget="remove">
								<i class="fas fa-times"></i>
							</button>
						</div>
					</div>
					<div class="card-body">
						<div class="chart">
							<canvas id="lineChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->

				<!-- BAR CHART -->
				<div class="card card-success">
					<div class="card-header">
						<h3 class="card-title">Ward Performance</h3>

						<div class="card-tools">
							<button type="button" class="btn btn-tool" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							</button>
							<button type="button" class="btn btn-tool" data-card-widget="remove">
								<i class="fas fa-times"></i>
							</button>
						</div>
					</div>
					<div class="card-body">
						<div class="chart">
							<canvas id="barChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->

				<!-- STACKED BAR CHART -->
				<div class="card card-success d-none">
					<div class="card-header">
						<h3 class="card-title">Stacked Bar Chart</h3>

						<div class="card-tools">
							<button type="button" class="btn btn-tool" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							</button>
							<button type="button" class="btn btn-tool" data-card-widget="remove">
								<i class="fas fa-times"></i>
							</button>
						</div>
					</div>
					<div class="card-body">
						<div class="chart">
							<canvas id="stackedBarChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->

			</div>
			<!-- /.col (RIGHT) -->
			<div class="col-md-12">
				<!-- AREA CHART -->
				<div class="card card-primary d-none">
					<div class="card-header">
						<h3 class="card-title">Area Chart</h3>

						<div class="card-tools">
							<button type="button" class="btn btn-tool" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							</button>
							<button type="button" class="btn btn-tool" data-card-widget="remove">
								<i class="fas fa-times"></i>
							</button>
						</div>
					</div>
					<div class="card-body">
						<div class="chart">
							<canvas id="areaChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->

				<!-- DONUT CHART -->
				<div class="card card-danger d-none">
					<div class="card-header">
						<h3 class="card-title">Stream performance</h3>

						<div class="card-tools">
							<button type="button" class="btn btn-tool" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							</button>
							<button type="button" class="btn btn-tool" data-card-widget="remove">
								<i class="fas fa-times"></i>
							</button>
						</div>
					</div>
					<div class="card-body">
						<canvas id="donutChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->


			</div>
			<!-- /.col (LEFT) -->

			<div class="col-md-12">
				<!-- PIE CHART -->
				<div class="card card-success">
					<div class="card-header">
						<h3 class="card-title">Staff perfomance</h3>

						<div class="card-tools">
							<button type="button" class="btn btn-tool" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							</button>
							<button type="button" class="btn btn-tool" data-card-widget="remove">
								<i class="fas fa-times"></i>
							</button>
						</div>
					</div>
					<div class="card-body">
						<canvas id="pieChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->

			</div>

		</div>
		<!-- /.row -->
	</div><!-- /.container-fluid -->
</section>
<!-- /.content -->

<!-- progress bars -->
<section class="content">
	<div class="container-fluid">
		<!-- start progess bars -->
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header bg-success">
						<h3 class="card-title">Stream Performance</h3>
					</div>
					<!-- /.card-header -->
					<div class="row">
						<?php
						$fetch_records_sql = mysqli_query(
							$mysqli,
							"SELECT * FROM streamtarget st 
									INNER JOIN revenue_streams rs ON rs.stream_id = st.streamtarget_stream_id 
									WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
									AND st.streamtarget_fy = '2024/2025'
									"

						);
						if (mysqli_num_rows($fetch_records_sql) > 0) {
							$cnt =  1;
							while ($rows = mysqli_fetch_array($fetch_records_sql)) {
								/** Total collections */
								$query = "SELECT SUM(collection_amount) FROM revenue_collections 
										WHERE collection_ward_id = '{$_SESSION['user_ward_id']}'
										AND collection_stream_id = '{$rows['streamtarget_stream_id']}'
										AND collection_status = 'Approved' 
										AND MONTH(collection_date) IN ({$months})
										";
								$stmt = $mysqli->prepare($query);
								$stmt->execute();
								$stmt->bind_result($stream_collections);
								$stmt->fetch();
								$stmt->close();

								if ($annual) {
									$achieved = ($stream_collections * 100) / $rows['streamtarget_amount'];
								} else {
									$achieved = ($stream_collections * 100) / ($rows['streamtarget_amount'] / 12);
								}

						?>
								<div class="col-md-6">
									<div class="card-body">
										<label><?php echo $rows['stream_name'] ?></label>
										<div class="progress custom-margin">
											<div class="progress-bar bg-primary" role="progressbar" aria-valuenow="40" aria-valuemin="0"
												aria-valuemax="100" style="width: <?php echo $achieved . '%'; ?>">
												<span class=""><?php echo $achieved; ?>% Complete</span>
											</div>
										</div>
									</div>
									<!-- /.card-body -->
								</div>
						<?php
								$cnt = $cnt + 1;
							}
						} ?>

					</div>
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col (left) -->

		</div>

		<!-- END PROGRESS BARS -->
	</div>
</section>