<?php
/*
 *   Crafted On Fri 3rd Aug 2024
 *   Author stephen ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
require('../config/config.php');

/** user ward name */
$ward_name = selectItem('ward', 'ward_name', ['ward_id'=>$_SESSION['user_ward_id']]);

/** Ward annual target */
$query = "SELECT SUM(streamtarget_amount) FROM streamtarget 
WHERE streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
AND streamtarget_fy = '2024/2025'
";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($wardAnnualTarget);
$stmt->fetch();
$stmt->close();

$wardMonthlyTarget = $wardAnnualTarget/12;

/** Number of collectors per ward */
$query = "SELECT SUM(user_id) FROM users 
WHERE user_ward_id = '{$_SESSION['user_ward_id']}'
AND user_access_level = 'Revenue Collector'
";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($numberofCollectors);
$stmt->fetch();
$stmt->close();


/** Imprest */
$annualImperest = selectOne('imprest', ['imprest_fy' => '2024/2025' ]);
$colectorTarget = $wardAnnualTarget / $numberofCollectors;
if($colectorTarget>0){
	$imprest = $annualImperest['imprest_amount'] / $colectorTarget;
}else{
	$imprest = 0;
}



// $monthly_target = 1000000;
// /** Revenue target */
// $revenue_targets = selectOne('revenue_targets', ['target_ward_id'=>$_SESSION['user_ward_id']]);
// $annual_target = $revenue_targets['target_amount'];
// $monthly_target = $revenue_targets['target_amount'] / 12;


/** Total monthly collections */
$query = "SELECT SUM(collection_amount) FROM revenue_collections 
WHERE collection_ward_id = '{$_SESSION['user_ward_id']}' 
AND DATE_FORMAT(collection_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m');";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($monthly_collections);
$stmt->fetch();
$stmt->close();

/** Total Ward Annual collections */
$query = "SELECT SUM(collection_amount) FROM revenue_collections 
WHERE collection_ward_id = '{$_SESSION['user_ward_id']}'";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($annual_collections);
$stmt->fetch();
$stmt->close();

/** Monthly % revenue target achieved */
if($wardMonthlyTarget>0){
	$percentage_target = ($monthly_collections*100) / $wardMonthlyTarget;
}else{
	$percentage_target = 0;
}

/** Annual % revenue target achieved */
if($wardAnnualTarget>0){
	$percentage_annual = ($annual_collections*100) / $wardAnnualTarget;
}else{
	$percentage_annual = 0;
}


/** pending Approvals */
$query = "SELECT count(collection_status) FROM revenue_collections WHERE collection_status = 'Pending' AND DATE_FORMAT(collection_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m');";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($pending_approvals);
$stmt->fetch();
$stmt->close();