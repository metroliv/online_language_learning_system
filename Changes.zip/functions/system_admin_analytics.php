<?php 


/** user ward name */
// $ward_name = selectItem('ward', 'ward_name', ['ward_id'=>$_SESSION['user_ward_id']]);

/** county Targets */
	//annual
	$query = "SELECT SUM(streamtarget_amount) FROM streamtarget 
	WHERE streamtarget_fy = '2024/2025'
	";
	$stmt = $mysqli->prepare($query);
	$stmt->execute();
	$stmt->bind_result($annaulTarget);
	$stmt->fetch();
	$stmt->close();

	if($annaulTarget<1){
		$annaulTarget = 0;
	}

	//monthly
	$monthTarget = $annaulTarget/12;

/** county Collection */
	$query = "SELECT SUM(collection_amount) FROM revenue_collections 
	WHERE collection_status = 'Approved' 
	AND MONTH(collection_date) IN ({$months})
	";
	$stmt = $mysqli->prepare($query);
	$stmt->execute();
	$stmt->bind_result($countyCollections);
	$stmt->fetch();
	$stmt->close();

	if($countyCollections< 1){
		$countyCollections = 0;
	}	


/** county % Achievement */
	if($monthTarget>0){
		$mothlyTargetAchieved = ($countyCollections*100)/$monthTarget;
		$annualTargetAchieved = ($countyCollections*100)/$annaulTarget;
	}else{
		$mothlyTargetAchieved = 0;
		$annualTargetAchieved = 0;
	}

	// Array mapping month numbers to month names
$myMonths = [
	1 => 'January',
	2 => 'February',
	3 => 'March',
	4 => 'April',
	5 => 'May',
	6 => 'June',
	7 => 'July',
	8 => 'August',
	9 => 'September',
	10 => 'October',
	11 => 'November',
	12 => 'December'
];

if (isset($_GET['month'])) {
	if ($_GET['month'] === 'all') { // Use === for comparison
		$months = "'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'"; // Include all months
		$annual = true;
	} else {
		$months = "'{$_GET['month']}'"; // Ensure this is sanitized before use
		$annual = false;
	}
	$fy = $_GET['fy']; // Ensure this is sanitized before use
} else {
	$annual = false;
	$currentmonth = date('m');
	$months = "'{$currentmonth}'";
	$fy = "2024/2025"; // Consider making this dynamic if needed
}

?>