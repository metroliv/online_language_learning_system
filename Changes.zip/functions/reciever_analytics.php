<?php
require_once('../functions/reusableQuery.php');
require_once('../config/config.php');

/**
 * Summary of getRandomRGBColor
 * @return string
 */
function getRandomRGBColor() {
    $r = rand(0, 255); // Random red value
    $g = rand(0, 255); // Random green value
    $b = rand(0, 255); // Random blue value
    return "rgb($r, $g, $b)";
}

// Array mapping month numbers to month names
$myMonths = [
	1 => 'January',
	2 => 'February',
	3 => 'March',
	4 => 'April',
	5 => 'May',
	6 => 'June',
	7 => 'July',
	8 => 'August',
	9 => 'September',
	10 => 'October',
	11 => 'November',
	12 => 'December'
];

if (isset($_GET['month'])) {
	if ($_GET['month'] === 'all' || $_GET['month'] ===  "'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'")
	{
		$months = "'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'"; // Include all months
		$annual = true;
	} else {
		$months = "'{$_GET['month']}'"; // Ensure this is sanitized before use
		$annual = false;
	}
	$fy = $_GET['fy']; // Ensure this is sanitized before use
} else {
	$annual = false;
	$currentmonth = date('m');
	$months = "'{$currentmonth}'";
	$fy = "2024/2025"; // Consider making this dynamic if needed
}

/** user ward name */
	$ward_name = selectItem('ward', 'ward_name', ['ward_id'=>$_SESSION['user_ward_id']]);
	/** user ward name */
// $ward_name = selectItem('ward', 'ward_name', ['ward_id' => $_SESSION['user_ward_id']]);

/** ward Target */
	//annual
	$query = "SELECT SUM(streamtarget_amount) FROM streamtarget 
			WHERE streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
			AND streamtarget_fy = '2024/2025'
			";
	$stmt = $mysqli->prepare($query);
	$stmt->execute();
	$stmt->bind_result($wardAnnaulTarget);
	$stmt->fetch();
	$stmt->close();

	//monthly
	$wardMonthlyTarget = $wardAnnaulTarget / 12;

	
/** Collection */
$query = "SELECT SUM(collection_amount) FROM revenue_collections 
WHERE collection_ward_id = '{$_SESSION['user_ward_id']}' 
AND collection_status = 'Approved' 
AND MONTH(collection_date) IN ({$months})";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($collections_total);
$stmt->fetch();
$stmt->close();


/** % Achievement */
//monthly
if ($wardMonthlyTarget > 0) {
	$mothlyAchievments = ($collections_total * 100) / $wardMonthlyTarget;
	$annualAchievments = ($collections_total * 100) / $wardAnnaulTarget;
} else {
	$mothlyAchievments = 0;
	$annualAchievments = 0;
}

/** number of collectors per ward */
	$query = "SELECT COUNT(user_id) FROM users 
	WHERE user_ward_id = '{$_SESSION['user_ward_id']}'
	AND user_access_level = 'Revenue Collector'
	";
	$stmt = $mysqli->prepare($query);
	$stmt->execute();
	$stmt->bind_result($collectorNo);
	$stmt->fetch();
	$stmt->close();

/** Annual collector target */
	$collectorTarget = floor($wardAnnaulTarget / $collectorNo);

/** Monthly collector target */
	$collectorTargetMonth = floor($collectorTarget / 12);


/** pending Approvals */
	$query = "SELECT count(collection_status) FROM revenue_collections 
	WHERE collection_status = 'Pending' 
	AND collection_ward_id = '{$_SESSION['user_ward_id']}' 
	";
	// AND collection_fy = '2024/2025'

	// AND DATE_FORMAT(collection_date, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m');";
	$stmt = $mysqli->prepare($query);
	$stmt->execute();
	$stmt->bind_result($pending_approvals);
	$stmt->fetch();
	$stmt->close();


	
/** Imprest percentage - to be mutiplied by collections */
	$annualImperest = selectOne('imprest', ['imprest_fy' => '2024/2025' ]);
	$colectorTarget = $wardAnnaulTarget / $collectorNo;
	if($colectorTarget>0) {
	$imprest = $annualImperest['imprest_amount'] / $colectorTarget;
	}else{
		$imprest = 0;
	}
?>