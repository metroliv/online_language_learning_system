<?php
// Start session and connect to the database

require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../partials/head.php');

// Fetch number of revenue collectors for the ward
$collectorNoQuery = "SELECT COUNT(user_id) FROM users 
                     WHERE user_ward_id = '{$_SESSION['user_ward_id']}'
                     AND user_access_level = 'Revenue Collector'";
$collectorNoResult = mysqli_query($mysqli, $collectorNoQuery);
$collectorNo = mysqli_fetch_array($collectorNoResult)[0];

// Fetch total amount collected per stream
$query_collected = "
    SELECT rss.stream_name, 
           rss.stream_id,
           COALESCE(SUM(rc.collection_amount), 0) AS total_collected
    FROM revenue_collections rc
    LEFT JOIN revenue_streams rss ON rc.collection_stream_id = rss.stream_id
    WHERE rc.collection_user_id = '{$_SESSION['user_id']}'
    AND rc.collection_status = 'Approved'
    GROUP BY rss.stream_name, rss.stream_id
";
$result_collected = mysqli_query($mysqli, $query_collected);

if (!$result_collected) {
  die("Database query failed: " . mysqli_error($mysqli));
}

// Initialize arrays for chart data
$stream_data = [];
$collected_amount_data = [];
$target_amount_data = [];

// Process collected data and calculate target per collector
while ($row = mysqli_fetch_assoc($result_collected)) {
  $stream_name = $row['stream_name'];
  $stream_id = $row['stream_id'];
  
  $stream_data[] = $stream_name;
  $collected_amount_data[$stream_name] = $row['total_collected'];

  // Fetch stream target per collector
  $query = "SELECT SUM(streamtarget_amount) FROM streamtarget st
            WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
            AND st.streamtarget_fy = '2024/2025'
            AND st.streamtarget_stream_id = '{$stream_id}'";
  $stmt = $mysqli->prepare($query);
  $stmt->execute();
  $stmt->bind_result($streamTargetAmounts);
  $stmt->fetch();
  $stmt->close();

  // Divide the target amount by the number of collectors
  $target_amount_data[$stream_name] = floor($streamTargetAmounts / $collectorNo);
}

// Prepare data for chart
$collected_amount_data = array_values($collected_amount_data);
$target_amount_data = array_values($target_amount_data);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Total Amount Collected vs Target</title>
  <link rel="stylesheet" href="path/to/your/css/style.css"> <!-- Include your CSS file -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js library -->
</head>

<body>
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <!-- BAR CHART for comparison -->
          <div class="card card-success">
            <div class="card-header">
              <h3 class="card-title">Total Amount Collected vs Target per Stream</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-card-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="chart">
                <canvas id="comparisonChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <script>
    var ctx = document.getElementById('comparisonChart').getContext('2d');
    var comparisonChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?php echo json_encode($stream_data); ?>,
        datasets: [{
          label: 'Target Amount',
          data: <?php echo json_encode($target_amount_data); ?>,
          backgroundColor: 'rgba(18, 68, 145, 0.2)', // #124491 with 20% opacity
          borderColor: 'rgba(18, 68, 145, 1)',
          borderWidth: 1
        }, {
          label: 'Total Amount Collected',
          data: <?php echo json_encode($collected_amount_data); ?>,
          backgroundColor: 'rgba(255, 205, 61, 0.2)',  // #ffcd3d with 20% opacity
          borderColor: 'rgba(255, 205, 61, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  </script>
</body>

</html>
