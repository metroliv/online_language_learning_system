<?php
/*
 *   Crafted On Mon Jul 29 2024
 *   Author Stephen Ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();
require_once('../functions/reusableQuery.php');
require_once('../functions/reciever_analytics.php');
require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../helpers/users.php');
require_once('../helpers/target.php');
require_once('../partials/headn.php');

/**
 * Chart Data
 * @var mixed
//  * 
//  */
// $rev_streams = [];
// $stream_no = 0;
// $variable = selectMany('revenue_streams');
// foreach ($variable as $key => $value) {
// 	array_push($rev_streams, $value['stream_name']);
// 	$stream_no++;
// }


// $randomNumbers = []; // Initialize an array to hold the random numbers

// // Generate 10 random numbers
// for ($i = 0; $i < $stream_no; $i++) {
//     $randomNumber = mt_rand(1000, 2000000); // Generate a random number between 25 and 70
//     $randomNumbers[] = $randomNumber; // Add the random number to the array
// }


// // Array mapping month numbers to month names
// $myMonths = [
//     1 => 'January',
//     2 => 'February',
//     3 => 'March',
//     4 => 'April',
//     5 => 'May',
//     6 => 'June',
//     7 => 'July',
//     8 => 'August',
//     9 => 'September',
//     10 => 'October',
//     11 => 'November',
//     12 => 'December'
// ];

// // $month = '08';
// // $monthWithoutZero = (int)$month; // This will be 8
// // dd($monthWithoutZero); // Outputs: 8

// if (isset($_GET['month'])) {	
// 	if ($_GET['month'] === 'all') { // Use === for comparison
// 		$months = "'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'"; // Include all months
// 		$annual = true;
// 	} else {
// 		$months = "'{$_GET['month']}'"; // Ensure this is sanitized before use
// 		$annual = false;
// 	}
// 	$fy = $_GET['fy']; // Ensure this is sanitized before use
// } else {
// 	$annual = false;
// 	$currentmonth = date('m');
// 	$months = "'{$currentmonth}'";	
// 	$fy = "2024/2025"; // Consider making this dynamic if needed
// }


// /**
//  * ward analytics
//  */
// /** user ward name */
// $ward_name = selectItem('ward', 'ward_name', ['ward_id'=>$_SESSION['user_ward_id']]);

// /** ward Target */
// //monthly
// $query = "SELECT SUM(streamtarget_amount) FROM streamtarget 
// WHERE streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
// AND streamtarget_fy = '2024/2025'
// ";
// $stmt = $mysqli->prepare($query);
// $stmt->execute();
// $stmt->bind_result($wardMonthlyTarget);
// $stmt->fetch();
// $stmt->close();

// //anual
// $wardAnnaulTarget = $wardMonthlyTarget*12;

/** Collection */
// $query = "SELECT SUM(collection_amount) FROM revenue_collections 
// WHERE collection_ward_id = '{$_SESSION['user_ward_id']}' 
// AND collection_status = 'Approved' 
// AND MONTH(collection_date) IN ({$months})";
// $stmt = $mysqli->prepare($query);
// $stmt->execute();
// $stmt->bind_result($collections_total);
// $stmt->fetch();
// $stmt->close();


/** % Achievement */
//monthly
// $mothlyAchievments = ($collections_total*100)/$wardMonthlyTarget;
// $annualAchievments = ($collections_total*100)/$wardAnnaulTarget;


?>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <?php include('../partials/preloader.php'); ?>

    <!-- Navbar -->
    <?php include('../partials/header.php'); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include('../partials/ward_admin_sidenav.php'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-dark">
                Revenue Streams,
                <?php
                echo $ward_name['ward_name'] . ' Ward. ';
                if ($annual) {
                  echo '2024/2025 FY';
                } else {
                  $trimonth = trim($months, "'");
                  $monthWithoutZero = (int)$trimonth; // This will be 8
                  // echo $months;
                  // echo $monthWithoutZero;
                  echo $myMonths[$monthWithoutZero] . ', 2024';
                }
                ?>
              </h1>
              <small>Department of Finance, Revenue Collection Tool</small>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                <li class="breadcrumb-item active">Revenue Target</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Select date filters -->
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title m-0">Revenue Collection Reports</h5>
              </div>
              <div class="card-body">
                <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                  <div class="row">
                    <div class="col-md-5">
                      <label for="ward">Month</label>
                      <select id="month" name="month" class="form-control">
                        <option value="">Select</option>
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                        <option value="all">All</option>
                      </select>
                    </div>

                    <!-- <div class="form-group col-sm-3 col-lg-3 col-xl-3">
												<button type="button" class="btn btn-default float-right" id="daterange-btn">
												<i class="far fa-calendar-alt"></i> Date range picker
												<i class="fas fa-caret-down"></i>
												</button>
												<input type="text" name="dates" class="form-control float-right" id="reportrange">
											</div> -->



                    <div class="col-md-5">
                      <label for="ward">Financial Year</label>
                      <select id="ward" name="fy" class="form-control">
                        <option value="2024/2025">2024/2025</option>
                      </select>
                    </div>

                    <div class="col-md-2">
                      <label for="stream">Action</label>
                      <button type="submit" class="btn btn-primary form-control" name="wardPerformance">Search</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- ./ Select date -->

      <!-- charts hidden -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <!-- LINE CHART -->
              <div class="card card-info d-none">
                <div class="card-header">
                  <h3 class="card-title">Line Chart</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="chart">
                    <canvas id="lineChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                  </div>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              <!--BAR CHART - Stream perfomance against target -->
              <div class="card card-success d-none">
                <div class="card-header">
                  <h3 class="card-title">Collections per stream </h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="chart">
                    <canvas id="barChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                  </div>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              <!-- STACKED BAR CHART -->
              <div class="card card-success d-none">
                <div class="card-header">
                  <h3 class="card-title">Stacked Bar Chart</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="chart">
                    <canvas id="stackedBarChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                  </div>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

            </div>
            <!-- /.col (left) -->
            <div class="col-md-12">
              <!-- AREA CHART -->
              <div class="card card-primary d-none">
                <div class="card-header">
                  <h3 class="card-title">Area Chart</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="chart">
                    <canvas id="areaChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                  </div>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              <!-- DONUT CHART -->
              <div class="card card-danger d-none">
                <div class="card-header">
                  <h3 class="card-title">Staff performance</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <canvas id="donutChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              <!-- PIE CHART -->
              <div class="card card-danger d-none">
                <div class="card-header">
                  <h3 class="card-title">Staff performance</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
                <div class="card-body">
                  <canvas id="pieChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

            </div>
            <!-- /.col (right) -->
          </div>
          <!-- /.row -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
      <!-- / charts -->

      <!-- Main content -->
      <div class="content">
        <div class="container">
          <!-- row  -->
          <div class="row">
            <!-- system users dashboard -->
            <div class="col-lg-12">
              <div class="card card-primary card-outline">

                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th style="width: 10px">#</th>
                        <th>Stream</th>
                        <th>Target</th>
                        <th>Collections</th>
                        <th>Target Achieved</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $fetch_records_sql = mysqli_query(
                        $mysqli,
                        // "SELECT * FROM streamtarget st "	
                        "SELECT * FROM streamtarget st 
											INNER JOIN revenue_streams rs ON rs.stream_id = st.streamtarget_stream_id 
											WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
											AND st.streamtarget_fy = '2024/2025'
											"
                        // 				 "SELECT * FROM logs l INNER JOIN users u ON u.user_id = l.log_user_id WHERE u.user_id = '{$user_id}' AND
                        // l.log_date BETWEEN '{$today}' AND '{$tomorrow}' ORDER BY l.log_id DESC"



                      );
                      if (mysqli_num_rows($fetch_records_sql) > 0) {
                        $cnt =  1;
                        while ($rows = mysqli_fetch_array($fetch_records_sql)) {
                      ?>
                          <tr>
                            <td>
                              <?php echo $cnt; ?>
                            </td>

                            <td>
                              <!-- <a href="collector_performance?stream=1&month=8&fy=2024/2025"> -->
                              <a href="#">
                                <?php echo $rows['stream_name'] ?>
                              </a>
                            </td>

                            <td>
                              <?php
                              if ($annual) {
                                echo 'Ksh. ' . number_format($rows['streamtarget_amount']);
                              } else {
                                echo 'Ksh. ' . number_format($rows['streamtarget_amount'] / 12);
                              }
                              ?>
                            </td>
                            </td>
                            <td>
                              <?php
                              /** Total collections */
                              $query = "SELECT SUM(collection_amount) FROM revenue_collections 
														WHERE collection_ward_id = '{$_SESSION['user_ward_id']}'
														AND collection_stream_id = '{$rows['streamtarget_stream_id']}'
														AND collection_status = 'Approved' 
														AND MONTH(collection_date) IN ({$months})
														";
                              // $query = "SELECT sum(collection_amount) FROM revenue_collections rc
                              // INNER JOIN revenue_services rss ON rc.collection_service_id = rss.service_id
                              // INNER JOIN revenue_stream rs ON rss.service_stream_id  = rs.stream_id														
                              // INNER JOIN streamtarget st ON st.streamtarget_stream_id  = rs.stream_id														
                              // WHERE rc.collection_ward_id = '{$_SESSION['user_ward_id']}'
                              // AND rc.collection_stream_id = '{$rows['streamtarget_stream_id']}'
                              // ";
                              $stmt = $mysqli->prepare($query);
                              $stmt->execute();
                              $stmt->bind_result($stream_collections);
                              $stmt->fetch();
                              $stmt->close();


                              if ($stream_collections >= 1) {
                                echo 'Ksh. ' . number_format($stream_collections);
                              } else {
                                echo 'Ksh. 0';
                              };
                              ?>

                            </td>
                            <td>
                              <?php
                              if ($annual) {
                                $achieved = ($stream_collections * 100) / $rows['streamtarget_amount'];
                                echo floor($achieved) . '%';
                              } else {
                                $achieved = ($stream_collections * 100) / ($rows['streamtarget_amount'] / 12);
                                echo floor($achieved) . '%';
                              }
                              ?>
                            </td>


                          </tr>
                      <?php
                          $cnt = $cnt + 1;
                          // include('../modals/users.php');
                        }
                      } ?>
                    </tbody>

                    </tbody>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
          </div>
          <!-- /.row -->
        </div>
      </div>
      <!-- /.content -->
      <?php include('../modals/users.php'); ?>
      <!-- Add user modal -->
    </div>
    <!-- /.content-wrapper -->
    <?php include('../partials/footer.php'); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->
  <?php include('../partials/scriptn.php'); ?>

  <!-- FLOT CHARTS -->
  <script src="../public/plugins/flot/jquery.flot.js"></script>
  <!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
  <script src="../public/plugins/flot/plugins/jquery.flot.resize.js"></script>
  <!-- FLOT PIE PLUGIN - also used to draw donut charts -->
  <script src="../public/plugins/flot/plugins/jquery.flot.pie.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../public/dist/js/demo.js"></script>
  <!-- Page specific script -->
  <script>
    $(function() {
      /*
       * Flot Interactive Chart
       * -----------------------
       */
      // We use an inline data source in the example, usually data would
      // be fetched from a server
      var data = [],
        totalPoints = 100

      function getRandomData() {

        if (data.length > 0) {
          data = data.slice(1)
        }

        // Do a random walk
        while (data.length < totalPoints) {

          var prev = data.length > 0 ? data[data.length - 1] : 50,
            y = prev + Math.random() * 10 - 5

          if (y < 0) {
            y = 0
          } else if (y > 100) {
            y = 100
          }

          data.push(y)
        }

        // Zip the generated y values with the x values
        var res = []
        for (var i = 0; i < data.length; ++i) {
          res.push([i, data[i]])
        }

        return res
      }

      var interactive_plot = $.plot('#interactive', [{
        data: getRandomData(),
      }], {
        grid: {
          borderColor: '#f3f3f3',
          borderWidth: 1,
          tickColor: '#f3f3f3'
        },
        series: {
          color: '#3c8dbc',
          lines: {
            lineWidth: 2,
            show: true,
            fill: true,
          },
        },
        yaxis: {
          min: 0,
          max: 100,
          show: true
        },
        xaxis: {
          show: true
        }
      })

      var updateInterval = 500 //Fetch data ever x milliseconds
      var realtime = 'on' //If == to on then fetch data every x seconds. else stop fetching
      function update() {

        interactive_plot.setData([getRandomData()])

        // Since the axes don't change, we don't need to call plot.setupGrid()
        interactive_plot.draw()
        if (realtime === 'on') {
          setTimeout(update, updateInterval)
        }
      }

      //INITIALIZE REALTIME DATA FETCHING
      if (realtime === 'on') {
        update()
      }
      //REALTIME TOGGLE
      $('#realtime .btn').click(function() {
        if ($(this).data('toggle') === 'on') {
          realtime = 'on'
        } else {
          realtime = 'off'
        }
        update()
      })
      /*
       * END INTERACTIVE CHART
       */


      /*
       * LINE CHART
       * ----------
       */
      //LINE randomly generated data

      var sin = [],
        cos = []
      for (var i = 0; i < 14; i += 0.5) {
        sin.push([i, Math.sin(i)])
        cos.push([i, Math.cos(i)])
      }
      var line_data1 = {
        data: sin,
        color: '#3c8dbc'
      }
      var line_data2 = {
        data: cos,
        color: '#00c0ef'
      }
      $.plot('#line-chart', [line_data1, line_data2], {
        grid: {
          hoverable: true,
          borderColor: '#f3f3f3',
          borderWidth: 1,
          tickColor: '#f3f3f3'
        },
        series: {
          shadowSize: 0,
          lines: {
            show: true
          },
          points: {
            show: true
          }
        },
        lines: {
          fill: false,
          color: ['#3c8dbc', '#f56954']
        },
        yaxis: {
          show: true
        },
        xaxis: {
          show: true
        }
      })
      //Initialize tooltip on hover
      $('<div class="tooltip-inner" id="line-chart-tooltip"></div>').css({
        position: 'absolute',
        display: 'none',
        opacity: 0.8
      }).appendTo('body')
      $('#line-chart').bind('plothover', function(event, pos, item) {

        if (item) {
          var x = item.datapoint[0].toFixed(2),
            y = item.datapoint[1].toFixed(2)

          $('#line-chart-tooltip').html(item.series.label + ' of ' + x + ' = ' + y)
            .css({
              top: item.pageY + 5,
              left: item.pageX + 5
            })
            .fadeIn(200)
        } else {
          $('#line-chart-tooltip').hide()
        }

      })
      /* END LINE CHART */

      /*
       * FULL WIDTH STATIC AREA CHART
       * -----------------
       */
      var areaData = [
        [2, 88.0],
        [3, 93.3],
        [4, 102.0],
        [5, 108.5],
        [6, 115.7],
        [7, 115.6],
        [8, 124.6],
        [9, 130.3],
        [10, 134.3],
        [11, 141.4],
        [12, 146.5],
        [13, 151.7],
        [14, 159.9],
        [15, 165.4],
        [16, 167.8],
        [17, 168.7],
        [18, 169.5],
        [19, 168.0]
      ]
      $.plot('#area-chart', [areaData], {
        grid: {
          borderWidth: 0
        },
        series: {
          shadowSize: 0, // Drawing is faster without shadows
          color: '#00c0ef',
          lines: {
            fill: true //Converts the line chart to area chart
          },
        },
        yaxis: {
          show: false
        },
        xaxis: {
          show: false
        }
      })

      /* END AREA CHART */

      /*
       * BAR CHART
       * ---------
       */

      var bar_data = {
        data: <?php echo json_encode($data); ?>,
        bars: {
          show: true
        }
      }
      $.plot('#bar-chart', [bar_data], {
        grid: {
          borderWidth: 1,
          borderColor: '#f3f3f3',
          tickColor: '#f3f3f3'
        },
        series: {
          bars: {
            show: true,
            barWidth: 0.5,
            align: 'center',
          },
        },
        colors: ['#3c8dbc'],
        xaxis: {
          ticks: <?php echo json_encode($ticks); ?>
        }
      })
      /* END BAR CHART */

      /*
       * DONUT CHART
       * -----------
       */

      var donutData = [{
          label: 'Series2',
          data: 30,
          color: '#3c8dbc'
        },
        {
          label: 'Series3',
          data: 20,
          color: '#0073b7'
        },
        {
          label: 'Series4',
          data: 50,
          color: '#00c0ef'
        }
      ]
      $.plot('#donut-chart', donutData, {
        series: {
          pie: {
            show: true,
            radius: 1,
            innerRadius: 0.5,
            label: {
              show: true,
              radius: 2 / 3,
              formatter: labelFormatter,
              threshold: 0.1
            }

          }
        },
        legend: {
          show: false
        }
      })
      /*
       * END DONUT CHART
       */

    })

    /*
     * Custom Label formatter
     * ----------------------
     */
    function labelFormatter(label, series) {
      return '<div style="font-size:13px; text-align:center; padding:2px; color: #fff; font-weight: 600;">' +
        label +
        '<br>' +
        Math.round(series.percent) + '%</div>'
    }
  </script>
  <!-- Page specific script -->
  <script>
    $(function() {
      /* ChartJS
       * -------
       * Here we will create a few charts using ChartJS
       */

      //--------------
      //- AREA CHART -
      //--------------

      // Get context with jQuery - using jQuery's .get() method.
      var areaChartCanvas = $('#areaChart').get(0).getContext('2d')


      var areaChartData = {
        labels: <?php echo json_encode($rev_streams) ?>,
        datasets: [{
            label: 'Targets',
            backgroundColor: 'rgba(60,141,188,0.9)',
            borderColor: 'rgba(60,141,188,0.8)',
            pointRadius: false,
            pointColor: '#3b8bba',
            pointStrokeColor: 'rgba(60,141,188,1)',
            pointHighlightFill: '#fff',
            pointHighlightStroke: 'rgba(60,141,188,1)',
            data: <?php echo json_encode($randomNumbers) ?>
          },
          {
            label: '',
            backgroundColor: 'rgba(60,141,188,0.9)',
            borderColor: 'rgba(60,141,188,0.8)',
            pointRadius: false,
            pointColor: '#3b8bba',
            pointStrokeColor: 'rgba(60,141,188,1)',
            pointHighlightFill: '#fff',
            pointHighlightStroke: 'rgba(60,141,188,1)',
            data: <?php echo json_encode($randomNumbers) ?>
          },
        ]
      }

      var areaChartOptions = {
        maintainAspectRatio: false,
        responsive: true,
        legend: {
          display: false
        },
        scales: {
          xAxes: [{
            gridLines: {
              display: false,
            }
          }],
          yAxes: [{
            gridLines: {
              display: false,
            }
          }]
        }
      }

      // This will get the first returned node in the jQuery collection.
      new Chart(areaChartCanvas, {
        type: 'line',
        data: areaChartData,
        options: areaChartOptions
      })

      //-------------
      //- LINE CHART -
      //--------------
      var lineChartCanvas = $('#lineChart').get(0).getContext('2d')
      var lineChartOptions = $.extend(true, {}, areaChartOptions)
      var lineChartData = $.extend(true, {}, areaChartData)
      lineChartData.datasets[0].fill = false;
      lineChartData.datasets[1].fill = false;
      lineChartOptions.datasetFill = false

      var lineChart = new Chart(lineChartCanvas, {
        type: 'line',
        data: lineChartData,
        options: lineChartOptions
      })

      //-------------
      //- DONUT CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
      var donutData = {
        labels: [
          'Matthew',
          'Mark',
          'Luke',
          'John',
          'James',
          'Peter',
        ],
        datasets: [{
          data: [700, 500, 400, 600, 300, 100],
          backgroundColor: ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de'],
        }]
      }
      var donutOptions = {
        maintainAspectRatio: false,
        responsive: true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(donutChartCanvas, {
        type: 'doughnut',
        data: donutData,
        options: donutOptions
      })

      //-------------
      //- PIE CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
      var pieData = donutData;
      var pieOptions = {
        maintainAspectRatio: false,
        responsive: true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(pieChartCanvas, {
        type: 'pie',
        data: pieData,
        options: pieOptions
      })

      //-------------
      //- BAR CHART -
      //-------------
      var barChartCanvas = $('#barChart').get(0).getContext('2d')
      var barChartData = $.extend(true, {}, areaChartData)
      var temp0 = areaChartData.datasets[0]
      var temp1 = areaChartData.datasets[1]
      barChartData.datasets[0] = temp1
      barChartData.datasets[1] = temp0

      var barChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        datasetFill: false
      }

      new Chart(barChartCanvas, {
        type: 'bar',
        data: barChartData,
        options: barChartOptions
      })

      //---------------------
      //- STACKED BAR CHART -
      //---------------------
      var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d')
      var stackedBarChartData = $.extend(true, {}, barChartData)

      var stackedBarChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          xAxes: [{
            stacked: true,
          }],
          yAxes: [{
            stacked: true
          }]
        }
      }

      new Chart(stackedBarChartCanvas, {
        type: 'bar',
        data: stackedBarChartData,
        options: stackedBarChartOptions
      })
    })
  </script>


</body>

</html>