<?php
session_start();
require_once('../functions/reusableQuery.php');
require_once('../config/config.php');
require_once('../helpers/collection.php');
require_once('../partials/headn.php');
?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/collector_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"> My Revenue Collection</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Users</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <div class="content">
                <div class="container">
                    <!-- row  -->
                    <div class="row">
                        <!-- system users dashboard -->
                        <div class="col-lg-12">
                            <div class="card card-primary card-outline">
                                <div class="card-header">
                                    <h3 class="card-title"></h3>
                                    <!-- Add new user button -->
                                    <div class="card-tools flex">
                                        <a data-toggle="modal" data-target="#addUser"><button type="button" class="btn btn-block btn-success">Submit Collections</button></a>
                                    </div>
                                </div>
                                <div class="modal fade fixed-right" id="addUser" role="dialog" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header align-items-center">
                                                <div class="text-center">
                                                    <h6 class="mb-0 text-bold">Add Collections</h6>
                                                </div>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                                                    <div class="row">
                                                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                                            <label class="form-control-label">Stream <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <select id="streamDropdown" required name="collection_stream_id" class="form-control">
                                                                    <option value="">Select stream</option>
                                                                    <?php
                                                                    $fetch_records_sql = mysqli_query($mysqli, "SELECT * FROM revenue_streams");
                                                                    if (mysqli_num_rows($fetch_records_sql) > 0) {
                                                                        while ($rows = mysqli_fetch_array($fetch_records_sql)) {
                                                                    ?>
                                                                            <option value="<?php echo $rows['stream_id']; ?>"><?php echo $rows['stream_name']; ?></option>
                                                                    <?php }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                                            <label class="form-control-label">Service <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <select id="serviceDropdown" required name="collection_service_id" class="form-control">
                                                                    <option value="">Select service</option>
                                                                    <?php
                                                                    $fetch_services_sql = mysqli_query($mysqli, "SELECT * FROM revenue_services");
                                                                    if (mysqli_num_rows($fetch_services_sql) > 0) {
                                                                        while ($rows = mysqli_fetch_array($fetch_services_sql)) {
                                                                    ?>
                                                                            <option value="<?php echo $rows['service_id']; ?>" data-stream="<?php echo $rows['service_stream_id']; ?>"><?php echo $rows['service_name']; ?></option>
                                                                    <?php }
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                                            <label class="form-control-label">Amount <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <input type="text" required name="collection_amount" class="form-control">
                                                            </div>
                                                        </div>

                                                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                                            <label class="form-control-label">Date <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <input type="text" readonly value="<?php echo date('d/m/Y') ?>" required name="collection_date" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                                            <label class="form-control-label">Location <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <input type="text" required name="collection_location" class="form-control">
                                                            </div>
                                                        </div>

                                                        <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                                            <label class="form-control-label">Assignment <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <input type="text" required name="collection_assignment" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-sm-12 col-lg-12 col-xl-12">
                                                            <label class="form-control-label">Comment <span class="text-danger">*</span></label>
                                                            <div class="input-group input-group-merge">
                                                                <textarea type="text" required name="collection_comment" class="form-control"></textarea>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="text-right">
                                                        <button type="submit" name="AddCollection" class="btn btn-outline-success">Add Collection</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped table-responsive">
                                        <thead>
                                            <tr>
                                                <th>Stream</th>
                                                <th>Service</th>
                                                <th>Amount</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Ward</th>
                                                <th>Location</th>
                                                <th>Assignment</th>
                                                <th>Action</th>
                                                <th>Comments</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $fetch_records_sql = mysqli_query(
                                                $mysqli,
                                                // ("SELECT * FROM revenue_collections rc
                                                // INNER JOIN users u ON u.user_id = rc.collection_user_id 
                                                // INNER JOIN revenue_streams rss ON rss.stream_id = rc.collection_stream_id
                                                // INNER JOIN revenue_services rs ON rs.service_id = rc.collection_service_id
                                                // INNER JOIN ward w ON w.ward_id = rc.collection_ward_id 
                                                // WHERE collection_user_id = '{$_SESSION['user_id']}'
                                                //  ")
                                                "SELECT * FROM revenue_collections rc
                                                 INNER JOIN users u ON u.user_id = rc.collection_user_id 
                                                 INNER JOIN revenue_streams rss ON rss.stream_id = rc.collection_stream_id
                                                 INNER JOIN revenue_services rs ON rs.service_id = rc.collection_service_id
                                                 INNER JOIN ward w ON w.ward_id = rc.collection_ward_id 
												 WHERE rc.collection_status = 'Pending' AND rc.collection_user_id = '{$_SESSION['user_id']}'
												 "
                                            );

                                            if (mysqli_num_rows($fetch_records_sql) > 0) {
                                                while ($rows = mysqli_fetch_array($fetch_records_sql)) {
                                            ?>
                                                    <tr>
                                                        <td><?php echo $rows['stream_name']; ?></td>
                                                        <td><?php echo $rows['service_name']; ?></td>
                                                        <td>Ksh <?php echo number_format($rows['collection_amount']); ?></td>
                                                        <td><?php echo $rows['collection_date']; ?></td>
                                                        <td><?php echo $rows['collection_status']; ?></td>
                                                        <td><?php echo $rows['ward_name']; ?></td>
                                                        <td><?php echo $rows['collection_location']; ?></td>
                                                        <td><?php echo $rows['collection_assignment']; ?></td>
                                                        <td>
                                                            <?php if ($rows['collection_status'] == 'Pending' || $rows['collection_status'] == 'Declined') { ?>
                                                                <a data-toggle="modal" href="#update_<?php echo $rows['collection_id']; ?>" class="badge badge-primary">Update</a>
                                                            <?php } else { ?>
                                                                <span class="badge badge-success">Approved</span>
                                                            <?php } ?>
                                                        </td>
                                                        <td><?php echo $rows['collection_comment']; ?></td>
                                                    </tr>
                                            <?php
                                                    include('../modals/manage_collection.php');
                                                }
                                            } else {
                                                echo "<tr><td colspan='10' class='text-center'>No records found.</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- /.card-body -->

                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.content -->

            <!-- Add user modal -->
        </div>
        <!-- /.content-wrapper -->
        <?php include('../partials/footer.php'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <?php include('../partials/scriptn.php'); ?>
    <script>
        $(function() {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });
        $(document).ready(function() {
            $('#streamDropdown').change(function() {
                var selectedStream = $(this).val();
                $('#serviceDropdown option').each(function() {
                    var stream = $(this).data('stream');
                    if (stream == selectedStream || selectedStream == "") {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
                $('#serviceDropdown').val(''); // Reset the service dropdown
            });
        });
    </script>
</body>

</html>