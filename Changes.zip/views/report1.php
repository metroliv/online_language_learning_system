<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once('../functions/reusableQuery.php');
require_once('../config/config.php');
require_once('../partials/head.php');

// Get growth rate data for the selected period
$period = $_GET['period'] ?? 'monthly'; // Default to 'monthly' if no period is selected

// Adjust the query based on the selected period and status
$interval = ($period === 'daily') ? 'DAY' : ($period === 'weekly' ? 'WEEK' : 'MONTH');
$query = "SELECT DATE_FORMAT(collection_date, '%Y-%m-%d') AS period, SUM(collection_amount) AS total_revenue
          FROM revenue_collections
          WHERE collection_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
          AND collection_status = 'approved'
          GROUP BY period";
$result = $mysqli->query($query);

$growth_data = [];
while ($row = $result->fetch_assoc()) {
    $growth_data[] = $row;
}

$mysqli->close();

// Encode data for use in JavaScript
$growth_data_json = json_encode($growth_data);
?>

<body>
    <!-- Include Sidebar Navigation -->
    <div class="sidebar">
        <?php include('../partials/executive_sidenav.php'); ?>
    </div>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <!-- Content Header -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo $greeting . ', ' . $_SESSION['user_names']; ?>
                        </h1>
                        <small>Welcome to Department of Finance Revenue Collection Tool</small>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="../partials/exec_dashboard.php">Home</a></li>
                            <li class="breadcrumb-item active">Approved Revenue Growth Rate</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.content-header -->

        <!-- Main Content -->
        <div class="container mt-5">
            <h2>Revenue Growth Rate</h2>
            <!-- Period Selector -->
            <div class="form-group">
                <label for="period">Select Period:</label>
                <select id="period" class="form-control">
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                </select>
            </div>

            <!-- Chart Container -->
            <canvas id="growthChart"></canvas>
        </div><!-- /.container -->

    </div><!-- /.content-wrapper -->
    <?php include('../partials/footer.php'); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <script>
        // Initial data from PHP
        const initialData = <?php echo $growth_data_json; ?>;

        // Convert initial data to chart format
        function prepareChartData(data) {
            const labels = data.map(item => item.period);
            const values = data.map(item => item.total_revenue);
            return {
                labels,
                values
            };
        }

        // Draw the chart
        function drawChart(labels, data) {
            const ctx = document.getElementById('growthChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Total Revenue',
                        data: data,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderWidth: 2,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed.y !== null) {
                                        label += new Intl.NumberFormat().format(context.parsed.y);
                                    }
                                    return label;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: 'Period'
                            },
                            grid: {
                                display: false
                            }
                        },
                        y: {
                            title: {
                                display: true,
                                text: 'Total Revenue'
                            },
                            beginAtZero: true,
                            grid: {
                                borderDash: [2, 2]
                            }
                        }
                    }
                }
            });
        }

        // Event listener for period change
        document.getElementById('period').addEventListener('change', async (event) => {
            const period = event.target.value;
            // Fetch data based on selected period
            try {
                const response = await fetch(`?period=${period}`);
                if (response.ok) {
                    const data = await response.json();
                    const {
                        labels,
                        values
                    } = prepareChartData(data);
                    drawChart(labels, values);
                } else {
                    console.error('Failed to fetch data:', response.statusText);
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        });

        // Initial chart load
        document.addEventListener('DOMContentLoaded', () => {
            const {
                labels,
                values
            } = prepareChartData(initialData);
            drawChart(labels, values);
        });
    </script>
</body>

</html>