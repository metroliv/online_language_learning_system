<?php
require_once('../config/config.php');

// Handle form submission
$stream = isset($_POST['stream']) ? $_POST['stream'] : 'all';
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-01'); // Default to the first day of the current month
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-t'); // Default to the last day of the current month

// Prepare the query based on user inputs
$query = "
    SELECT 
        s.stream_id,
        s.stream_name,
        SUM(rc.collection_amount) AS total_collected
    FROM revenue_collections rc
    JOIN revenue_streams s ON rc.collection_stream_id = s.stream_id
    WHERE rc.collection_status = 'Approved'
    AND rc.collection_date BETWEEN ? AND ?
";

if ($stream != 'all') {
    $query .= " AND rc.collection_stream_id = ?";
}

$query .= " GROUP BY s.stream_id, s.stream_name ORDER BY total_collected DESC";

// Prepare and execute the query
$stmt = $mysqli->prepare($query);

if ($stream != 'all') {
    $stmt->bind_param("sss", $startDate, $endDate, $stream);
} else {
    $stmt->bind_param("ss", $startDate, $endDate);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch stream performance data
$streamPerformance = [];
while ($row = $result->fetch_assoc()) {
    $streamPerformance[] = $row;
}

// Check for errors
if (!$result) {
    die('Error fetching stream performance: ' . $mysqli->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../partials/head.php'); ?>
    <title>Stream Performance Dashboard</title>
</head>
<body>
    <div class="wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Stream Performance Dashboard</h1>
                        <small>Overview of stream performance by revenue collection</small>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

        <!-- Main content -->
        <div class="container-fluid">
            <!-- Filter Form -->
            <div class="row mb-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title m-0">Filter Stream Performance</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="stream">Stream</label>
                                        <select id="stream" name="stream" class="form-control">
                                            <option value="all">All</option>
                                            <?php
                                            $streamsQuery = "SELECT stream_id, stream_name FROM revenue_streams";
                                            $streamsResult = $mysqli->query($streamsQuery);
                                            while ($stream = $streamsResult->fetch_assoc()) {
                                                echo '<option value="' . $stream['stream_id'] . '">' . htmlspecialchars($stream['stream_name']) . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="start_date">Start Date</label>
                                        <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($startDate); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="end_date">End Date</label>
                                        <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($endDate); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="submit">&nbsp;</label>
                                        <button type="submit" class="btn btn-primary form-control">Filter</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stream Performance Table -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title m-0">Stream Performance</h5>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Timeframe</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($streamPerformance as $performance) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($performance['stream_name']); ?></td>
                                            <td><?php echo htmlspecialchars($startDate) . ' to ' . htmlspecialchars($endDate); ?></td>
                                            <td><?php echo number_format($performance['total_collected'], 0); ?> Ksh</td>
                                            <td>
                                                <a href="view_details.php?stream_id=<?php echo $performance['stream_id']; ?>&start_date=<?php echo urlencode($startDate); ?>&end_date=<?php echo urlencode($endDate); ?>" class="btn btn-info btn-sm">View Details</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- ./wrapper -->
    <?php include('../partials/scripts.php'); ?>
</body>
</html>
