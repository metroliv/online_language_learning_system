<?php
/*
 *   Crafted On Mon Jul 29 2024
 *   Author Stephen Ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();

require_once('../functions/reusableQuery.php');
require_once('../functions/collector_target_analytics.php');
require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../helpers/users.php');
require_once('../partials/headn.php');
$user = selectOne('users', ['user_id' => $_GET['id']])
?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">



        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/collector_sidenav.php'); ?>


        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">
                                Revenue Targets
                            </h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Revenue Target</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <div class="content">
                <div class="container">
                    <!-- row  -->
                    <div class="row">
                        <!-- widget -->
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="far fa-chart-bar"></i>
                                        <?php echo date('F'); ?> Targets
                                    </h3>

                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="row">


                                        <!-- ./col -->
                                        <div class="col-6 col-md-4">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-success"><i class="fas fa-wallet"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text"> Overall Target</span>
                                                    <span class="info-box-number">Ksh <?php echo number_format($constantTarget); ?></span>
                                                </div>
                                            </div><!-- /.info-box-content -->
                                        </div>
                                        <div class="col-6 col-md-4">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-success"><i class="fas fa-wallet"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text">Actual Target</span>
                                                    <span class="info-box-number">Ksh <?php echo number_format($decreasingTarget); ?></span>
                                                </div>
                                            </div><!-- /.info-box-content -->
                                        </div>
                                        <!-- ./col -->
                                        <div class="col-6 col-md-4">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-success"><i class="fas fa-wallet"></i></span>
                                                <div class="info-box-content">
                                                    <span class="info-box-text">Achieved Target</span>
                                                    <span class="info-box-number">Ksh <?php echo $my_collections; ?></span>
                                                </div>
                                            </div><!-- /.info-box-content -->
                                        </div>
                                        <!-- ./col -->
                                    </div>
                                    <!-- /.row -->
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- ./ widget -->
                        <!-- system users dashboard -->
                        <div class="col-lg-12">
                            <div class="card card-primary card-outline">

                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th style="width: 10px">#</th>
                                                <th>Stream</th>
                                                <th>Target</th>
                                                <th>Collections</th>
                                                <th>Target Achieved</th>
                                                <!-- <th>Actions</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $fetch_records_sql = mysqli_query(
                                                $mysqli,
                                                //"SELECT * FROM revenue_streams"
                                                // "SELECT * FROM  streamtarget st
                                                // INNER JOIN collectortarget ct ON ct.collectortarget_streamtarget_id = st.streamtarget_id 
                                                // INNER JOIN revenue_streams rs ON st.streamtarget_stream_id = rs.stream_id 
                                                // WHERE ct.collectortarget_user_id = 5"
                                                "SELECT * FROM  revenue_streams"
                                                // "SELECT * FROM  streamtarget st
                                                // INNER JOIN collectortarget ct ON ct.collectortarget_streamtarget_id = st.streamtarget_id 
                                                // INNER JOIN revenue_streams rs ON st.streamtarget_stream_id = rs.stream_id 
                                                // WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'"
                                            );
                                            if (mysqli_num_rows($fetch_records_sql) > 0) {
                                                $cnt =  1;
                                                while ($rows = mysqli_fetch_array($fetch_records_sql)) {

                                            ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo $cnt; ?>
                                                        </td>

                                                        <td>
                                                            <?php echo $rows['stream_name']; ?>
                                                        </td>

                                                        <td> Ksh
                                                            <?php
                                                            $query = "SELECT SUM(streamtarget_amount) FROM  streamtarget st
                                                           WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
                                                           AND st.streamtarget_fy = '2024/2025'
                                                           AND st.streamtarget_stream_id = '{$rows['stream_id']}'															
                                                           ";
                                                            $stmt = $mysqli->prepare($query);
                                                            $stmt->execute();
                                                            $stmt->bind_result($streamTargetAmounts);
                                                            $stmt->fetch();
                                                            $stmt->close();

                                                            echo floor($streamTargetAmounts / $collectorNo);
                                                            ?>
                                                        </td>

                                                        <td>
                                                            <?php
                                                            /** Total monthly collections */
                                                            $query = "SELECT SUM(collection_amount) FROM revenue_collections
															WHERE collection_user_id = '{$_SESSION['user_id']}'
															AND collection_stream_id = '{$rows['stream_id']}' 
                                                            AND collection_status = 'Approved'
															";
                                                            $stmt = $mysqli->prepare($query);
                                                            $stmt->execute();
                                                            $stmt->bind_result($my_collections);
                                                            $stmt->fetch();
                                                            $stmt->close();
                                                            $my_collections;
                                                            if (!empty($my_collections)) {
                                                                $collections = $my_collections;
                                                            } else {
                                                                $collections = 0;
                                                            }
                                                            echo "Ksh " . number_format($collections);
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if ($collections > 0 || $streamTargetAmounts > 0) {
                                                                $achivedstrPerc = ($collections * 100) / $streamTargetAmounts;
                                                            } else {
                                                                $achivedstrPerc = 0;
                                                            }
                                                            echo number_format($achivedstrPerc, 2) . '%';
                                                            ?>
                                                        </td>

                                                        <!-- <td>
                                                            <a data-toggle="modal" href="monthly_ward_targets" class="badge badge-primary"><i class="fas fa-eye"></i> View </a>

                                                        </td> -->

                                                    </tr>
                                            <?php
                                                    $cnt = $cnt + 1;
                                                    // include('../modals/users.php');
                                                }
                                            } ?>
                                        </tbody>

                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.content -->
            <?php include('../modals/users.php'); ?>
            <!-- Add user modal -->
        </div>
        <!-- /.content-wrapper -->
        <?php include('../partials/footer.php'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
    <?php include('../partials/scriptn.php'); ?>

</body>

</html>