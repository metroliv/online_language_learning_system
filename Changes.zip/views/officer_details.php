<?php
session_start();
require_once('../config/config.php');

// Get parameters from the URL
$wardId = isset($_GET['ward_id']) ? $_GET['ward_id'] : '';
$streamId = isset($_GET['stream_id']) ? $_GET['stream_id'] : '';

// Fetch ward name
$wardQuery = "SELECT ward_name FROM ward WHERE ward_id = ?";
$wardStmt = $mysqli->prepare($wardQuery);
$wardStmt->bind_param("i", $wardId);
$wardStmt->execute();
$wardResult = $wardStmt->get_result();
$wardData = $wardResult->fetch_assoc();
$wardName = $wardData ? $wardData['ward_name'] : 'Unknown Ward';

// Fetch stream name
$streamQuery = "SELECT stream_name FROM revenue_streams WHERE stream_id = ?";
$streamStmt = $mysqli->prepare($streamQuery);
$streamStmt->bind_param("i", $streamId);
$streamStmt->execute();
$streamResult = $streamStmt->get_result();
$streamData = $streamResult->fetch_assoc();
$streamName = $streamData ? $streamData['stream_name'] : 'Unknown Stream';

// Fetch collected amount and target amount for officers
$officerQuery = "
    SELECT 
    u.user_names AS officer_name,
    COALESCE(SUM(rc.collection_amount), 0) AS collected_amount,
    COALESCE(target_share.target_amount_per_collector, 0) AS target_amount
FROM revenue_collections rc
JOIN users u ON rc.collection_user_id = u.user_id
LEFT JOIN (
    SELECT 
        st.streamtarget_ward_id,
        st.streamtarget_stream_id,
        st.streamtarget_amount / COUNT(DISTINCT u.user_id) AS target_amount_per_collector
    FROM streamtarget st
    JOIN users u ON st.streamtarget_ward_id = u.user_ward_id
    WHERE u.user_access_level = 'Revenue Collector'
    GROUP BY st.streamtarget_ward_id, st.streamtarget_stream_id, st.streamtarget_amount
) AS target_share 
    ON rc.collection_ward_id = target_share.streamtarget_ward_id 
    AND rc.collection_stream_id = target_share.streamtarget_stream_id
WHERE rc.collection_ward_id = ?
AND rc.collection_stream_id = ?
AND rc.collection_status = 'Approved'
GROUP BY u.user_names, target_share.target_amount_per_collector

";


$officerStmt = $mysqli->prepare($officerQuery);
$officerStmt->bind_param("ii", $wardId, $streamId);
$officerStmt->execute();
$officerResult = $officerStmt->get_result();

// Fetch officer details data
$officerDetails = [];
while ($row = $officerResult->fetch_assoc()) {
    $officerDetails[] = $row;
}

// Check for errors
if (!$officerResult) {
    die('Error fetching officer details: ' . $mysqli->error);
}

// Prepare data for the chart
$labels = [];
$collectedAmounts = [];
$targetAmounts = [];

foreach ($officerDetails as $detail) {
    $labels[] = $detail['officer_name'];
    $collectedAmounts[] = (int)$detail['collected_amount'];
    $targetAmounts[] = (int)$detail['target_amount'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('../partials/head.php'); ?>
    <title>Officer Details</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Style to reduce chart size */
        #officerChart {
            max-width: 600px;
            /* Adjust as needed */
            max-height: 300px;
            /* Adjust as needed */
            width: 100%;
            height: auto;
        }
    </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Preloader -->
        <?php include('../partials/preloader.php'); ?>

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/executive_sidenav.php'); ?>
         <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Officer Details</h1>
                        <small>Details of officers for <?php echo htmlspecialchars($wardName); ?> and Stream: <?php echo htmlspecialchars($streamName); ?></small>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>

        <!-- Main content -->
        <div class="container-fluid">
            <!-- Officer Details Table -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title m-0">Officer Details</h5>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Officer Name</th>
                                        <th>Collected Amount</th>
                                        <th>Target Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($officerDetails)) { ?>
                                        <tr>
                                            <td colspan="3" class="text-center">No data available</td>
                                        </tr>
                                        <?php } else {
                                        foreach ($officerDetails as $detail) { ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($detail['officer_name']); ?></td>
                                                <td><?php echo number_format($detail['collected_amount'], 0); ?> Ksh</td>
                                                <td><?php echo number_format($detail['target_amount'], 0); ?> Ksh</td>
                                            </tr>
                                    <?php }
                                    } ?>
                                </tbody>
                            </table>

                            <!-- Chart -->
                            <canvas id="officerChart"></canvas>
                            <script>
                                var ctx = document.getElementById('officerChart').getContext('2d');
                                var officerChart = new Chart(ctx, {
                                    type: 'bar',
                                    data: {
                                        labels: <?php echo json_encode($labels); ?>,
                                        datasets: [{
                                            label: 'Collected Amount',
                                            data: <?php echo json_encode($collectedAmounts); ?>,
                                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                            borderColor: 'rgba(54, 162, 235, 1)',
                                            borderWidth: 1
                                        }, {
                                            label: 'Target Amount',
                                            data: <?php echo json_encode($targetAmounts); ?>,
                                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                                            borderColor: 'rgba(255, 99, 132, 1)',
                                            borderWidth: 1
                                        }]
                                    },
                                    options: {
                                        responsive: true,
                                        scales: {
                                            y: {
                                                beginAtZero: true
                                            }
                                        }
                                    }
                                });
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 </div>
        <!-- /.container-fluid -->
    </div>
    <!-- ./wrapper -->
    <?php include('../partials/scripts.php'); ?>
</body>

</html>