<?php
/*
 *   Crafted On Mon 8th Aug 2024
 *   Author ndundastevn@gmail.com
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();
require_once('../config/config.php');
require_once('../config/checklogin.php');
require_once('../helpers/target.php');
require_once('../functions/reusableQuery.php');
require_once('../partials/head.php');
$ward= selectOne('ward', ['ward_id' => $_GET['id']]);

/** Total Ward target*/
$query = "SELECT SUM(collection_amount) FROM revenue_collections
		WHERE collection_ward_id = '{$_GET['id']}'";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($wardCollectionss);
$stmt->fetch();
$stmt->close();
?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <?php include('../partials/preloader.php'); ?>

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/admin_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"> <?php echo $ward['ward_name']?> Ward Collections</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Revenue Collections</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

			<!-- widgets -->
			<div class="container-fluid">
				<!-- Small boxes (Stat box) -->				
				<!-- /.row -->
				<div class="row">
					<div class="col-md-4 col-sm-6 col-12">
						<a href="revenue_target" class="text-dark">
							<div class="info-box">
							<span class="info-box-icon bg-info"><i class="far fa-flag"></i></span>

							<div class="info-box-content">
								<span class="info-box-text">Collections</span>
								<span class="info-box-number"><?php echo $wardCollectionss; ?> Ksh</span>
							</div>
							<!-- /.info-box-content -->
							</div>
						</a>
						<!-- /.info-box -->
					</div>
					<!-- /.col --> 				
				</div>       		
				<!-- /.row (main row) -->
			</div>
			<!-- /.container-fluid -->
			 
			 <!-- Main content -->
			 <div class="content">                
				<div class="container">
					<!-- row  -->
                    <div class="row">
                        <!-- system users dashboard -->
                        <div class="col-lg-12">
							<div class="card card-primary card-outline">
								
								<!-- /.card-header -->
								<div class="card-body">
									<table id="example1" class="table table-bordered table-striped">
										<thead>                  
											<tr>
												<th style="width: 10px">#</th>
												<th>Stream</th>
												<th>Target</th>																				
												<th>Collections</th>																				
												<th>Target Achieved</th>												
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
										<?php
                                        $fetch_records_sql = mysqli_query(
                                            $mysqli,
                                            
											"SELECT * FROM streamtarget st
											INNER JOIN revenue_streams s ON st.streamtarget_stream_id = s.stream_id 
											WHERE streamtarget_ward_id = '{$_GET['id']}'"
											// "SELECT * FROM streamtarget st INNER JOIN ward w ON w.ward_id = st.streamtarget_ward_id"

                                        );
                                        if (mysqli_num_rows($fetch_records_sql) > 0) {
                                            $cnt =  1;
                                            while ($rows = mysqli_fetch_array($fetch_records_sql)) {
                                        ?>
                                                <tr>
                                                    <td>
                                                        <?php echo $cnt; ?>
                                                    </td>                                                    
													<td>
														<?php echo $rows['stream_name']; ?>
													</td>                                                 
                                                    <td>
														<?php 
														/** Total stream Annual target */
														$query = "SELECT streamtarget_amount FROM streamtarget
														WHERE streamtarget_ward_id = '{$ward['ward_id']}'";
														$stmt = $mysqli->prepare($query);
														$stmt->execute();
														$stmt->bind_result($streamAmont);
														$stmt->fetch();
														$stmt->close();
														echo $streamAmont;
														?>
                                                    </td>
                                                    <td>
														<?php 
														$query = "SELECT SUM(collection_amount) FROM revenue_collections
														WHERE collection_ward_id = '{$_GET['id']}'
														AND collection_stream_id = '{$rows['streamtarget_stream_id']}'
														";
														$stmt = $mysqli->prepare($query);
														$stmt->execute();
														$stmt->bind_result($collectedAmount);
														$stmt->fetch();
														$stmt->close();
														echo $collectedAmount
														?>
                                                    </td>
                                                    <td>
                                                        <?php 
														if($collectedAmount>0){
															$collPercent = ($collectedAmount*100) / $streamAmont;

														}else{
															$collPercent =0;
														}
														echo $collPercent.'%';
														?>
                                                    </td>
                                                    <td>
                                                        <a data-toggle="modal" href="#updateStreamTarget_<?php echo $rows['streamtarget_id'] ?>" class="badge badge-primary"><i class="fas fa-edit"></i> View</a>
                                                    </td>
                                                </tr>
                                        <?php
                                                $cnt = $cnt + 1;
                                                include('../modals/targets.php');
                                            }
                                        } ?>
                                    </tbody>
																					
										</tbody>										
									</table>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
                        </div>
                    </div>
                    <!-- /.row -->
				</div>
            </div>
            <!-- /.content -->

			<!-- Add target modal -->
			<div class="row">
				<div class="modal fade fixed-right" id="addTarget" role="dialog" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header align-items-center">
								<div class="text-center">
									<h6 class="mb-0 text-bold">Register new targets</h6>
								</div>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
									<div class="row">										
										<div class="form-group col-sm-4 col-lg-6 col-xl-6">
											<label class="form-control-label"> Ward <span class="text-danger">*</span></label>
											<div class="input-group input-group-merge">
												<!-- <input type="hidden" required name="user_ward_id" class="form-control"> -->
												<select type="text" required name="target_ward_id" class="form-control">
													<?php
													$fetch_services_sql = mysqli_query(
														$mysqli,
														"SELECT * FROM ward"
													);
													if (mysqli_num_rows($fetch_services_sql) > 0) {
														while ($services = mysqli_fetch_array($fetch_services_sql)) {
													?>
															<option value="<?php echo $services['ward_id']; ?>"><?php echo $services['ward_name']; ?></option>
													<?php }
													} ?>
												</select>
											</div>
										</div>
										<div class="form-group col-sm-4 col-lg-6 col-xl-6">
											<label class="form-control-label"> Financial Year <span class="text-danger">*</span></label>
											<div class="input-group input-group-merge">
												<input type="text" required name="target_financial_year" class="form-control">												
											</div>
										</div>
									</div>
									<div class="row">	
																	
										<div class="form-group col-sm-12 col-lg-12 col-xl-12">
											<label class="form-control-label">Target Amount <span class="text-danger">*</span></label>
											<div class="input-group input-group-merge">
												<input type="text" required name="target_amount" class="form-control">
											</div>
										</div>

															
										
										<!-- <?php 
										$datas = selectMany('revenue_streams');
										foreach ($datas as $key => $stream) {
											# code...
										?>									
										<div class="form-group col-sm-12 col-lg-6 col-xl-6">
											<label class="form-control-label"><?php $stream['stream_name'] ?> <span class="text-danger">*</span></label>
											<div class="input-group input-group-merge">
												<input type="text" name="streamtarget_stream_id" hidden value="<?php $stream['stream_id'] ?>" class="form-control">
												<input type="text" required name="streamtarget_amount" class="form-control">
											</div>
										</div>
										<?php } ?>
																				 -->
									</div>
									<div class="text-right">
										<button type="submit" name="addTarget" class="btn btn-outline-success">Add Target</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- ./ Add target modal -->
            
        </div>
        <!-- /.content-wrapper -->
        <?php include('../partials/footer.php'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <?php include('../partials/scripts.php'); ?>
</body>

</html>

