<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once('../config/config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include('../partials/head.php'); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
    <style>
        .filter-form .form-control {
            margin-bottom: 10px;
        }

        .card-header {
            background-color: #f4f6f9;
        }

        .chart-container {
            margin-top: 20px;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <?php include('../partials/preloader.php'); ?>

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/executive_sidenav.php'); ?>

    <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Performance Reports</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../views/dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Performance Reports</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Filters -->
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Filters</h3>
                </div>
                <div class="card-body">
                    <form id="filter-form">
                        <div class="form-row">
                            <div class="col-md-3">
                                <label for="ward">Ward</label>
                                <select id="ward" name="ward" class="form-control">
                                    <!-- Options will be populated dynamically -->
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="stream">Stream</label>
                                <select id="stream" name="stream" class="form-control">
                                    <!-- Options will be populated dynamically -->
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="period">Period</label>
                                <input type="date" id="start_date" name="start_date" class="form-control">
                                <input type="date" id="end_date" name="end_date" class="form-control mt-2">
                            </div>
                            <div class="col-md-3">
                                <label for="type">Type</label>
                                <select id="type" name="type" class="form-control">
                                    <option value="tabular">Tabular</option>
                                    <option value="graphical">Graphical</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="total">Total</label>
                                <input type="text" id="total" name="total" class="form-control" readonly>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary mt-3" onclick="fetchReport()">Generate Report</button>
                        <button type="button" id="generate_pdf" class="btn btn-primary mt-3">Download PDF</button>
                    </form>
                </div>

            </div>

            <!-- Report Output -->
            <div id="report-output" class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Report</h3>
                </div>
                <div class="card-body">
                    <!-- This section will be dynamically updated -->
                    <div id="table-container" class="d-none">
                        <!-- Table will be inserted here -->

                    </div>
                    <div id="chart-container" class="d-none">
                        <!-- Chart will be inserted here -->
                        <canvas id="report-chart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <?php include('../partials/scripts.php'); ?>
        <!-- REQUIRED SCRIPTS -->
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            document.getElementById('generate_pdf').addEventListener('click', function() {
                // Get the HTML content of the table container
                var tableHtml = document.getElementById('table-container').innerHTML;
                var totalAmount = document.getElementById('total').value;

                // Create a FormData object
                var formData = new FormData();
                formData.append('tableHtml', tableHtml);
                formData.append('totalAmount', totalAmount);

                // Send the HTML content and total amount to the server
                fetch('../partials/generate_pdf.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok.');
                        }
                        return response.blob(); // Retrieve the PDF as a blob
                    })
                    .then(blob => {
                        // Create a URL for the PDF blob
                        var url = URL.createObjectURL(blob);
                        // Create a link element to download the PDF
                        var a = document.createElement('a');
                        a.href = url;
                        a.download = 'report.pdf';
                        document.body.appendChild(a);
                        a.click();
                        // Clean up the URL object
                        URL.revokeObjectURL(url);
                    })
                    .catch(error => {
                        console.error('Error generating PDF:', error);
                    });
            });
        </script>
        <script>
            // Store the mapping of IDs to names
            let wardNameMap = {};
            let streamNameMap = {};

            function populateDropdown(elementId, items) {
                const dropdown = document.getElementById(elementId);
                if (dropdown) {
                    dropdown.innerHTML = '<option value="all">All</option>'; // Reset with "All" option

                    items.forEach(item => {
                        let optionText = elementId === 'ward' ? item.ward_name : item.stream_name;
                        let optionValue = elementId === 'ward' ? item.ward_id : item.stream_id;

                        // Store the mapping
                        if (elementId === 'ward') {
                            wardNameMap[optionValue] = optionText;
                        } else {
                            streamNameMap[optionValue] = optionText;
                        }

                        const option = document.createElement('option');
                        option.value = optionValue;
                        option.textContent = optionText;
                        dropdown.appendChild(option);
                    });
                } else {
                    console.error(`Element with ID ${elementId} not found.`);
                }
            }
            document.addEventListener('DOMContentLoaded', () => {
                fetch('../helpers/report-api.php?action=fetchOptions')
                    .then(response => response.json())
                    .then(data => {
                        if (data.wards && data.streams) {
                            populateDropdown('ward', data.wards);
                            populateDropdown('stream', data.streams);
                        } else {
                            console.error('Data format is incorrect:', data);
                        }
                    })
                    .catch(error => console.error('Error fetching options:', error));
            });

            function fetchReport() {
                const formData = new FormData(document.getElementById('filter-form'));

                fetch('../helpers/report-api.php', {
                        method: 'POST',
                        body: new URLSearchParams(formData)
                    })
                    .then(response => response.json())
                    .then(data => {
                        const reportType = document.getElementById('type').value;
                        const totalInput = document.getElementById('total');

                        // Handle table display
                        const tableContainer = document.getElementById('table-container');
                        if (tableContainer) {
                            if (reportType === 'tabular') {
                                if (data.tableHTML) {
                                    // Replace Ward IDs with Ward Names using wardNameMap
                                    let tableHTML = data.tableHTML.replace(/<td>(\d+)<\/td>(?=<td>[^<]+<\/td><td>[^<]+<\/td>)/g, function(match, wardId) {
                                        return `<td>${wardNameMap[wardId] || 'Unknown Ward'}</td>`;
                                    });

                                    tableContainer.innerHTML = `
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Ward Name</th>
                                        <th>Stream Name</th>
                                        <th>Collected Amount</th>
                                        <th>Target Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${tableHTML}
                                </tbody>
                            </table>
                        `;
                                    tableContainer.classList.remove('d-none');
                                } else {
                                    tableContainer.innerHTML = 'No data available';
                                    tableContainer.classList.remove('d-none');
                                }
                            } else {
                                tableContainer.classList.add('d-none');
                            }
                        }

                        // Handle chart display
                        const chartContainer = document.getElementById('chart-container');
                        if (chartContainer) {
                            if (reportType === 'graphical') {
                                if (data.chartData && data.chartData.labels.length > 0) {
                                    const chartCanvas = document.getElementById('report-chart');
                                    if (chartCanvas) {
                                        const ctx = chartCanvas.getContext('2d');
                                        // Clear the previous chart if it exists
                                        if (window.myChart) {
                                            window.myChart.destroy();
                                        }
                                        // Create a new chart
                                        window.myChart = new Chart(ctx, {
                                            type: 'bar',
                                            data: {
                                                labels: data.chartData.labels.map(label => wardNameMap[label] || label),
                                                datasets: [{
                                                        label: 'Collected Amount',
                                                        data: data.chartData.collectedAmounts,
                                                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                                        borderColor: 'rgba(75, 192, 192, 1)',
                                                        borderWidth: 1
                                                    },
                                                    {
                                                        label: 'Target Amount',
                                                        data: data.chartData.targetAmounts,
                                                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                                                        borderColor: 'rgba(153, 102, 255, 1)',
                                                        borderWidth: 1
                                                    }
                                                ]
                                            },
                                            options: {
                                                responsive: true,
                                                scales: {
                                                    y: {
                                                        beginAtZero: true
                                                    }
                                                }
                                            }
                                        });
                                        chartContainer.classList.remove('d-none');
                                    } else {
                                        console.error('Chart element not found.');
                                    }
                                } else {
                                    chartContainer.innerHTML = 'No chart data available';
                                    chartContainer.classList.remove('d-none');
                                }
                            } else {
                                chartContainer.classList.add('d-none');
                            }
                        }

                        // Update total
                        if (totalInput) {
                            totalInput.value = data.total || 0;
                        }
                    })
                    .catch(error => console.error('Error fetching report:', error));
            }

            document.getElementById('filter-form').addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission
                fetchReport(); // Call the function to handle the form data
            });
        </script>


</body>

</html>