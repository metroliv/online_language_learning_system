<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once('../config/config.php');
require_once('../partials/head.php');

// Fetch wards
$wards_query = "SELECT ward_id, ward_name FROM ward";
$wards_result = $mysqli->query($wards_query);

$wards = [];
while ($row = $wards_result->fetch_assoc()) {
    $wards[] = $row;
}

$targets_query = "SELECT 
    st.streamtarget_ward_id,
    w.ward_name,
    SUM(st.streamtarget_amount) AS total_target
FROM streamtarget st
JOIN ward w ON st.streamtarget_ward_id = w.ward_id
GROUP BY st.streamtarget_ward_id, w.ward_name";
$targets_result = $mysqli->query($targets_query);

$targets = [];
while ($row = $targets_result->fetch_assoc()) {
    $targets[$row['streamtarget_ward_id']] = $row['total_target'];
}

// Fetch revenue collections for each ward where the status is 'Approved'
$collections_query = "
    SELECT
        collection_ward_id,
        SUM(collection_amount) AS total_collected
    FROM revenue_collections
    WHERE collection_status = 'Approved'
    GROUP BY collection_ward_id
";
$collections_result = $mysqli->query($collections_query);

$collections = [];
while ($row = $collections_result->fetch_assoc()) {
    $collections[$row['collection_ward_id']] = $row['total_collected'];
}

// Prepare data for display with detailed performance statuses
$performance_data = [];
foreach ($wards as $ward) {
    $ward_id = $ward['ward_id'];
    $ward_name = $ward['ward_name'];
    $target = $targets[$ward_id] ?? 0;
    $collected = $collections[$ward_id] ?? 0;

    if ($collected == 0 && $target == 0) {
        $status = 'No Data';
    } elseif ($collected < ($target * 0.5)) {
        $status = 'Fair Performance';
    } elseif ($collected < ($target * 0.75)) {
        $status = 'Average Performance';
    } elseif ($collected < $target) {
        $status = 'Good Performance';
    } else {
        $status = 'Excellent';
    }


    $performance_data[] = [
        'ward_name' => $ward_name,
        'target' => number_format($target),
        'collected' => number_format($collected),
        'status' => $status
    ];
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ward Performance Overview</title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- AdminLTE Skins -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/skins/_all-skins.min.css">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="../public/css/styles.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Include Header -->
        <?php include('../partials/header.php'); ?>

        <!-- Include Sidebar -->
        <?php include('../partials/executive_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Ward Performance Overview</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../views/dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Ward Performance Overview</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div><!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Performance Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Ward</th>
                                    <th>Target Amount (KSh)</th>
                                    <th>Total Collected (KSh)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($performance_data as $data): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($data['ward_name']); ?></td>
                                        <td><?php echo $data['target']; ?></td>
                                        <td><?php echo $data['collected']; ?></td>
                                        <td><?php echo $data['status']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div><!-- /.container-fluid -->
            </section><!-- /.content -->
        </div><!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>

        <!-- Include Footer -->
        <?php include('../partials/footer.php'); ?>
    </div><!-- ./wrapper -->
    <?php include('../partials/scripts.php'); ?>
    <!-- AdminLTE and Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>