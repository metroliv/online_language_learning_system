<?php
// Start session if needed
session_start();
// Enable error reporting for troubleshooting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the necessary files
require_once('../config/config.php');
require_once('../partials/head.php');
require_once('../helpers/auth.php');



// Initialize variables
$start_date = date('Y-m-d', strtotime('first day of this month'));
$end_date = date('Y-m-d');

if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
}

// Query to get revenue collection data
$query = "
    SELECT DATE(collection_date) AS date, SUM(collection_amount) AS total_amount
    FROM revenue_collections
    WHERE collection_date BETWEEN '$start_date' AND '$end_date'
    AND collection_status = 'Approved'
    GROUP BY DATE(collection_date)
";

$result = $mysqli->query($query);

if (!$result) {
    die('Error executing query: ' . $mysqli->error);
}

// Prepare data for chart
$labels = [];
$collected_amount = [];

while ($row = $result->fetch_assoc()) {
    $labels[] = $row['date'];
    $collected_amount[] = $row['total_amount'];
}

// Close the database connection
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once('../partials/head.php'); ?>
    <!-- Add daterangepicker CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
</head>
<body class="hold-transition sidebar-mini">
    
<div class="wrapper">
<?php include('../partials/header.php');?>
    <!-- Include Sidebar -->
    <?php include('../partials/executive_sidenav.php'); ?>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        
        <div class="content-header">
            <div class="container">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo $greeting . ', ' . $_SESSION['user_names']; ?>
                        </h1>
                        <small>Welcome to Department of Finance Revenue Collection Tool</small>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="../views/dashboard.php">Home</a></li>
                            <li class="breadcrumb-item active">Revenue Trend</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Date Range Picker -->
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Select Date Range</h3>
                            </div>
                            <div class="card-body">
                                <input type="text" id="daterange" class="form-control" />
                            </div>
                        </div>

                        <!-- Chart Display -->
                        <div class="card card-success">
                            <div class="card-header">
                                <h3 class="card-title">Total Amount Collected</h3>
                            </div>
                            <div class="card-body">
                                <!-- Adjust the size of the canvas element -->
                                <canvas id="revenueChart" style="width: 100%; height: 300px;"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <?php include('../partials/footer.php'); ?>
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>

</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap 4 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script>
<!-- Daterangepicker -->
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php include('../partials/scripts.php'); ?>
<script>
    // Initialize the Date Range Picker
    $('#daterange').daterangepicker({
        startDate: moment().startOf('month'),
        endDate: moment(),
        opens: 'left',
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment()],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, function(start, end) {
        // Reload the page with the selected date range as query parameters
        window.location.href = `?start_date=${start.format('YYYY-MM-DD')}&end_date=${end.format('YYYY-MM-DD')}`;
    });

    // Initialize the chart
    var ctx = document.getElementById('revenueChart').getContext('2d');
    var revenueChart = new Chart(ctx, {
        type: 'bar',  // Keep chart type as 'bar'
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Total Amount Collected',
                data: <?php echo json_encode($collected_amount); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            responsive: true, // Ensure the chart resizes based on the container size
            maintainAspectRatio: false, // Prevent maintaining the aspect ratio
        }
    });
</script>

</body>
</html>
