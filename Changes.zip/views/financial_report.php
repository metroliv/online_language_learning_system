<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once('../config/config.php');
require_once('../partials/head.php');

// Fetch distinct financial years from the streamtarget table
$query = "SELECT DISTINCT streamtarget_fy AS financial_year FROM streamtarget";
$result = $mysqli->query($query);

$financial_years = [];
while ($row = $result->fetch_assoc()) {
    $financial_years[] = $row['financial_year'];
}

// Check if a financial year is selected
$selected_year = $_GET['year'] ?? null;
$report_data = [];

if ($selected_year) {
    // Fetch revenue target and collections for the selected financial year
    $query = "
        SELECT
            w.ward_name,
            SUM(st.streamtarget_amount) AS target,
            COALESCE(SUM(c.collection_amount), 0) AS total_collected
        FROM streamtarget st
        LEFT JOIN revenue_collections c ON st.streamtarget_ward_id = c.collection_ward_id
        LEFT JOIN ward w ON st.streamtarget_ward_id = w.ward_id
        WHERE st.streamtarget_fy = ?
        AND c.collection_status = 'approved'
        GROUP BY w.ward_name
    ";
    
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('s', $selected_year);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $row['performance'] = ($row['target'] > 0) ? ($row['total_collected'] / $row['target']) * 100 : 0;
        $report_data[] = $row;
    }

    $stmt->close();
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Year Reports</title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- AdminLTE Skins -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/skins/_all-skins.min.css">
    <!-- Custom Styles -->
    <link rel="stylesheet" href="../public/css/styles.css">
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Include Header -->
        <?php include('../partials/header.php'); ?>

        <!-- Include Sidebar -->
        <?php include('../partials/executive_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Financial Year Reports</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../views/dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Financial Year Reports</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div><!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid mt-3">
                    <!-- Financial Year Selector -->
                    <div class="form-group">
                        <label for="financial_year">Select Financial Year:</label>
                        <select id="financial_year" class="form-control" onchange="window.location.href = '?year=' + this.value;">
                            <option value="">-- Select Year --</option>
                            <?php foreach ($financial_years as $year): ?>
                                <option value="<?php echo htmlspecialchars($year); ?>" <?php echo ($selected_year == $year) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($year); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Report Container -->
                    <div id="report_container">
                        <?php if ($selected_year && $report_data): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Report for Financial Year: <?php echo htmlspecialchars($selected_year); ?></h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Ward</th>
                                                <th>Target (KSh)</th>
                                                <th>Total Collected (KSh)</th>
                                                <th>Performance (%)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($report_data as $row): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($row['ward_name']); ?></td>
                                                    <td><?php echo number_format($row['target']); ?></td>
                                                    <td><?php echo number_format($row['total_collected']); ?></td>
                                                    <td><?php echo number_format($row['performance'], 2); ?>%</td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php elseif ($selected_year): ?>
                            <p class="text-danger">No data available for the selected financial year.</p>
                        <?php else: ?>
                            <p>Please select a financial year to view the report.</p>
                        <?php endif; ?>
                    </div>
                </div><!-- /.container-fluid -->
            </section><!-- /.content -->
        </div><!-- /.content-wrapper -->

        <!-- Include Footer -->
        <?php include('../partials/footer.php'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
    </div><!-- ./wrapper -->

    <!-- AdminLTE and Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
