<?php include('../helpers/ward_perfomance_query.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include('../partials/head.php'); ?>
    <title>Ward Performance Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@5.15.4/css/all.min.css">
    <style>
        .chart-container {
            position: relative;
            height: 500px; /* Increased height */
            width: 100%; /* Full width */
        }
        .content-wrapper {
            padding: 20px; /* Ensure padding for content */
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <section class="content">
                <div class="container-fluid">
                    <!-- Performance vs Target by Ward (Line Chart) -->
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title">Performance vs Target by Ward</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="performanceChart"></canvas>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <?php include('../partials/footer.php'); ?>
    </div>
    <!-- ./wrapper -->

    <script>
        // JavaScript to render the chart
        document.addEventListener('DOMContentLoaded', function() {
            var ctxLine = document.getElementById('performanceChart').getContext('2d');
            var performanceChart = new Chart(ctxLine, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($wards); ?>,
                    datasets: [{
                        label: 'Target Amount',
                        data: <?php echo json_encode($targets); ?>,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2,
                        fill: false
                    }, {
                        label: 'Collected Amount',
                        data: <?php echo json_encode($collected); ?>,
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 2,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                display: true,
                                color: '#e3e3e3'
                            }
                        },
                        x: {
                            grid: {
                                display: true,
                                color: '#e3e3e3'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                            labels: {
                                color: '#333'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.7)',
                            titleColor: '#fff',
                            bodyColor: '#fff'
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>
