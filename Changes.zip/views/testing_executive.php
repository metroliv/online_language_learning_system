<?php
// Start session and connect to the database
session_start();
require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../partials/head.php');

// Fetch total amount collected per stream for the executive dashboard
$query_collected = "
    SELECT rss.stream_name, 
           COALESCE(SUM(rc.collection_amount), 0) AS total_collected
    FROM revenue_collections rc
    LEFT JOIN revenue_streams rss ON rc.collection_stream_id = rss.stream_id
    WHERE rc.collection_status = 'Approved'
    GROUP BY rss.stream_name
";
$result_collected = mysqli_query($mysqli, $query_collected);

if (!$result_collected) {
    die("Database query failed: " . mysqli_error($mysqli));
}

// Fetch target amount per stream
$query_target = "
    SELECT rss.stream_name, 
           COALESCE(SUM(ct.collectortarget_amount), 0) AS target_amount
    FROM collectortarget ct
    LEFT JOIN revenue_streams rss ON ct.collectortarget_streamtarget_id = rss.stream_id
    GROUP BY rss.stream_name
";
$result_target = mysqli_query($mysqli, $query_target);

if (!$result_target) {
    die("Database query failed: " . mysqli_error($mysqli));
}

// Initialize arrays for chart data
$stream_data = [];
$collected_amount_data = [];
$target_amount_data = [];

// Process collected data
while ($row = mysqli_fetch_assoc($result_collected)) {
    $stream_name = $row['stream_name'];
    $stream_data[] = $stream_name;
    $collected_amount_data[$stream_name] = $row['total_collected'];
}

// Process target data
while ($row = mysqli_fetch_assoc($result_target)) {
    $stream_name = $row['stream_name'];
    if (isset($collected_amount_data[$stream_name])) {
        $target_amount_data[$stream_name] = $row['target_amount'];
    } else {
        // Ensure that we add the target even if there's no collected amount
        $stream_data[] = $stream_name;
        $collected_amount_data[$stream_name] = 0; // Default to 0 if no collected amount
        $target_amount_data[$stream_name] = $row['target_amount'];
    }
}

// Prepare data for chart
$collected_amount_data = array_values($collected_amount_data);
$target_amount_data = array_values($target_amount_data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Dashboard</title>
    <link rel="stylesheet" href="path/to/your/css/style.css"> <!-- Include your CSS file -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js library -->
</head>
<body>
<!-- Executive Dashboard Content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <!-- BAR CHART for comparison -->
                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title">Total Amount Collected vs Target per Stream</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart">
                            <canvas id="executiveComparisonChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<script>
    var ctx = document.getElementById('executiveComparisonChart').getContext('2d');
    var executiveComparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($stream_data); ?>,
            datasets: [{
                label: 'Total Amount Collected',
                data: <?php echo json_encode($collected_amount_data); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }, {
                label: 'Target Amount',
                data: <?php echo json_encode($target_amount_data); ?>,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</body>
</html>
