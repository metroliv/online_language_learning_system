<?php
/*
 *   Crafted On Mon Jul 29 2024
 *   Author Stephen Ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();

require_once('../functions/reusableQuery.php');
require_once('../functions/ward_reciever_analytics.php');
require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../helpers/receiver_reports.php');
require_once('../helpers/users.php');
require_once('../partials/headn.php');
//dd($_SESSION['user_ward_id']);

if (isset($_GET['status'])) {
	//dd($_GET);
	// Given date range
	$dateRange = $_GET['date'];

	// Separate the dates
	list($startDate, $endDate) = explode(' - ', $dateRange);

	// Convert the dates to the format YYYY-MM-DD for SQL
	$startDateFormatted = date('Y-m-d', strtotime($startDate));
	$endDateFormatted = date('Y-m-d', strtotime($endDate));

	if ($_GET['status'] === 'All') {
		$status = "'Approved', 'Rejected', 'Pending'";
		$mystatus = "All";
	}
	if ($_GET['status'] === 'Approved') {
		$status = "'Approved'";
		$mystatus = "Approved";
	}
	if ($_GET['status'] === 'Rejected') {
		$status = "'Rejected'";
		$mystatus = "Rejected";
	}
	if ($_GET['status'] === 'Pending') {
		$status = "'Pending'";
		$mystatus = "Pending";
	}
	//dd($status);

	$fy = $_GET['fy'];
} else { // in the event $_get vaiable has no data
	$status = 'Pending';
	$mystatus = "Pending";
	$startDateFormatted = date('Y-m-d');
	$endDateFormatted = date('Y-m-d');
	$fy = "2024/2025";
}

?>

<body class="hold-transition sidebar-mini layout-fixed">
	<div class="wrapper">

		<!-- Preloader -->
		<?php include('../partials/preloader.php'); ?>

		<!-- Navbar -->
		<?php include('../partials/header.php'); ?>
		<!-- /.navbar -->

		<!-- Main Sidebar Container -->
		<?php include('../partials/ward_admin_sidenav.php'); ?>

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<div class="content-header">
				<div class="container">
					<div class="row mb-2">
						<div class="col-sm-6">
							<h1 class="m-0">
								<?php $ward_name['ward_name'] . ' Ward,' ?>
								<?php echo $mystatus ?>
								Collection Reports </h1>
						</div><!-- /.col -->
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"><a href="dashboard">Home</a></li>
								<li class="breadcrumb-item active">Ward Staff</li>
							</ol>
						</div><!-- /.col -->
					</div><!-- /.row -->
				</div><!-- /.container-fluid -->
			</div>
			<!-- /.content-header -->

			<!-- Select date filters -->
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title m-0">Revenue Collection Reports</h5>
							</div>
							<div class="card-body">
								<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
									<div class="row">
										<div class="col-md-3">
											<label for="ward">Status</label>
											<select id="ward" required name="report_status" class="form-control">
												<option value="">Select</option>
												<option value="Pending">Pending</option>
												<option value="Approved">Approved</option>
												<option value="Rejected">Rejected</option>
												<option value="All">All Reports</option>
											</select>
										</div>

										<!-- <div class="form-group col-sm-3 col-lg-3 col-xl-3">
												<button type="button" class="btn btn-default float-right" id="daterange-btn">
												<i class="far fa-calendar-alt"></i> Date range picker
												<i class="fas fa-caret-down"></i>
												</button>
												<input type="text" name="dates" class="form-control float-right" id="reportrange">
											</div> -->

										<!-- Date range -->
										<div class="form-group col-lg-3 col-xl-3">
											<label>Date range:</label>
											<div class="input-group">
												<div class="input-group-prepend">
													<span class="input-group-text">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" name="daterange" class="form-control float-right" id="reservation">
											</div>
											<!-- /.input group -->
										</div>

										<div class="col-md-3">
											<label for="ward">Financial Year</label>
											<select id="ward" name="fy" class="form-control">
												<option value="2024/2025">2024/2025</option>
											</select>
										</div>

										<div class="col-md-3">
											<label for="stream">Action</label>
											<button type="submit" class="btn btn-primary form-control" name="filterReports">Search</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- ./ Select date -->

			<!-- Main content -->
			<div class="content mt-2">
				<div class="container">
					<!-- row  -->
					<div class="row">
						<!-- system users dashboard -->
						<div class="col-lg-12">
							<div class="card card-primary card-outline">

								<!-- /.card-header -->
								<div class="card-body">
									<table id="example1" class="table table-bordered table-striped">
										<thead>
											<tr>
												<th style="width: 10px">#</th>
												<th>Office Name</th>
												<th>Stream</th>
												<th>Service</th>
												<th>Amount</th>
												<th>Location</th>
												<th>Date</th>
												<th>Status</th>
												<th>Actions</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$fetch_records_sql = mysqli_query(
												$mysqli,
												"SELECT * FROM revenue_collections rc
                                                INNER JOIN users u ON u.user_id = rc.collection_user_id 
												INNER JOIN revenue_streams rss ON rss.stream_id = rc.collection_stream_id
                                                INNER JOIN revenue_services rs ON rs.service_id = rc.collection_service_id
                                                INNER JOIN ward w ON w.ward_id = rc.collection_ward_id 
												WHERE rc.collection_ward_id = '{$_SESSION['user_ward_id']}'
												AND rc.collection_status IN ({$status})												
												 "
											);
											// AND DATE(rc.collection_date) BETWEEN '{$startDateFormatted}' AND '{$endDateFormatted}'										



											if (mysqli_num_rows($fetch_records_sql) > 0) {
												$cnt =  1;
												while ($rows = mysqli_fetch_array($fetch_records_sql)) {
											?>
													<tr>
														<td>
															<?php echo $cnt; ?>
														</td>
														<td>
															<?php echo $rows['user_names']; ?>
														</td>
														<td>
															<?php echo $rows['stream_name']; ?>
														</td>
														<td>
															<?php echo $rows['service_name']; ?>
														</td>
														<td>
															<?php echo $rows['collection_amount']; ?>
														</td>
														<td>
															<?php echo $rows['collection_location']; ?>
														</td>
														<td>
															<?php echo $rows['collection_date']; ?>
														</td>
														<td>
															<?php echo $rows['collection_status']; ?>
														</td>
														<td>
															<?php
															if ($rows['collection_status'] === 'Approved') {
															?>
																<span class="badge badge-success"><i class="fas fa-check"></i> Approved</span>
															<?php
															} else {
															?>
																<!-- <a data-toggle="modal" href="?id=" class="badge badge-primary"><i class="fas fa-eye"></i> Aprove</a> -->
																<a data-toggle="modal" href="#approve_<?php echo $rows['collection_id']; ?>" class="badge badge-primary"><i class="fas fa-pen"></i> Approve</a>
																<a data-toggle="modal" href="#decline_<?php echo $rows['collection_id']; ?>" class="badge badge-danger"><i class="fas fa-trash"></i> Decline</a>

															<?php } ?>
														</td>
													</tr>
											<?php
													$cnt = $cnt + 1;
													include('../modals/pending_approvals.php');
												}
											} ?>
										</tbody>
									</table>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
						</div>
					</div>


					<!-- Add user modal -->
					<?php include('../modals/users.php'); ?>

					<!-- filters modal-->
					<div class="modal fade fixed-right" id="filterDashboard" role="dialog" aria-hidden="true">
						<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
							<div class="modal-content">
								<div class="modal-header align-items-center">
									<div class="text-center">
										<h6 class="mb-0 text-bold">Filter</h6>
									</div>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body">
									<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
										<div class="row">
											<div class="form-group col-sm-6 col-lg-6 col-xl-6">
												<label class="form-control-label">Status <span class="text-danger">*</span></label>
												<div class="input-group input-group-merge">
													<select type="text" required name="month" class="form-control">
														<option value="">All reports</option>
														<option value="">Pending</option>
														<option value="">Approved</option>
														<option value="">Rejected</option>
														<option value="">April</option>

													</select>
												</div>
											</div>
											<!-- Date and time range -->
											<div class="form-group col-sm-6 col-lg-6 col-xl-6">
												<label>Date range button:</label>

												<div class="form-group col-sm-6 col-lg-6 col-xl-6">
													<button type="button" class="btn btn-default float-right" id="daterange-btn">
														<i class="far fa-calendar-alt"></i> Date range picker
														<i class="fas fa-caret-down"></i>
													</button>
													<input type="text" class="form-control float-right" id="daterange-btn">

												</div>
											</div>
											<div class="form-group col-sm-6 col-lg-6 col-xl-6">
												<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
												<div class="input-group input-group-merge">
													<select type="text" required name="fy" class="form-control">
														<option value="">2024/2025</option>

													</select>
												</div>
											</div>

										</div>
										<div class="text-right">
											<button type="submit" name="AddCollection" class="btn btn-outline-success">Search</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<!-- ./ modal -->

				</div>
				<!-- /.content-wrapper -->
				<?php include('../partials/footer.php'); ?>

				<!-- Control Sidebar -->
				<aside class="control-sidebar control-sidebar-dark">
					<!-- Control sidebar content goes here -->
				</aside>
				<!-- /.control-sidebar -->
			</div>
			<!-- ./wrapper -->

			<!-- scripts -->
			<?php include('../partials/scriptn.php'); ?>

			<!-- page scripts -->
			<script>
				$(function() {
					//Initialize Select2 Elements
					$('.select2').select2()

					//Initialize Select2 Elements
					$('.select2bs4').select2({
						theme: 'bootstrap4'
					})

					//Datemask dd/mm/yyyy
					$('#datemask').inputmask('dd/mm/yyyy', {
						'placeholder': 'dd/mm/yyyy'
					})
					//Datemask2 mm/dd/yyyy
					$('#datemask2').inputmask('mm/dd/yyyy', {
						'placeholder': 'mm/dd/yyyy'
					})
					//Money Euro
					$('[data-mask]').inputmask()

					//Date picker
					$('#reservationdate').datetimepicker({
						format: 'L'
					});

					//Date and time picker
					$('#reservationdatetime').datetimepicker({
						icons: {
							time: 'far fa-clock'
						}
					});

					//Date range picker
					$('#reservation').daterangepicker()
					//Date range picker with time picker
					$('#reservationtime').daterangepicker({
						timePicker: true,
						timePickerIncrement: 30,
						locale: {
							format: 'MM/DD/YYYY hh:mm A'
						}
					})
					//Date range as a button
					$('#daterange-btn').daterangepicker({
							ranges: {
								'Today': [moment(), moment()],
								'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
								'Last 7 Days': [moment().subtract(6, 'days'), moment()],
								'Last 30 Days': [moment().subtract(29, 'days'), moment()],
								'This Month': [moment().startOf('month'), moment().endOf('month')],
								'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
							},
							startDate: moment().subtract(29, 'days'),
							endDate: moment()
						},
						function(start, end) {
							$('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
						}
					)

					//Timepicker
					$('#timepicker').datetimepicker({
						format: 'LT'
					})

					//Bootstrap Duallistbox
					$('.duallistbox').bootstrapDualListbox()

					//Colorpicker
					$('.my-colorpicker1').colorpicker()
					//color picker with addon
					$('.my-colorpicker2').colorpicker()

					$('.my-colorpicker2').on('colorpickerChange', function(event) {
						$('.my-colorpicker2 .fa-square').css('color', event.color.toString());
					})

					$("input[data-bootstrap-switch]").each(function() {
						$(this).bootstrapSwitch('state', $(this).prop('checked'));
					})

				})
				// BS-Stepper Init
				document.addEventListener('DOMContentLoaded', function() {
					window.stepper = new Stepper(document.querySelector('.bs-stepper'))
				})

				// DropzoneJS Demo Code Start
				Dropzone.autoDiscover = false

				// Get the template HTML and remove it from the doumenthe template HTML and remove it from the doument
				var previewNode = document.querySelector("#template")
				previewNode.id = ""
				var previewTemplate = previewNode.parentNode.innerHTML
				previewNode.parentNode.removeChild(previewNode)

				var myDropzone = new Dropzone(document.body, { // Make the whole body a dropzone
					url: "/target-url", // Set the url
					thumbnailWidth: 80,
					thumbnailHeight: 80,
					parallelUploads: 20,
					previewTemplate: previewTemplate,
					autoQueue: false, // Make sure the files aren't queued until manually added
					previewsContainer: "#previews", // Define the container to display the previews
					clickable: ".fileinput-button" // Define the element that should be used as click trigger to select files.
				})

				myDropzone.on("addedfile", function(file) {
					// Hookup the start button
					file.previewElement.querySelector(".start").onclick = function() {
						myDropzone.enqueueFile(file)
					}
				})

				// Update the total progress bar
				myDropzone.on("totaluploadprogress", function(progress) {
					document.querySelector("#total-progress .progress-bar").style.width = progress + "%"
				})

				myDropzone.on("sending", function(file) {
					// Show the total progress bar when upload starts
					document.querySelector("#total-progress").style.opacity = "1"
					// And disable the start button
					file.previewElement.querySelector(".start").setAttribute("disabled", "disabled")
				})

				// Hide the total progress bar when nothing's uploading anymore
				myDropzone.on("queuecomplete", function(progress) {
					document.querySelector("#total-progress").style.opacity = "0"
				})

				// Setup the buttons for all transfers
				// The "add files" button doesn't need to be setup because the config
				// `clickable` has already been specified.
				document.querySelector("#actions .start").onclick = function() {
					myDropzone.enqueueFiles(myDropzone.getFilesWithStatus(Dropzone.ADDED))
				}
				document.querySelector("#actions .cancel").onclick = function() {
					myDropzone.removeAllFiles(true)
				}
				// DropzoneJS Demo Code End
			</script>

</body>

</html>