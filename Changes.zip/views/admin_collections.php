<?php
/*
 *   Crafted On Mon Jul 29 2024
 *   Author Stephen Ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();
require_once('../functions/reusableQuery.php');
require_once('../config/config.php');
require_once('../helpers/collection.php');
require_once('../partials/headn.php');

if (isset($_GET['date'])) {
	$date = $_GET['date'];
} else {
	$date = date('Y-m-d');
}

?>

<body class="hold-transition sidebar-mini layout-fixed"></body>
<div class="wrapper">

	<!-- Preloader -->
	<?php include('../partials/preloader.php'); ?>

	<!-- Navbar -->
	<?php include('../partials/header.php'); ?>
	<!-- /.navbar -->

	<!-- Main Sidebar Container -->
	<?php include('../partials/ward_admin_sidenav.php'); ?>

	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<div class="content-header">
			<div class="container">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h1 class="m-0"> My Revenue Collection</h1>
					</div><!-- /.col -->
					<div class="col-sm-6">
						<ol class="breadcrumb float-sm-right">
							<li class="breadcrumb-item"><a href="home">Home</a></li>
							<li class="breadcrumb-item active">Users</li>
						</ol>
					</div><!-- /.col -->
				</div><!-- /.row -->
			</div><!-- /.container-fluid -->
		</div>
		<!-- /.content-header -->

		<!-- Select date -->
		<!-- <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title m-0">Revenue Collection Reports</h5>
                                </div>
                                <div class="card-body">
									<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
										<div class="row">
                                            <div class="col-md-3">
                                                <label for="ward">Day</label>
												<input type="text" required name="day" class="form-control">
                                               
                                            </div>
                                            <div class="col-md-3">
                                                <label for="duration">Month</label>
												<input type="text" required name="month" class="form-control">
                                            </div>
                                            <div class="col-md-3">
                                                <label for="revenue_officer">Year</label>
												<input type="text" required name="year" class="form-control">
                                            </div>
                                            <div class="col-md-3">
                                                <label for="stream">Action</label>
												<button type="submit" class="btn btn-primary form-control" name="seachCollections">Search</button>
                                            </div>
                                        </div>                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
		<!-- ./ Select date -->



		<!-- Main content -->
		<div class="content">
			<div class="container">
				<!-- row  -->
				<div class="row">
					<!-- system users dashboard -->
					<div class="col-lg-12">
						<div class="card card-primary card-outline">
							<div class="card-header">
								<h3 class="card-title">
									<?php
									if (isset($_GET['date'])) {
										// $date = new DateTime($_GET['date']);
										// $formattedDate = $date->format('l, jS F Y');
										// echo $formattedDate;
										echo $_GET['date'];
									} else {
										echo date('l, jS F Y');
									}
									?>
								</h3>
								<!-- Add new user button -->

								<div class="card-tools flex">
									<a data-toggle="modal" data-target="#addUser"><button type="button" class="btn btn-block btn-success">Submit Collections</button></a>
								</div>
							</div>
							<!-- /.card-header -->
							<div class="card-body">
								<table id="example1" class="table table-bordered table-striped">
									<thead>
										<tr>
											<th>Service</th>
											<th>Amount</th>
											<th>Date</th>
											<th>Status </th>
											<th>Ward</th>
											<th>Location</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
										$fetch_records_sql = mysqli_query(
											$mysqli,
											"SELECT * FROM revenue_collections rc
                                                INNER JOIN users u ON u.user_id = rc.collection_user_id 
                                                INNER JOIN revenue_services rs ON rs.service_id = rc.collection_service_id
												INNER JOIN revenue_streams rstr ON rstr.stream_id = rs.service_stream_id
                                                INNER JOIN ward w ON w.ward_id = rc.collection_ward_id 
												WHERE collection_user_id = '{$_SESSION['user_id']}'
												AND DATE(collection_date) = '{$date}' 
												"
										);
										if (mysqli_num_rows($fetch_records_sql) > 0) {
											$cnt =  1;
											while ($rows = mysqli_fetch_array($fetch_records_sql)) {
										?>
												<tr>
													<td>
														<?php echo $rows['service_name']; ?>
													</td>
													<td>
														Ksh <?php echo number_format($rows['collection_amount']); ?>
													</td>
													<td>
														<?php echo $rows['collection_date']; ?>
													</td>
													<td>
														<?php echo $rows['collection_status']; ?>
													</td>
													<td>
														<?php echo $rows['ward_name']; ?>
													</td>
													<td>
														<?php echo $rows['collection_location']; ?>
													</td>
													<td>
														<?php if ($rows['collection_status'] == 'Pending' || $rows['collection_status'] == 'Declined') { ?>
															<a data-toggle="modal" href="#update_<?php echo $rows['collection_id']; ?>" class="badge badge-primary">Update</a>
														<?php } else { ?>
															<span class="badge badge-success">Approved</span>
														<?php } ?>
													</td>
												</tr>
										<?php
												$cnt = $cnt + 1;
												include('../modals/manage_collection.php');
											}
										} ?>
									</tbody>

									</tbody>
								</table>
							</div>
							<!-- /.card-body -->
						</div>
						<!-- /.card -->
					</div>
				</div>
				<!-- /.row -->
			</div>
		</div>
		<!-- /.content -->

		<!-- Add collection modal -->
		<div class="modal fade fixed-right" id="addUser" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header align-items-center">
						<div class="text-center">
							<h6 class="mb-0 text-bold">Add Collections</h6>
						</div>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
							<div class="row">
								<div class="form-group col-sm-6 col-lg-6 col-xl-6">
									<label class="form-control-label">Stream <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<select id="streamDropdown" required name="collection_stream_id" class="form-control">
											<option value="">Select stream</option>
											<?php
											$fetch_records_sql = mysqli_query($mysqli, "SELECT * FROM revenue_streams");
											if (mysqli_num_rows($fetch_records_sql) > 0) {
												while ($rows = mysqli_fetch_array($fetch_records_sql)) {
											?>
													<option value="<?php echo $rows['stream_id']; ?>"><?php echo $rows['stream_name']; ?></option>
											<?php }
											} ?>
										</select>
									</div>
								</div>
								<div class="form-group col-sm-6 col-lg-6 col-xl-6">
									<label class="form-control-label">Service <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<select id="serviceDropdown" required name="collection_service_id" class="form-control">
											<option value="">Select service</option>
											<?php
											$fetch_services_sql = mysqli_query($mysqli, "SELECT * FROM revenue_services");
											if (mysqli_num_rows($fetch_services_sql) > 0) {
												while ($rows = mysqli_fetch_array($fetch_services_sql)) {
											?>
													<option value="<?php echo $rows['service_id']; ?>" data-stream="<?php echo $rows['service_stream_id']; ?>"><?php echo $rows['service_name']; ?></option>
											<?php }
											} ?>
										</select>
									</div>
								</div>
								<div class="form-group col-sm-6 col-lg-6 col-xl-6">
									<label class="form-control-label">Amount <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<input type="text" required name="collection_amount" class="form-control">
									</div>
								</div>

								<div class="form-group col-sm-6 col-lg-6 col-xl-6">
									<label class="form-control-label">Date <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<input type="text" readonly value="<?php echo date('d/m/Y') ?>" required name="collection_date" class="form-control">
									</div>
								</div>
								<div class="form-group col-sm-6 col-lg-6 col-xl-6">
									<label class="form-control-label">Location <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<input type="text" required name="collection_location" class="form-control">
									</div>
								</div>

								<div class="form-group col-sm-6 col-lg-6 col-xl-6">
									<label class="form-control-label">Assignment <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<input type="text" required name="collection_assignment" class="form-control">
									</div>
								</div>
								<div class="form-group col-sm-12 col-lg-12 col-xl-12">
									<label class="form-control-label">Comment <span class="text-danger">*</span></label>
									<div class="input-group input-group-merge">
										<textarea type="text" required name="collection_comment" class="form-control"></textarea>
									</div>
								</div>

							</div>
							<div class="text-right">
								<button type="submit" name="AddCollection" class="btn btn-outline-success">Add Collection</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Add user modal -->
		<!-- Add user modal -->
	</div>
	<!-- /.content-wrapper -->
	<?php include('../partials/footer.php'); ?>

	<!-- Control Sidebar -->
	<aside class="control-sidebar control-sidebar-dark">
		<!-- Control sidebar content goes here -->
	</aside>
	<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<?php include('../partials/scriptn.php'); ?>
<script>
	$(function() {
		$("#example1").DataTable();
		$('#example2').DataTable({
			"paging": true,
			"lengthChange": false,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
		});
	});
	$(document).ready(function() {
		$('#streamDropdown').change(function() {
			var selectedStream = $(this).val();
			$('#serviceDropdown option').each(function() {
				var stream = $(this).data('stream');
				if (stream == selectedStream || selectedStream == "") {
					$(this).show();
				} else {
					$(this).hide();
				}
			});
			$('#serviceDropdown').val(''); // Reset the service dropdown
		});
	});
</script>
</body>

</html>