<?php
session_start();

require_once('../functions/reusableQuery.php');
require_once('../config/config.php');
require_once('../helpers/auth.php');
require_once('../partials/head.php');


// Get parameters from the URL
$streamId = isset($_GET['stream_id']) ? $_GET['stream_id'] : '';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01'); // Default to the first day of the current month
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t'); // Default to the last day of the current month
$selectedWard = isset($_POST['ward']) ? $_POST['ward'] : 'all';

// Fetch the stream name
$streamNameQuery = "SELECT stream_name FROM revenue_streams WHERE stream_id = ?";
$streamNameStmt = $mysqli->prepare($streamNameQuery);
$streamNameStmt->bind_param("i", $streamId);
$streamNameStmt->execute();
$streamNameResult = $streamNameStmt->get_result();
$streamName = $streamNameResult->fetch_assoc()['stream_name'];

// Prepare the query based on user inputs
$query = "
    SELECT 
        w.ward_id,
        w.ward_name,
        SUM(rc.collection_amount) AS total_collected
    FROM revenue_collections rc
    JOIN ward w ON rc.collection_ward_id = w.ward_id
    WHERE rc.collection_status = 'Approved'
    AND rc.collection_stream_id = ?
    AND rc.collection_date BETWEEN ? AND ?
";

if ($selectedWard !== 'all') {
    $query .= " AND w.ward_id = ?";
}

// Group by ward
$query .= " GROUP BY w.ward_id, w.ward_name ORDER BY total_collected DESC";

// Prepare and execute the query
$stmt = $mysqli->prepare($query);

if ($selectedWard !== 'all') {
    $stmt->bind_param("ssss", $streamId, $startDate, $endDate, $selectedWard);
} else {
    $stmt->bind_param("sss", $streamId, $startDate, $endDate);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch ward performance data
$wardPerformance = [];
while ($row = $result->fetch_assoc()) {
    $wardPerformance[] = $row;
}

// Check for errors
if (!$result) {
    die('Error fetching ward performance: ' . $mysqli->error);
}

// Fetch all wards for the dropdown
$wardsQuery = "SELECT ward_id, ward_name FROM ward";
$wardsResult = $mysqli->query($wardsQuery);
$wards = [];
while ($ward = $wardsResult->fetch_assoc()) {
    $wards[] = $ward;
}
?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <?php include('../partials/preloader.php'); ?>

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/executive_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">

            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Ward Performance Details for Stream: <?php echo htmlspecialchars($streamName); ?></h1>
                            <small>Details of revenue collections by ward</small>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>

            <!-- Main content -->
            <div class="container-fluid">
                <!-- Filter Form -->
                <div class="row mb-3">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title m-0">Filter Ward Performance</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="ward">Ward</label>
                                            <select id="ward" name="ward" class="form-control">
                                                <option value="all">All</option>
                                                <?php foreach ($wards as $ward) { ?>
                                                    <option value="<?php echo htmlspecialchars($ward['ward_id']); ?>" <?php echo $selectedWard == $ward['ward_id'] ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($ward['ward_name']); ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="start_date">Start Date</label>
                                            <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($startDate); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label for="end_date">End Date</label>
                                            <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($endDate); ?>">
                                        </div>
                                        <div class="col-md-4 mt-2">
                                            <label for="submit">&nbsp;</label>
                                            <button type="submit" class="btn btn-primary form-control">Filter</button>
                                        </div>
                                        <div class="col-md-4 mt-2">
                                            <label for="reset">&nbsp;</label>
                                            <a href="view_details.php?stream_id=<?php echo urlencode($streamId); ?>&start_date=<?php echo urlencode($startDate); ?>&end_date=<?php echo urlencode($endDate); ?>" class="btn btn-secondary form-control">Reset</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ward Performance Table -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title m-0">Ward Performance</h5>
                            </div>
                            <div class="card-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Ward Name</th>
                                            <th>Total Collected</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($wardPerformance as $performance) { ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($performance['ward_name']); ?></td>
                                                <td><?php echo number_format($performance['total_collected'], 0); ?> Ksh</td>
                                                <td>
                                                    <a href="../views/officer_details.php?ward_id=<?php echo urlencode($performance['ward_id']); ?>&stream_id=<?php echo urlencode($streamId); ?>&start_date=<?php echo urlencode($startDate); ?>&end_date=<?php echo urlencode($endDate); ?>" class="btn btn-info btn-sm">View Officers</a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ./wrapper -->

    </div>
    <?php include('../partials/scripts.php'); ?>
</body>

</html>