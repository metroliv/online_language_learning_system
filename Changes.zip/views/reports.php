<?php
// Include necessary files and start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once('../config/config.php');
require_once('../partials/head.php');

// Fetch ward data for bar chart
$wardNames = [];
$wardTargets = [];
$wardCollections = [];

// Fetch records for each ward
$fetch_records_sql = mysqli_query($mysqli, "SELECT * FROM ward");
if (mysqli_num_rows($fetch_records_sql) > 0) {
    while ($rows = mysqli_fetch_array($fetch_records_sql)) {
        $wardId = $rows['ward_id'];
        $wardName = $rows['ward_name'];

        // Fetch ward target
        $query = "SELECT SUM(streamtarget_amount) FROM streamtarget WHERE streamtarget_ward_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $wardId);
        $stmt->execute();
        $stmt->bind_result($wardTarget);
        $stmt->fetch();
        $stmt->close();

        // Fetch ward collections
        $query = "SELECT SUM(collection_amount) FROM revenue_collections WHERE collection_ward_id = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('i', $wardId);
        $stmt->execute();
        $stmt->bind_result($wardCollection);
        $stmt->fetch();
        $stmt->close();

        // Store data
        $wardNames[] = $wardName;
        $wardTargets[] = $wardTarget;
        $wardCollections[] = $wardCollection;
    }
}

// Convert PHP arrays to JSON for use in JavaScript
$wardNames_json = json_encode($wardNames);
$wardTargets_json = json_encode($wardTargets);
$wardCollections_json = json_encode($wardCollections);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revenue Collection by Ward</title>
    <!-- Include Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #343a40;
            padding: 20px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            padding: 20px;
        }

        canvas {
            border-radius: 8px;
            background: #f3f3f3;
        }

        .chart-title {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <?php include('../partials/executive_sidenav.php'); ?>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="container">
            <div class="chart-title">Revenue Collections vs Targets by Ward</div>
            <canvas id="revenueBarChart" width="800" height="500"></canvas>
        </div>
    </div>

    <script>
        var ctx = document.getElementById('revenueBarChart').getContext('2d');
        var revenueBarChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo $wardNames_json; ?>,
                datasets: [
                    {
                        label: 'Targets',
                        data: <?php echo $wardTargets_json; ?>,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)', // Blue
                        borderColor: 'rgba(54, 162, 235, 1)', // Dark blue
                        borderWidth: 1
                    },
                    {
                        label: 'Collections',
                        data: <?php echo $wardCollections_json; ?>,
                        backgroundColor: 'rgba(255, 99, 132, 0.6)', // Red
                        borderColor: 'rgba(255, 99, 132, 1)', // Dark red
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            font: {
                                size: 16
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                var label = tooltipItem.dataset.label || '';
                                if (label) {
                                    label += ': ' + tooltipItem.raw;
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            font: {
                                size: 14
                            },
                            autoSkip: false, // Ensure all labels are shown
                            maxRotation: 90, // Rotate labels if they are too long
                            minRotation: 45 // Minimum rotation angle for labels
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            color: '#e0e0e0'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
