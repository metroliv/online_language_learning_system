<?php
session_start();
require_once('../helpers/auth.php');
require_once('../config/config.php');
require_once('../partials/head.php'); // Ensure this file includes necessary AdminLTE components

// Fetch performance vs target
$query_performance = "
    SELECT w.ward_name, rt.target_amount, IFNULL(SUM(rc.collection_amount), 0) as collected_amount 
    FROM revenue_targets rt
    LEFT JOIN revenue_collections rc ON rt.target_ward_id = rc.collection_ward_id AND rc.collection_status = 'Approved'
    LEFT JOIN ward w ON rt.target_ward_id = w.ward_id
    GROUP BY rt.target_ward_id, w.ward_name
";
$result_performance = mysqli_query($mysqli, $query_performance);

// Prepare data for performance chart
$wards = [];
$targets = [];
$collected = [];

if ($result_performance) {
    while ($row = mysqli_fetch_assoc($result_performance)) {
        $wards[] = $row['ward_name'];
        $targets[] = $row['target_amount'];
        $collected[] = $row['collected_amount'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performance vs Target by Ward</title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/css/adminlte.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- jQuery -->
    <script src="https://cdn.jsdelivr.net/npm/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Main Header -->
        <?php include('../partials/header.php'); ?>

        <!-- Left side column. contains the sidebar -->
        <?php include('../partials/executive_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Perfomance of Ward</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../views/dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Perfomance of Ward</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <!-- Performance vs Target by Ward (Line Chart) -->
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title">Performance vs Target by Ward</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="chart">
                                <canvas id="performanceChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <?php include('../partials/footer.php'); ?>
    </div>
    <!-- ./wrapper -->

    <script>
        // JavaScript to render the chart
        document.addEventListener('DOMContentLoaded', function() {
            var ctxLine = document.getElementById('performanceChart').getContext('2d');
            var performanceChart = new Chart(ctxLine, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($wards); ?>,
                    datasets: [{
                        label: 'Target Amount',
                        data: <?php echo json_encode($targets); ?>,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2,
                        fill: false
                    }, {
                        label: 'Collected Amount',
                        data: <?php echo json_encode($collected); ?>,
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 2,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
</body>

</html>
