<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once('../config/config.php');
require_once('../partials/head.php');
require_once('../helpers/stream_overview.php')
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revenue Stream Analysis</title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="../public/css/adminlte.min.css">
    <link rel="stylesheet" href="../public/css/styles.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">

    <div class="wrapper">
         <!-- Preloader -->
         <?php include('../partials/preloader.php'); ?>
        <!-- Include Header -->
        <?php include('../partials/header.php'); ?>

        <!-- Include Sidebar -->
        <?php include('../partials/executive_sidenav.php'); ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <!-- Content Header -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Revenue Stream Analysis</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../views/dashboard.php">Home</a></li>
                                <li class="breadcrumb-item active">Revenue Stream Analysis</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div><!-- /.content-header -->

            <!-- Main Content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Region Selector -->
                        <div class="form-group col-md-3">
                            <label for="region">Select Region:</label>
                            <select id="region" class="form-control" onchange="window.location.href = '?stream=<?php echo $selected_stream; ?>&service=<?php echo $selected_service; ?>&region=' + this.value + '&period=<?php echo $selected_period; ?>'">
                                <?php foreach ($regions as $region) : ?>
                                    <option value="<?php echo $region['ward_id']; ?>" <?php echo ($selected_region == $region['ward_id']) ? 'selected' : ''; ?>>
                                        <?php echo $region['ward_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Revenue Stream Selector -->
                        <div class="form-group col-md-3">
                            <label for="revenue_stream">Select Revenue Stream:</label>
                            <select id="revenue_stream" class="form-control" onchange="window.location.href = '?stream=' + this.value + '&service=' + document.getElementById('service').value + '&region=' + document.getElementById('region').value + '&period=<?php echo $selected_period; ?>'">
                                <option value="">-- Select Stream --</option>
                                <?php foreach ($streams as $stream) : ?>
                                    <option value="<?php echo $stream['stream_id']; ?>" <?php echo ($selected_stream == $stream['stream_id']) ? 'selected' : ''; ?>>
                                        <?php echo $stream['stream_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Service Selector -->
                        <div class="form-group col-md-3">
                            <label for="service">Select Service:</label>
                            <select id="service" class="form-control" onchange="window.location.href = '?stream=<?php echo $selected_stream; ?>&service=' + this.value + '&region=' + document.getElementById('region').value + '&period=<?php echo $selected_period; ?>'">
                                <option value="">-- Select Service --</option>
                                <?php foreach ($services as $service) : ?>
                                    <option value="<?php echo $service['service_id']; ?>" <?php echo ($selected_service == $service['service_id']) ? 'selected' : ''; ?>>
                                        <?php echo $service['service_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Period Selector (Date Range) -->
                        <!-- Start Date Selector -->
                        <div class="form-group col-md-3">
                            <label for="start_date">Start Date:</label>
                            <input type="date" id="start_date" class="form-control" value="<?php echo htmlspecialchars($selected_start_date); ?>" onchange="updateURL()">
                        </div>

                        <!-- End Date Selector -->
                        <div class="form-group col-md-3">
                            <label for="end_date">End Date:</label>
                            <input type="date" id="end_date" class="form-control" value="<?php echo htmlspecialchars($selected_end_date); ?>" onchange="updateURL()">
                        </div>
                    </div><!-- /.row -->

                    <!-- Report Container -->
                    <div id="report_container" class="mt-4">
                        <?php if ($selected_stream && $report_data) : ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Revenue Collection Report</h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Stream</th>
                                                <th>Service</th>
                                                <th>Region</th>
                                                <th>Total Collected (KSh)</th>
                                                <th>Month</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($report_data as $row) : ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($row['stream_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['service_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['ward_name']); ?></td>
                                                    <td><?php echo number_format($row['total_collected'], 2); ?></td>
                                                    <td><?php echo htmlspecialchars($row['collection_month']); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div><!-- /.card-body -->

                                <div class="card-footer">
                                    <!-- Optional footer content -->
                                </div><!-- /.card-footer -->
                            </div><!-- /.card -->
                        <?php else : ?>
                            <p class="text-danger">No data available for the selected filters.</p>
                        <?php endif; ?>
                    </div><!-- /#report_container -->

                    <!-- Chart Container -->
                    <div id="chart_container" class="mt-4">
                        <canvas id="revenueChart"></canvas>
                    </div><!-- /#chart_container -->
                </div><!-- /.container-fluid -->
            </div><!-- /.content -->
        </div><!-- /.content-wrapper -->

        <!-- Include Footer -->
        <?php include('../partials/footer.php'); ?>
    </div><!-- /.wrapper -->
    <?php include('../partials/scripts.php'); ?>
    <!-- AdminLTE JS -->
    <script src="../public/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- JavaScript for updating the URL with selected values -->
    <script>
        function updateURL() {
            const stream = document.getElementById('revenue_stream').value;
            const service = document.getElementById('service').value;
            const region = document.getElementById('region').value;
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;

            const newURL = `?stream=${encodeURIComponent(stream)}&service=${encodeURIComponent(service)}&region=${encodeURIComponent(region)}&start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(endDate)}`;
            window.location.href = newURL;
        }

        document.getElementById('revenue_stream').addEventListener('change', updateURL);
        document.getElementById('service').addEventListener('change', updateURL);
        document.getElementById('region').addEventListener('change', updateURL);
        document.getElementById('start_date').addEventListener('change', updateURL);
        document.getElementById('end_date').addEventListener('change', updateURL);
    </script>
    <script>
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const revenueData = {
            labels: <?php echo json_encode(array_column($report_data, 'collection_month')); ?>,
            datasets: [{
                label: 'Total Collected',
                data: <?php echo json_encode(array_column($report_data, 'total_collected')); ?>,
                backgroundColor: 'rgba(60,141,188,0.9)',
                borderColor: 'rgba(60,141,188,0.8)',
                borderWidth: 1
            }]
        };
        const revenueChart = new Chart(ctx, {
            type: 'line',
            data: revenueData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        beginAtZero: true
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>

</html>