<?php
/*
 *   Crafted On Mon Jul 29 2024
 *   Author Stephen Ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();
require_once('../functions/reusableQuery.php');
require_once('../config/config.php');
require_once('../helpers/collection.php');
require_once('../partials/headn.php');

// Check if the session variables are set
if (isset($_SESSION['user_ward_id'])) {

    // Fetch list of revenue collectors for the ward
    $collectorQuery = "SELECT user_id, user_names FROM users 
                       WHERE user_ward_id = '{$_SESSION['user_ward_id']}'
                       AND user_access_level = 'Revenue Collector'";
    $collectorResult = mysqli_query($mysqli, $collectorQuery);
    $collectorCount = mysqli_num_rows($collectorResult); // Get the number of collectors

    // Check if there are any collectors
    if ($collectorCount > 0) {
        // Initialize arrays for chart data
        $collector_names = [];
        $collector_performance = [];
        $collector_colors = [];

        // Fetch total target for the ward
        $targetQuery = "
            SELECT SUM(streamtarget_amount) AS total_target
            FROM streamtarget st
            WHERE st.streamtarget_ward_id = '{$_SESSION['user_ward_id']}'
            AND st.streamtarget_fy = '2024/2025'
        ";
        $targetResult = mysqli_query($mysqli, $targetQuery);
        $totalTarget = mysqli_fetch_assoc($targetResult)['total_target'];

        // Check if the total target is greater than zero
        if ($totalTarget > 0) {
            // Calculate target per collector
            $target_per_collector = $totalTarget / $collectorCount;

            // Process each collector
            while ($collector = mysqli_fetch_assoc($collectorResult)) {
                $collector_id = $collector['user_id'];
                $collector_name = $collector['user_names'];
                $collector_names[] = $collector_name;

                // Fetch total amount collected by this collector
                $collectedQuery = "
                    SELECT COALESCE(SUM(rc.collection_amount), 0) AS total_collected
                    FROM revenue_collections rc
                    WHERE rc.collection_user_id = '{$collector_id}'
                    AND rc.collection_status = 'Approved'
                ";
                $collectedResult = mysqli_query($mysqli, $collectedQuery);
                $collectedAmount = mysqli_fetch_assoc($collectedResult)['total_collected'];

                // Calculate performance as percentage
                $performance_percentage = ($target_per_collector > 0) ? ($collectedAmount / $target_per_collector) * 100 : 0;

                // Store collector performance data
                $collector_performance[] = round($performance_percentage, 2);

                // Determine color based on performance
                if ($performance_percentage < 50) {
                    $collector_colors[] = 'rgba(255, 99, 132, 0.8)'; // Red for low performance
                } elseif ($performance_percentage < 75) {
                    $collector_colors[] = 'rgba(255, 205, 86, 0.8)'; // Yellow for medium performance
                } else {
                    $collector_colors[] = 'rgba(75, 192, 192, 0.8)'; // Green for high performance
                }
            }
        } else {
            echo "The total target for the ward is zero.";
        }
        
        // Prepare data for chart
        $collector_performance = array_values($collector_performance);

    } else {
        echo "No collectors found for the selected ward.";
    }

} else {
    echo "Session variables not set. Please log in.";
}
?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php include('../partials/collector_sidenav.php'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Collectors Performance</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Users</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- DONUT CHART for performance -->
                            <div class="card card-success">
                                <div class="card-header">
                                    <h3 class="card-title">Collector Performance per Ward</h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="chart">
                                        <canvas id="collectorPerformanceChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- Add user modal -->
        </div>
        <!-- /.content-wrapper -->
        <?php include('../partials/footer.php'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->


    <script>
        var ctx = document.getElementById('collectorPerformanceChart').getContext('2d');
        var collectorPerformanceChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($collector_names); ?>,
                datasets: [{
                    label: 'Performance (%)',
                    data: <?php echo json_encode($collector_performance); ?>,
                    backgroundColor: [
                        'rgba(18, 68, 145, 0.2)', // #124491 with 20% opacity
                        'rgba(255, 205, 61, 0.2)', // #ffcd3d with 20% opacity
                        'rgba(54, 162, 235, 0.2)', // #36a2eb with 20% opacity
                        'rgba(255, 99, 132, 0.2)', // #ff6384 with 20% opacity
                        'rgba(75, 192, 192, 0.2)', // #4bc0c0 with 20% opacity
                        'rgba(153, 102, 255, 0.2)', // #9966ff with 20% opacity
                        'rgba(255, 159, 64, 0.2)' // #ff9f40 with 20% opacity
                    ],
                    borderColor: [
                        'rgba(18, 68, 145, 1)', // #124491
                        'rgba(255, 205, 61, 1)', // #ffcd3d
                        'rgba(54, 162, 235, 1)', // #36a2eb
                        'rgba(255, 99, 132, 1)', // #ff6384
                        'rgba(75, 192, 192, 1)', // #4bc0c0
                        'rgba(153, 102, 255, 1)', // #9966ff
                        'rgba(255, 159, 64, 1)' // #ff9f40
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                var label = context.label || '';
                                var value = context.raw || 0;
                                return label + ': ' + value + '%';
                            }
                        }
                    }
                }
            }
        });
    </script>
    <?php include('../partials/scriptn.php'); ?>
    
</body>

</html>