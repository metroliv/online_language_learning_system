<?php
/*
 *   Crafted On Mon Jul 29 2024
 *   Author stephen ndunda (ndundastevn@gmail.com)
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Government of Makueni County Applications Development Section End User License Agreement
 *   Copyright (c) 2023 Government of Makueni County 
 *
 *
 *   1. GRANT OF LICENSE 
 *   GoMC Applications Development Section hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from GoMC Applications Development Section. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from GoMC Applications Development Section
 *
 *   2. COPYRIGHT 
 *   The Software is owned by GoMC Applications Development Section and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 *
 *   5. NO OTHER WARRANTIES. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   GoMC APPLICATIONS DEVELOPMENT SECTION SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL GoMC APPLICATIONS DEVELOPMENT SECTION OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IF GoMC APPLICATIONS DEVELOPMENT SECTION HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL GoMC APPLICATIONS DEVELOPMENT SECTION LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
session_start();
include("../functions/reusableQuery.php");
include('../config/config.php');
include('../helpers/target.php');
include('../config/checklogin.php');
include('../partials/headn.php');

// Array mapping month numbers to month names
$myMonths = [
    1 => 'January',
    2 => 'February',
    3 => 'March',
    4 => 'April',
    5 => 'May',
    6 => 'June',
    7 => 'July',
    8 => 'August',
    9 => 'September',
    10 => 'October',
    11 => 'November',
    12 => 'December'
];

// $month = '08';
// $monthWithoutZero = (int)$month; // This will be 8
// dd($monthWithoutZero); // Outputs: 8

if (isset($_GET['month'])) {	
	if ($_GET['month'] === 'all' || $_GET['month'] === "'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'")
	 { // Use === for comparison
		$months = "'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'"; // Include all months
		$annual = true;
		
	} else {
		$months = "'{$_GET['month']}'"; // Ensure this is sanitized before use
		$annual = false;
	}
	$fy = $_GET['fy']; // Ensure this is sanitized before use
} else {
	$annual = false;
	$currentmonth = date('m');
	$months = "'{$currentmonth}'";	
	$fy = "2024/2025"; // Consider making this dynamic if needed
}

/** Total Conty Collections*/
$query = "SELECT SUM(collection_amount) FROM revenue_collections";
$stmt = $mysqli->prepare($query);
$stmt->execute();
$stmt->bind_result($countyCollections);
$stmt->fetch();
$stmt->close();
?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <?php include('../partials/preloader.php'); ?>

        <!-- Navbar -->
        <?php include('../partials/header.php'); ?>
        <!-- /.navbar -->
        <?php
		if(
				$_SESSION['user_access_level'] == 'ECM' || $_SESSION['user_access_level'] == 'Chief Officer' || $_SESSION['user_access_level'] == 'Director'
				|| $_SESSION['user_access_level'] == 'Director - IMV' || $_SESSION['user_access_level'] == 'ECMS' || $_SESSION['user_access_level'] == 'Executive'
			)  {
					
				require_once('../partials/executive_sidenav.php');
			}else{
				require_once('../partials/admin_sidenav.php');
			}
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"> County Revenue Collections.</h1><br/>
							<h1>
								<?php 
									if($annual){
										echo '2024/2025 FY';
									}else{
										$trimonth = trim($months, "'");
										$monthWithoutZero = (int)$trimonth; // This will be 8
									
										echo $myMonths[$monthWithoutZero].', 2024';
									}						 
								?>	
							</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
                                <li class="breadcrumb-item active">Revenue Collections</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
			
			<!-- filters -->
			<div class="container-fluid pb-2">
			<!-- <div class="col-md-3 col-sm-3 col-3"> -->
				<div class="text-right">
					<a data-toggle="modal" data-target="#filterDashboard"><button type="button" class="btn btn-outline-success btn-sm">filter</button></a>
				</div>	
			<!-- </div> -->
			</div>
			<!-- ./ filters -->

			 <!-- Main content -->
			 <div class="content">                
				<div class="container">
					<!-- row  -->
                    <div class="row">
                        <!-- system users dashboard -->
                        <div class="col-lg-12">
							<div class="card card-primary card-outline">
								
								<!-- /.card-header -->
								<div class="card-body">
									<table id="example1" class="table table-bordered table-striped">
										<thead>                  
											<tr>
												<th style="width: 10px">#</th>
												<th>Ward</th>
												<th>Collections</th>																				
												<th>Financial Year</th>																				
											</tr>
										</thead>
										<tbody>
										<?php
                                        $fetch_records_sql = mysqli_query(
                                            $mysqli,
                                            "SELECT * FROM ward"
                                        );
                                        if (mysqli_num_rows($fetch_records_sql) > 0) {
                                            $cnt =  1;
                                            while ($rows = mysqli_fetch_array($fetch_records_sql)) {
                                        ?>
                                                <tr>
                                                    <td>
                                                        <?php echo $cnt; ?>
                                                    </td>                                                    
													<td>
														<a href="stream_collections?id=<?php echo $rows['ward_id'] ?>">
															<?php echo $rows['ward_name']; ?>
														</a>
													</td>                                                 
                                                    
                                                    <td>
													<?php
														/** Ward collections*/
														$query = "SELECT SUM(collection_amount) FROM revenue_collections
														WHERE collection_ward_id = '{$rows['ward_id']}'";
														$stmt = $mysqli->prepare($query);
														$stmt->execute();
														$stmt->bind_result($wardCollections);
														$stmt->fetch();
														$stmt->close();

														if(!empty($wardCollections)){
															echo 'Ksh. '.$wardCollections;
														}else{
															echo 'ksh. 0';
														}
														?>
                                                    </td>
                                                    
													<td>
                                                        2024/2025
													</td>
													<td>
                                                        <!-- <a href="admin_stream_collection?id=<?php echo $rows['ward_id'] ?>">
															<i class="fas fa-eye"></i>
															View
														</a> -->
													</td>
                                                    
                                                </tr>
                                        <?php
                                                $cnt = $cnt + 1;
                                                // include('../modals/bursary/bursary_user.php');
                                            }
                                        } ?>
                                    </tbody>
																					
										</tbody>										
									</table>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
                        </div>
                    </div>
                    <!-- /.row -->
				</div>
            </div>
            <!-- /.content -->

			<!-- filters modal-->
<div class="modal fade fixed-right" id="filterDashboard" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header align-items-center">
                            <div class="text-center">
                                <h6 class="mb-0 text-bold">Filter</h6>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                                <div class="row">
                                    <div class="form-group col-sm-6 col-lg-6 col-xl-6">
                                        <label class="form-control-label">Month <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <select type="text" required name="month" class="form-control">
                                                <option value="">Select</option>
                                                <option value="all">All Months</option>
                                                <option value="1">January</option>
												<option value="2">February</option>
												<option value="3">March</option>
												<option value="4">April</option>
												<option value="5">May</option>
												<option value="6">June</option>
												<option value="7">July</option>
												<option value="8">August</option>
												<option value="9">September</option>
												<option value="10">October</option>
												<option value="11">November</option>
												<option value="12">December</option>
                                                
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-sm-6 col-lg-6 col-xl-6">
										<label class="form-control-label">Financial Year <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <select type="text" required name="fy" class="form-control">
                                                <option value="2024/2025">2024/2025</option>                                            
                                                
                                            </select>
                                        </div>
                                    </div>                                   

                                </div>
                                <div class="text-right">
                                    <button type="submit" name="Collectionsfiters" class="btn btn-outline-success">Search</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./ filters -->

			<!-- Add user modal -->
			<div class="row">
                    <div class="modal fade fixed-right" id="addUser" role="dialog" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header align-items-center">
                                    <div class="text-center">
                                        <h6 class="mb-0 text-bold">Register new system user</h6>
                                    </div>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form class="needs-validation" method="post" enctype="multipart/form-data" role="form">
                                        <div class="row">
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label">Full names (as they appear in National ID) <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" required name="user_name" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label">Email address <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="email" required name="user_email" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label">Phone number <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="phone" required name="user_phone_number" class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label">Access level <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <select type="text" required name="user_access_level" class="form-control">
                                                        <option value="System Administrator">System Administrator</option>
                                                        <option value="ECM">ECM - ICT, Education & Internship</option>
                                                        <option value="ECMS">ECMs</option>
                                                        <option value="Chief Officer">Chief Officer</option>
                                                        <option value="Director">Director</option>
                                                        <option value="Director - IMV">Director - IMV</option>
                                                        <option value="Ward Administrator">Ward Administrator</option>
                                                        <option value="Staff">Revenue Collector</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-12 col-lg-6 col-xl-6">
                                                <label class="form-control-label"> User Ward <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <select type="text" required name="user_ward" class="form-control">
                                                        <option value="33">Emali/Mulala</option>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm-4 col-lg-12 col-xl-12">
                                                <label class="form-control-label">Address <span class="text-danger">*</span></label>
                                                <div class="input-group input-group-merge">
                                                    <input type="text" required name="user_address" class="form-control">
                                                </div>
                                            </div>

                                        </div>
                                        <div class="text-right">
                                            <button type="submit" name="Add_User" class="btn btn-outline-success">Add User</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<!-- ./ Add user modal -->
            
        </div>
        <!-- /.content-wrapper -->
        <?php include('../partials/footer.php'); ?>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <?php include('../partials/scriptn.php'); ?>
	<script>
	$(function () {
		$("#example1").DataTable();
    	$('#example2').DataTable({
		"paging": true,
		"lengthChange": false,
		"searching": true,
		"ordering": true,
		"info": true,
		"autoWidth": false,
		});
	});
    </script> 		
</body>

</html>

