<?php
require_once('../config/config.php');

// Fetch total collected amount for each ward
$collectedQuery = "
    SELECT 
        rc.collection_ward_id AS ward_id,
        SUM(rc.collection_amount) AS total_collected
    FROM revenue_collections rc
    WHERE rc.collection_status = 'Approved'
    GROUP BY rc.collection_ward_id
";

$collectedResult = $mysqli->query($collectedQuery);

// Fetch total target amount for each ward
$financialYear = '2024/2025'; // Adjust as needed
$targetQuery = "
    SELECT 
        st.streamtarget_ward_id AS ward_id,
        SUM(st.streamtarget_amount) AS total_target
    FROM streamtarget st
    WHERE st.streamtarget_fy = ?
    GROUP BY st.streamtarget_ward_id
";

$targetStmt = $mysqli->prepare($targetQuery);
$targetStmt->bind_param("s", $financialYear);
$targetStmt->execute();
$targetResult = $targetStmt->get_result();

// Combine collected and target data
$collectedData = [];
while ($row = $collectedResult->fetch_assoc()) {
    $collectedData[$row['ward_id']] = $row['total_collected'];
}

$targetData = [];
while ($row = $targetResult->fetch_assoc()) {
    $targetData[$row['ward_id']] = $row['total_target'];
}

// Fetch ward names
$wardIds = array_unique(array_merge(array_keys($collectedData), array_keys($targetData)));
if (!empty($wardIds)) {
    $placeholders = implode(',', array_fill(0, count($wardIds), '?'));
    $wardsQuery = "
        SELECT 
            w.ward_id,
            w.ward_name
        FROM ward w
        WHERE w.ward_id IN ($placeholders)
    ";

    $wardsStmt = $mysqli->prepare($wardsQuery);
    $types = str_repeat('i', count($wardIds)); // All placeholders are integers
    $wardsStmt->bind_param($types, ...$wardIds);
    $wardsStmt->execute();
    $wardsResult = $wardsStmt->get_result();

    $wardNames = [];
    while ($row = $wardsResult->fetch_assoc()) {
        $wardNames[$row['ward_id']] = $row['ward_name'];
    }
} else {
    $wardNames = [];
}

// Prepare data for chart
$wards = array_values($wardNames);
$targets = array_map(function($id) use ($targetData) { return $targetData[$id] ?? 0; }, array_keys($wardNames));
$collected = array_map(function($id) use ($collectedData) { return $collectedData[$id] ?? 0; }, array_keys($wardNames));
?>
