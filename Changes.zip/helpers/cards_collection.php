<?php
require_once('../config/config.php');
// Query to fetch the total revenue target for the financial year 2024/2025
$revenueTargetQuery = "SELECT 
        SUM(st.streamtarget_amount) AS total_target
    FROM 
        streamtarget st
    WHERE 
        st.streamtarget_fy = '2024/2025'";
$revenueTargetResult = $mysqli->query($revenueTargetQuery);

// Check for errors in the query
if (!$revenueTargetResult) {
    die('Error fetching revenue target: ' . $mysqli->error);
}

// Fetch the result
$revenueTarget = $revenueTargetResult->fetch_assoc()['total_target'];

// Query to fetch the total revenue collected without date range
$totalRevenueCollectedQuery = "SELECT SUM(collection_amount) AS total_collected FROM revenue_collections WHERE collection_status = 'Approved'";
$totalRevenueCollectedResult = $mysqli->query($totalRevenueCollectedQuery);

// Check for errors in the query
if (!$totalRevenueCollectedResult) {
    die('Error fetching total revenue collected: ' . $mysqli->error);
}

// Fetch the result
$totalRevenueCollected = $totalRevenueCollectedResult->fetch_assoc()['total_collected'];

// Calculate percentage of target achieved
$percentageAchieved = 0;
if ($revenueTarget > 0) {
    $percentageAchieved = ($totalRevenueCollected / $revenueTarget) * 100;
}

// Query to fetch the top-performing officer and their ward
$officerRevenueQuery = "
    SELECT 
        u.user_id, 
        u.user_names, 
        w.ward_name,
        SUM(c.collection_amount) AS total_collected
    FROM revenue_collections c
    JOIN users u ON c.collection_user_id = u.user_id
    JOIN ward w ON u.user_ward_id = w.ward_id
    WHERE c.collection_status = 'Approved'
    GROUP BY u.user_id, u.user_names, w.ward_name
    ORDER BY total_collected DESC
    LIMIT 1
";
$officerRevenueResult = $mysqli->query($officerRevenueQuery);

// Check for errors in the query
if (!$officerRevenueResult) {
    die('Error fetching officer revenue: ' . $mysqli->error);
}

// Fetch the result
$topOfficer = $officerRevenueResult->fetch_assoc();
$topOfficerName = $topOfficer['user_names'];
$topOfficerWard = $topOfficer['ward_name'];
$topOfficerRevenue = $topOfficer['total_collected'];
