<?php
/*
 *	Crafted On Fri April 19 2024
 *   Author stephen Ndunda (ndundastevn@gmail.com)
 * 
 *   www.makueni.go.ke
 *   info@makueni.go.ke
 *
 *
 *   The Makueni County Government ICT, Education and Internship Department End User License Agreement
 *   Copyright (c) 2022 Makueni County Government
 *
 *
 *   1. GRANT OF LICENSE 
 *   Makueni County Government ICT, Education and Internship Department hereby grants to you (an individual) the revocable, personal, non-exclusive, and nontransferable right to
 *   install and activate this system on one computer solely for your official and non-commercial use,
 *   unless you have purchased a commercial license from Makueni County Government ICT. Sharing this Software with other individuals, 
 *   or allowing other individuals to view the contents of this Software, is in violation of this license.
 *   You may not make the Software available on a network, or in any way provide the Software to multiple users
 *   unless you have first purchased at least a multi-user license from Makueni County Government ICT, Education and Internship Department
 *
 *   2. COPYRIGHT 
 *   The Software is owned by Makueni County Government ICT, Education and Internship Department and protected by copyright law and international copyright treaties. 
 *   You may not remove or conceal any proprietary notices, labels or marks from the Software.
 *
 *
 *   3. RESTRICTIONS ON USE
 *   You may not, and you may not permit others to
 *   (a) reverse engineer, decompile, decode, decrypt, disassemble, or in any way derive source code from, the Software;
 *   (b) modify, distribute, or create derivative works of the Software;
 *   (c) copy (other than one back-up copy), distribute, publicly display, transmit, sell, rent, lease or 
 *   otherwise exploit the Software. 
 *
 *
 *   4. TERM
 *   This License is effective until terminated. 
 *   You may terminate it at any time by destroying the Software, together with all copies thereof.
 *   This License will also terminate if you fail to comply with any term or condition of this Agreement.
 *   Upon such termination, you agree to destroy the Software, together with all copies thereof.
 *
 * 
 *   5. NO OTHER WARRANTIES. 
 *   MAKUENI COUNTY GOVERNMENT ICT, EDUCATION AND INTERNSHIP DEPARTMENT  DOES NOT WARRANT THAT THE SOFTWARE IS ERROR FREE. 
 *   MAKUENI COUNTY GOVERNMENT ICT, EDUCATION AND INTERNSHIP DEPARTMENT SOFTWARE DISCLAIMS ALL OTHER WARRANTIES WITH RESPECT TO THE SOFTWARE, 
 *   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, 
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
 *   SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES OR LIMITATIONS
 *   ON HOW LONG AN IMPLIED WARRANTY MAY LAST, OR THE EXCLUSION OR LIMITATION OF 
 *   INCIDENTAL OR CONSEQUENTIAL DAMAGES,
 *   SO THE ABOVE LIMITATIONS OR EXCLUSIONS MAY NOT APPLY TO YOU. 
 *   THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS AND YOU MAY ALSO 
 *   HAVE OTHER RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.
 *
 *
 *   6. SEVERABILITY
 *   In the event of invalidity of any provision of this license, the parties agree that such invalidity shall not
 *   affect the validity of the remaining portions of this license.
 *
 *
 *   7. NO LIABILITY FOR CONSEQUENTIAL DAMAGES IN NO EVENT SHALL MAKUENI COUNTY GOVERNMENT ICT, EDUCATION AND INTERNSHIP DEPARTMENT OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY
 *   CONSEQUENTIAL, SPECIAL, INCIDENTAL OR INDIRECT DAMAGES OF ANY KIND ARISING OUT OF THE DELIVERY, PERFORMANCE OR 
 *   USE OF THE SOFTWARE, EVEN IFMAKUENI COUNTY GOVERNMENT ICT, EDUCATION AND INTERNSHIP DEPARTMENT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *   IN NO EVENT WILL MAKUENI COUNTY GOVERNMENT ICT, EDUCATION AND INTERNSHIP DEPARTMENT  LIABILITY FOR ANY CLAIM, WHETHER IN CONTRACT 
 *   TORT OR ANY OTHER THEORY OF LIABILITY, EXCEED THE LICENSE FEE PAID BY YOU, IF ANY.
 *
 */
require_once('../functions/reusableQuery.php');
// require('../config/config.php');

/** Search collections */
if(isset($_POST['seachCollections'])){
	// Redirect to another page
	header('Location: admin_collections?='.$_POST['year'].'-'.$_POST['month'].'-'.$_POST['day']);
	exit();
}

/** dashboard filterrs */
if (isset($_POST['Dashboadfiters'])) 
{	
	header("Location: dashboard?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}

/** ward target filterrs */
if (isset($_POST['wardRevenueTarget'])) 
{	
	header("Location: ward_revenue_target?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}
/** ward collections filterrs */
if (isset($_POST['wardCollections'])) 
{	
	header("Location: ward_collections?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}
/** ward performance filterrs */
if (isset($_POST['wardPerformance'])) 
{	
	header("Location: ward_performance?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}

/** Tsrget filterrs */
if (isset($_POST['filterTargets'])) 
{	
	header("Location: revenue_target?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}

/** Collections filterrs */
if (isset($_POST['Collectionsfiters'])) 
{	
	header("Location: revenue_collected?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}

/** performance filters */
if (isset($_POST['Perfomancefiters'])) 
{	
	header("Location: target_achieved?month=" . $_POST['month'] . "&fy=" . $_POST['fy']);
	exit(); 		
}


/**
 * Summary of set_stream_target
 * @param mixed $targetID
 * @param mixed $amount
 * @param mixed $wardID
 * @return void
 */
function set_stream_target($targetID, $amount, $wardID){
	$streams = selectMany('revenue_streams');
	foreach ($streams as $key => $stream) {
		$data = [
			'streamtarget_target_id' => $targetID,
			'streamtarget_stream_id' => $stream['stream_id'],
			'streamtarget_amount' => $amount,
			'streamtarget_ward_id' => $wardID,
			'streamtarget_fy' => '2024/2025'
		];
		$res = saveData($data, 'streamtarget');		

	}	
}

/**
 * Summary of set_streamTarget
 * @return void
 */
function set_streamTarget(){
	$streams = selectMany('revenue_streams');
	foreach ($streams as $key => $stream) {
		$data = [
			'streamtarget_target_id' => 32,
			'streamtarget_stream_id' => $stream['stream_id'],
			'streamtarget_amount' => 100000,
			'streamtarget_ward_id' => 2,
			'streamtarget_fy' => '2024/2025'
		];
		$res = saveData($data, 'streamtarget');		

	}	
}

function set_collector_targets()
{
	global $mysqli;
	
	$filters = [
		'streamtarget_ward_id' => 2,
		'streamtarget_fy' => '2024/2025',
	];
	$streanTarget = selectMany('streamtarget', $filters);
	foreach ($streanTarget as $key => $target) {
		/** Get number of collectors per ward */
		$query = "SELECT count(user_id) FROM users 
		WHERE user_ward_id = '{$target['streamtarget_ward_id']}' 
		AND user_access_level = 'Revenue Collector'
		";
		$stmt = $mysqli->prepare($query);
		$stmt->execute();
		$stmt->bind_result($revCollectors);
		$stmt->fetch();
		$stmt->close();

		if($revCollectors > 0)
		{
			$collectoTargetAmount = $target['streamtarget_amount'] / $revCollectors;
		}else{
			$collectoTargetAmount = 0;
		}

		$collectors = selectMany('users', ['user_ward_id' => $target['streamtarget_ward_id'], 'user_access_level' => 'Revenue Collector']);
		foreach ($collectors as $key => $collector) {
			$datas = [
				'collectortarget_streamtarget_id' => $target['streamtarget_id'],
				'collectortarget_user_id' => $collector['user_id'],
				'collectortarget_amount' => $collectoTargetAmount
			];
			saveDatas($datas, 'collectortarget');
		}
		
	}
	//return  $streanTarget;
}

/** STEP 1: Saving Targets */
if(isset($_POST['addTarget'])){
	$res;	

	$streams = selectMany('revenue_streams');
	foreach ($streams as $key => $stream) {
		# code...
		$amount = str_replace(",", "", $_POST[$stream['stream_id']]);
		$targetdata = [
			'streamtarget_ward_id'=> $_POST['target_ward_id'],
			'streamtarget_fy'=> $_POST['target_financial_year'],
			'streamtarget_amount'=> $amount,
			'streamtarget_stream_id'=> $stream['stream_id'],			
		];
		$check_if_data_exists = selectOne('streamtarget', ['streamtarget_fy'=> $_POST['target_financial_year'], 'streamtarget_stream_id'=> $stream['stream_id'], 'streamtarget_ward_id'=> $_POST['target_ward_id']]);
		if(empty($check_if_data_exists)){
			$res = saveData($targetdata, 'streamtarget');
		}else{
			$res = 0;
		}

	}
	if ($res){
	$success = "Target set Successful";
	} else {
	$err = "Failed, try agin laiter";
	}
			

	
	// dd($wardID.''.$wardFY);

	//set_streamTarget();
	//dd($_POST);
	// $cnt =0;
	// while ($cnt <= 16) {
	// 	$dats = [
	// 		'streamtarget_stream_id'=> 555
	// 	];
	// }

	/** */
	//set_collector_targets();
	

	/** */
	// $wards = selectMany('ward');
	// foreach ($wards as $key => $ward) {
	// 	$_POST['target_ward_id'] = $ward['ward_id'];
	// 	$targetID = saveDatas($_POST, 'revenue_targets');
	// 	$stream_target_amount = $_POST['target_amount'] / 16;
	// 	set_stream_target($targetID, $stream_target_amount, $ward['ward_id']);
	// }	

	/** */
	// $wards = selectMany('ward');
	// foreach ($wards as $key => $ward) {
	// 	$_POST['target_ward_id'] = $ward['ward_id'];
	// 	$targetID = saveDatas($_POST, 'revenue_targets');
	// 	$stream_target_amount = $_POST['target_amount'] / 17;
	// 	set_stream_target($targetID, $stream_target_amount);
	// }	
	// $resl = saveData($_POST, 'bursary_personal_profile');
		
}

/** STEP 1: Updating Targets */
if(isset($_POST['UpdateTarget'])){
	unset($_POST['UpdateTarget']);
	$id = $_POST['target_id'];
	unset($_POST['target_id']);
	//dd($_POST);
	
	$status = updateDetails($_POST, 'revenue_targets', 'target_id', $id);
	
	if ($status){
	$success = "Target Updated Successful";
	} else {
	$err = "Failed, try agin laiter";
	}
		
}
?>


