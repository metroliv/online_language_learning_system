<?php
if (isset($_POST['AddCollection'])) {

    $collection_user_id  = mysqli_real_escape_string($mysqli, $_SESSION['user_id']);
    $collection_stream_id  = mysqli_real_escape_string($mysqli, $_POST['collection_stream_id']);
    $collection_service_id  = mysqli_real_escape_string($mysqli, $_POST['collection_service_id']);
    $collection_amount = str_replace(',', '', mysqli_real_escape_string($mysqli, $_POST['collection_amount']));
    $collection_date = mysqli_real_escape_string($mysqli, $_POST['collection_date']);
    $collection_location = mysqli_real_escape_string($mysqli, $_POST['collection_location']);
    $collection_assignment = mysqli_real_escape_string($mysqli, $_POST['collection_assignment']);
    $collection_comment = mysqli_real_escape_string($mysqli, $_POST['collection_comment']);
    $collection_ward_id  = mysqli_real_escape_string($mysqli, $_SESSION['user_ward_id']);
    $collection_fy  = '2024/2025';
	
    if (mysqli_query($mysqli, "INSERT INTO revenue_collections (collection_user_id, collection_amount, collection_stream_id,  collection_location, collection_assignment, collection_service_id, collection_comment, collection_ward_id, collection_fy) 
            VALUES ('{$collection_user_id}', '{$collection_amount}', '{$collection_stream_id}', '{$collection_location}',  '{$collection_assignment}', '{$collection_service_id}',  '{$collection_comment}', '{$collection_ward_id}', '{$collection_fy}')")) {
        $success = "Revenue collection submitted";
    } else {
        $err = "Error Adding Collection";
    }
}


/* Update Collection */
if (isset($_POST['UpdateCollection'])) {
    $collection_id = mysqli_real_escape_string($mysqli, $_POST['collection_id']);
    $collection_service_id  = mysqli_real_escape_string($mysqli, $_POST['collection_service_id']);
    $collection_stream_id  = mysqli_real_escape_string($mysqli, $_POST['collection_stream_id']);
    $collection_amount = str_replace(',', '', mysqli_real_escape_string($mysqli, $_POST['collection_amount']));
    $collection_date = mysqli_real_escape_string($mysqli, $_POST['collection_date']);
    $collection_location = mysqli_real_escape_string($mysqli, $_POST['collection_location']);
    $collection_assignment = mysqli_real_escape_string($mysqli, $_POST['collection_assignment']);
    $collection_comment = mysqli_real_escape_string($mysqli, $_POST['collection_comment']);
    $collection_status = 'Pending';
	$collection_fy  = '2024/2025';


    if (mysqli_query($mysqli, "UPDATE revenue_collections SET collection_service_id = '{$collection_service_id}', collection_stream_id = '{$collection_stream_id}', collection_amount = '{$collection_amount}',
    collection_date = '{$collection_date}', collection_location = '{$collection_location}', collection_assignment = '{$collection_assignment}', collection_comment = '{$collection_comment}', 
	collection_status = '{$collection_status}', collection_fy = '{$collection_fy}'
    WHERE collection_id = '{$collection_id}'")) {
        $success = "Revenue collection updated";
    } else {
        $err = "Error Preparing Statement";
    }
}
?>
