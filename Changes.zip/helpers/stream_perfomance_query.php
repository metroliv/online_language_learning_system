<?php
require_once('../config/config.php');

// Handle form submission
$stream = isset($_POST['stream']) ? $_POST['stream'] : 'all';
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-01'); // Default to the first day of the current month
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-t'); // Default to the last day of the current month

// Prepare the query based on user inputs
$query = "
    SELECT 
        s.stream_id,
        s.stream_name,
        SUM(rc.collection_amount) AS total_collected
    FROM revenue_collections rc
    JOIN revenue_streams s ON rc.collection_stream_id = s.stream_id
    WHERE rc.collection_status = 'Approved'
    AND rc.collection_date BETWEEN ? AND ?
";

if ($stream != 'all') {
    $query .= " AND rc.collection_stream_id = ?";
}

$query .= " GROUP BY s.stream_id, s.stream_name ORDER BY total_collected DESC";

// Prepare and execute the query
$stmt = $mysqli->prepare($query);

if ($stream != 'all') {
    $stmt->bind_param("sss", $startDate, $endDate, $stream);
} else {
    $stmt->bind_param("ss", $startDate, $endDate);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch stream performance data
$streamPerformance = [];
while ($row = $result->fetch_assoc()) {
    $streamPerformance[] = $row;
}

// Check for errors
if (!$result) {
    die('Error fetching stream performance: ' . $mysqli->error);
}
?>
